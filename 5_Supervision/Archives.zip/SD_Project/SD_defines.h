/* 
 * File:   SD_defines.h
 * Author: Herzaeone
 *
 * Created on 25 mai 2013, 11:30
 */

#ifndef SD_DEFINES_H
#define	SD_DEFINES_H


#include "../QS/QS_all.h"
#include "FSconfig.h"
#include "Compiler.h"
#include "FSDefs.h"
#include "FSIO.h"
#include "HardwareProfile.h"
#include "SD-SPI.h"

#define USE_SD_INTERFACE_WITH_SPI

#endif	/* SD_DEFINES_H */

