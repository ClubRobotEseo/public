/*
 *	Club Robot ESEO 2013 - 2014
 *
 *
 *	Fichier : SD_card.c
 *	Package : Supervision
 *	Description : Gestion d'une m�moire externe sur SPI
 *	Auteur : Herzaeone
 *	Version 20130516
 */

/**
 * Code non impl�ment�: n�cessite des fonctions d'�criture carte SD valide
 */

#define SD_CARD_CAN_MSG_C
#include "Eeprom_can_msg.h"

	void SD_CAN_MSG_init(){
		
	}
