/*
 *	Club Robot ESEO 2008 - 2011
 *	Archi-Tech', PACMAN, ChekNorris
 *
 *	Fichier : main.h
 *	Package : Supervision
 *	Description : sequenceur de la supervision
 *	Auteur : Jacen
 *	Version 20110413
 */

#define MAIN_C
#include "main.h"
#include "QS/QS_who_am_i.h"
#include "QS/QS_adc.h"
#ifdef ENABLE_XBEE
	#include "QS/QS_can_over_xbee.h"
#endif

//Prototypes
void init(void);
void LED_FACTO_init();
void init(void);
void tests(void);
void SWITCH_update(void);
void RCON_read();
void _ISR _MathError();
void _ISR _StackError();
void _ISR _AddressError();
void _ISR _OscillatorFail();
void alim_watcher_init(void);
bool_e watch_alim(void);
#ifdef TEST_HARD
static bool_e received;
void test_W_UART2();
void test_R_UART2();
#endif


int main (void)
{	
	Uint16 i;
	init();
#ifdef TEST_HARD
	test_W_UART2();
#endif
	tests();
	SD_init();
	
	i=-1;
	while (1)
	{	
		if(i)	//Delay n�cessaire avant allumage de la RTC..
			i--;
#ifdef TEST_HARD
		test_R_UART2();
#endif
		if(i==1)
			RTC_print_time();	//Si on rajoute pas ce d�lai bizarre, la RTC n'est pas pr�te quand on vient la lire.
	
		/* Gestion du selftest */
		SELFTEST_update(NULL);

		/* Test fiabilit� des balises */
		SELFTEST_balise_update();

		/* Interface de gestion des boutons */
		BUTTON_update();

		/* Gestion switchs */
		SWITCH_update();
		
		/* V�rification de la r�ception d'un message CAN et traitement de ce message */		
		CAN_WATCH_update();

		/* V�rification de la r�ception d'un message de type CAN sur l'UART1 et l'UART2 */
		CAN_INJECTOR_update();

		#ifdef ENABLE_XBEE
			if(global.config[XBEE])
				CAN_over_XBee_process_main();
		#endif
		
		#ifdef INTERFACE_GRAPHIQUE
			INTERFACE_GRAPHIQUE_process_u1rx();	
		#endif /* def INTERFACE_GRAPHIQUE */
	}
	return 0;
}

void init(void)
{
	PORTS_init();
	LED_FACTO_init();
	UART_init();
	RCON_read();
	RTC_init();
	debug_printf("<---------Demarrage carte supervision Version SD--------->\r\n");
	
	TIMER_init();
	BUFFER_init();
	CAN_init();
	CAN_WATCH_init();
	CAN_INJECTOR_init();
	global.match_started=FALSE;
	QS_WHO_AM_I_find();	//D�termine le robot sur lequel est branch�e la carte.
	debug_printf("I am %s\n",(QS_WHO_AM_I_get())?"TINY":"KRUSTY");
	if(QS_WHO_AM_I_get())
	{
		//Tiny
		global.XBEE_i_am_module =	ROBOT_1;
//		#warning "I_am est temporaire... normalement, Tiny chausse le module 1..."
		global.XBEE_module_id_destination = ROBOT_2;
	}	
	else
	{
		//Krusty
		global.XBEE_i_am_module = ROBOT_2;
		global.XBEE_module_id_destination =ROBOT_1;
	}

	LED_init();
	BUTTON_init();
	
	TIMER4_run(250);	//Timer 1 : 250ms.
	
	#ifdef EEPROM_CAN_MSG_ENABLE
		EEPROM_CAN_MSG_init();
	#endif

	#ifdef SD_CAN_MSG_ENABLE
		SD_CAN_MSG_init();
	#endif
	
	#ifdef INTERFACE_GRAPHIQUE
		INTERFACE_GRAPHIQUE_init();
	#endif /* def INTERFACE_GRAPHIQUE */
	
	//CONFIGURATION PAR DEFAUT
	global.config[STRATEGIE]=1;
	global.config[COLOR]=RED;
	global.config[EVITEMENT]=TRUE;
	global.config[BALISE]=TRUE;
	global.config[DEBUG]=FALSE;
	global.config[EEPROM] = TRUE;
	global.config[XBEE]=FALSE;
	global.config[BUFFER]=TRUE;
	#ifdef FDP_2013	//Ces deux interrupteurs sont pr�sents sur le fond de panier 2013.
		global.config[XBEE] = PORT_SWITCH_XBEE;	//XBee activ� selon l'interrupteur sur le fond de panier !
		global.config[EEPROM] = PORT_SWITCH_EEPROM;//Enregistrement du match activ� selon l'interrupteur sur le fond de panier !
	#else
		global.config[XBEE] = 0;	//XBee activ� selon l'interrupteur sur le fond de panier !
		global.config[EEPROM] = 1;	//Enregistrement du match activ� selon l'interrupteur sur le fond de panier !
	#endif
	
	//Initialisation de la proc�dure de selfest
	SELFTEST_init();
}

// Allume les LEDs au d�marrage apr�s configuration des ports
void LED_FACTO_init(){
	//INITIALISATION DES LEDS
	LED_RUN = 1;
	LED_CAN = 0;
	LED_UART = 0;
	LED_USER = 1;
	LED_USER2 = 0;
	LED_ERROR = 0;
}

//#define FLUSH_EEPROM
void tests(void)
{
	#ifdef FLUSH_EEPROM
		EEPROM_CAN_MSG_flush_eeprom();	//Activer ceci permet de vider la m�moire EEPROM lors de l'init (attention, cela prend 10 secondes environ !!)
		debug_printf("EEPROM_flushed\n");
	#endif
}

//Initialise simplement l'ADC
void alim_watcher_init(){
	ADC_init();
}

//Fonction qui r�cup�re la valeur lue aux bornes de l'alim, la compare � la limite fix�e et renvoie 0 si ca va, 1 si il faut s'alarmer
bool_e watch_alim(void){
	Sint16 value = ADC_getValue(0);
	//static Sint16 previous_value;

	if(value < ALIM_LIMIT){
		return TRUE;
	}

	//previous_value = value;
	return FALSE;
}

#ifdef TEST_HARD
//Fonction pour tester le p�riph�rique UART2 en �criture
void test_W_UART2(void)
{
	debug_printf("Test emission UART2:");
}

//Fonction appel�e par le CAN_Watch pour lever le flag (static au main)
void debug_msg_received(){
	received = TRUE;
}

//Fonction qui renvoie un message lorsque 'un message est recu sur l'UART
//Ce test est � faire de pr�f�rence apr�s le test d'�criture
void test_R_UART2(){
	if(received == TRUE){
		debug_printf("Message recu!");
		received = FALSE;
	}
}
#endif

void SWITCH_update(void)
{
	#ifdef FDP_2013
		global.config[DEBUG]		= SWITCH_RG1;
		global.config[U1_VERBOSE] 	= SWITCH_RG0;
	#else
		global.config[DEBUG]		= 1;
		global.config[U1_VERBOSE] 	= 1;	
	#endif
}	

void _ISR _T4Interrupt()
{
	static Uint8 time_250ms = 0;
	time_250ms = (time_250ms>=4)?0:time_250ms+1;
	if(!time_250ms)	//1 fois toutes les secondes...
	{
		#ifdef ENABLE_XBEE
			if(global.config[XBEE])
				CAN_over_XBee_every_second();
		#endif
	}
	#ifdef TEST_HARD
		static Uint8 LED_LAT = 0x1;
		LATD = LED_LAT<<8;
		if(LED_LAT == 0b100000){
			LED_LAT = 1;
		}else{
			LED_LAT <<=1;
		}
	#endif
	beacon_flag_update();
	IFS1bits.T4IF = 0;
}


void RCON_read()
{
	debug_printf("dsPIC30F reset source :\r\n");
	if(RCON & 0x8000)
		debug_printf("- Trap conflict event\r\n");
	if(RCON & 0x4000)
		debug_printf("- Illegal opcode or uninitialized W register access\r\n");
	if(RCON & 0x80)
		debug_printf("- MCLR Reset\r\n");
	if(RCON & 0x40)
		debug_printf("- RESET instruction\r\n");
	if(RCON & 0x10)
		debug_printf("- WDT time-out\r\n");
	if(RCON & 0x8)
		debug_printf("- PWRSAV #SLEEP instruction\r\n");
	if(RCON & 0x4)
		debug_printf("- PWRSAV #IDLE instruction\r\n");
	if(RCON & 0x2)
		debug_printf("- POR, BOR\r\n");
	if(RCON & 0x1)
		debug_printf("- POR\r\n");
	RCON=0;
}
/* Trap pour debug reset */
void _ISR _MathError()
{
  _MATHERR = 0;
  LED_ERROR = 1;
  debug_printf("Trap Math\r\n");
  while(1) Nop();
}

void _ISR _StackError()
{
  _STKERR = 0;
  LED_ERROR = 1;
  debug_printf("Trap Stack\r\n");
  while(1) Nop();
}

void _ISR _AddressError()
{
  _ADDRERR = 0;
  LED_ERROR = 1;
  debug_printf("Trap Address\r\n");
  while(1) Nop();
}

void _ISR _OscillatorFail()
{
  _OSCFAIL = 0;
  LED_ERROR = 1;
  debug_printf("Trap OscFail\r\n");
  while(1) Nop();
}
