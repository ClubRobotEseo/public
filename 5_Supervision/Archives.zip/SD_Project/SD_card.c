/*
 *	Fichier: SD_card.c
 *	Auteur: Herzaeone
 *	Version 20130527
 *
 */


#include <string.h>
#include "../QS/QS_all.h"
#include "HardwareProfile.h"
#include "FSIO.h"
#include "Selftest.h"
#include "../QS/QS_spi.h"


 static FSFILE * pointer;

 /**
  * Fonction: SD_init
  * Description: On initialise la Carte SD pour pouvoir enregistrer les messages CAN
  *
  * Cas Nominal: La fonction est lanc�e et v�rifie si une carte SD est pr�sente
  *  - Si le mode verbose est activ� apparaitra alors la mendion "MediaDetected" sur l'UART2 suivi d'un saut � la ligne
  * On initialise ensuite la librairie qui configure la carte SD
  *  - Une fois cette initialisation termin�e, le message "FS_init_ok" apparait suivit d'un saut de ligne
  * On ouvre ensuite un fichier
  *  - Si le fichier s'ouvre correctement le message "Fichier ouvert avec succes" est envoy�
  * La fonction d'initialisation s'est donc d�roul�e avec succ�s
  *
  * Cas d'�chec:
  * La fonction �choue dans la d�tection de carte: Le programme bloque tant qu'il ne r�ussit pas a �tablir une connexion
  * La fonction d'initialisation des librairies �choue: Le programme boucle tant qu'il n'a pas r�ussi l'initialisation
  * La fonction d'ouverture de fichier �choue: un message pr�vient alors de cet �chec
  *  ALLOW_WRITES n'est pas d�fini alors le programme envoie un #warning lors de la compilation.
  */
 void SD_init(void){
	 TRISEbits.TRISE9 = 1;
	 SPI_init();

	 while (!MDD_MediaDetect());
	 debug_printf("MediaDetected\n");

	 //Initialisation de la library
	 while(!FSInit()); //Code donn� en exemple par Microchip
	 debug_printf("FSinit_ok\n");

#if defined ALLOW_WRITES
	 pointer = FSfopen ("FILE1.TXT", "w");
	 if (pointer == NULL){
		 LED_ERROR = LED_ON;
		 debug_printf("Erreur d'ouverture du fichier sur carte SD\n");
		 return;
	 }else{
		debug_printf("Fichier ouvert avec succes\n");
	 }
#else
	#warning 'Concerning SD card: ALLOW_WRITE disabled'
#endif
}


 /**
  * Fonction : SD_wtite
  * Descritption comme son nom l'indique cette fonction est destin�e � �crire
  * dans un fichier une chaine de caract�re entr�e en param�tre
  *
  * @param string: char* (La chaine de caract�re � �crire)
  * @ret bool_e : TRUE si l'�criture s'est faite correctement, FALSE sinon
  *
  * Note: Si la fonction �choue un message d'erreur est envoy� sur l'UART2 et
  * la LED_ERROR (rouge) s'allume;
  */
 #if defined ALLOW_WRITES
 bool_e SD_write(char *string){
	 //        chaine--taille(en octet)--taille chaine--Fichier
	 if (FSfwrite (string, 1, strlen(string), pointer) != 21){
		 LED_ERROR = LED_ON;
		 debug_printf("ERREUR ECRITURE CARTE SD\n");
		 return FALSE;
	 }
	 return TRUE;
 }
#endif


 /**
  * Fonction: SD_closeFile
  * Description: Fonction qui sert � fermer le fichier dont le pointeur est la variable globale du m�me nom
  * Note: Une fois le fichier ferm� un message pr�vient de la fermeture sur l'UART2
  */
 void SD_closeFile(){
	 if(FSfclose(pointer))
		 debug_printf("Fichier ferm�\n");
 }
