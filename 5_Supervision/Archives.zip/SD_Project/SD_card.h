/*
 *	Club Robot ESEO 2013 - 2014
 *
 *
 *	Fichier : SD_card.h
 *	Package : Supervision
 *	Description : Gestion d'une m�moire externe sur SPI
 *	Auteur : Herzaeone
 *	Version 20130516
 */

/**
 * Les fonctions sont d�crites dans les .c
 */

#ifndef SD_CARD_H
	#include "SD_defines.h"

	#define	SD_CARD_H

	void SD_init(void);
#if defined ALLOW_WRITES
	void SD_write(char *string);
#endif
	void SD_closeFile(void);
	void SD_test(void);

#endif	/* SD_CARD_H */

