/******************************************************************************
 *
 *                Microchip Memory Disk Drive File System
 *
 ******************************************************************************
 * FileName:        HardwareProfile.h
 * Processor:       dsPIC30
 * Compiler:        C30
 * Modified by Herzaeone
 *
*****************************************************************************/


#ifndef _HARDWAREPROFILE_H_
#define _HARDWAREPROFILE_H_

#include "SD_defines.h"

// Define your clock speed here

// Sample clock speed for PIC18

#if defined (__dsPIC30F__)

    #define GetSystemClock()        32000000
    #define GetPeripheralClock()    GetSystemClock()
    #define GetInstructionClock()   (GetSystemClock() / 2)

    // Clock values
    #define MILLISECONDS_PER_TICK       10                      // Definition for use with a tick timer
    #define TIMER_PRESCALER             TIMER_PRESCALER_8       // Definition for use with a tick timer
    #define TIMER_PERIOD                20000                   // Definition for use with a tick timer

#elif defined (__dsPIC33E__) || defined (__PIC24E__)

    #define GetSystemClock()        120000000
    #define GetPeripheralClock()    (GetSystemClock() / 2)
    #define GetInstructionClock()   (GetSystemClock() / 2)

    // Clock values
    #define MILLISECONDS_PER_TICK       10                      // Definition for use with a tick timer
    #define TIMER_PRESCALER             TIMER_PRESCALER_64      // Definition for use with a tick timer
    #define TIMER_PERIOD                9375                    // Definition for use with a tick timer
#endif


// Select your interface type
// This library currently only supports a single physical interface layer at a time


// Description: Macro used to enable the SD-SPI physical layer (SD-SPI.c and .h)
#define USE_SD_INTERFACE_WITH_SPI

// Description: Macro used to enable the CF-PMP physical layer (CF-PMP.c and .h)
//#define USE_CF_INTERFACE_WITH_PMP

// Description: Macro used to enable the CF-Manual physical layer (CF-Bit transaction.c and .h)                                                                
//#define USE_MANUAL_CF_INTERFACE

// Description: Macro used to enable the USB Host physical layer (USB host MSD library)
//#define USE_USB_INTERFACE


/*********************************************************************/
/******************* Pin and Register Definitions ********************/
/*********************************************************************/

/* SD Card definitions: Change these to fit your application when using
   an SD-card-based physical layer                                   */

#ifdef USE_SD_INTERFACE_WITH_SPI
    
    #if defined __dsPIC30F__

		#if defined (__dsPIC30F6010A__)
	        // Description: SD-SPI Chip Select Output bit
	        #define SD_CS				LATGbits.LATG9
			// Description: SD-SPI Chip Select TRIS bit
	        #define SD_CS_TRIS			TRISGbits.TRISG9
	        
	        // Description: SD-SPI Card Detect Input bit
	        #define SD_CD               PORTEbits.RE8
	        // Description: SD-SPI Card Detect TRIS bit
	        #define SD_CD_TRIS          TRISEbits.TRISE8
	        
	        // Description: SD-SPI Write Protect Check Input bit
	        #define SD_WE               PORTEbits.RE9
	        // Description: SD-SPI Write Protect Check TRIS bit
	        #define SD_WE_TRIS          TRISEbits.TRISE9
	        
	        // Registers for the SPI module you want to use

	        // Description: The main SPI control register
	        #define SPICON1             SPI2CON
	        // Description: The SPI status register
	        #define SPISTAT             SPI2STAT
	        // Description: The SPI Buffer
	        #define SPIBUF              SPI2BUF
	        // Description: The receive buffer full bit in the SPI status register
	        #define SPISTAT_RBF         SPI2STATbits.SPIRBF
	        // Description: The bitwise define for the SPI control register (i.e. _____bits)
	        #define SPICON1bits         SPI2CONbits
	        // Description: The bitwise define for the SPI status register (i.e. _____bits)
	        #define SPISTATbits         SPI2STATbits
	        // Description: The enable bit for the SPI module
	        #define SPIENABLE           SPISTATbits.SPIEN

	        // Tris pins for SCK/SDI/SDO lines

	        // Description: The TRIS bit for the SCK pin
	        #define SPICLOCK            TRISGbits.TRISG6
	        // Description: The TRIS bit for the SDI pin
	        #define SPIIN               TRISGbits.TRISG7
	        // Description: The TRIS bit for the SDO pin
	        #define SPIOUT              TRISGbits.TRISG8
		#endif
		

        // Will generate an error if the clock speed is too low to interface to the card
        #if (GetSystemClock() < 100000)
            #error Clock speed must exceed 100 kHz
        #endif
    
    #endif

#endif


#endif
