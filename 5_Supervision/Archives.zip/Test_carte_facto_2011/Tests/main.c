/*
 *	Club Robot ESEO 2008 - 2010
 *	Archi-Tech', PACMAN
 *
 *	Fichier : main.h
 *	Package : Supervision
 *	Description : sequenceur de la supervision
 *	Auteur : Jacen
 *	Version 20100105
 */

#define MAIN_C
#include "main.h"

int main (void)
{
	init();
	
	while(1)
	{
		test_carte_facto_update();
	}
	return 0;	
}

void init()
{
	PORTS_init();
	UART_init();
	PWM_init();
	TIMER_init(); //pour watchdog
	test_carte_facto_init();
}	
