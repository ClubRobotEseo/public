/*
 *  Club Robot ESEO 2010 - 2011
 *  Chomp
 *
 *  Fichier : QS_watchdog.h
 *  Package : Qualit� Soft
 *  Description : Test des cartes g�n�riques 2010-2011
 *  Auteur : Patrick, Erwan
 *	Licence : CeCILL-C (voir LICENCE.txt)
 *  Version 20110215
 */
 
#include "QS/QS_all.h"

#ifndef TEST_CARTE_FACTO_H
	#define TEST_CARTE_FACTO_H
	
	#include "QS/QS_uart.h"
	#include "QS/QS_watchdog.h"
	#include "QS/QS_pwm.h"
	#include "QS/QS_adc.h"
	
	#define LED_ON	1
	#define LED_OFF	0
	
	#define BOUTON_ON 1
	#define BOUTON_OFF 0
	
	#define INC_PWM 10 //temps au bout duquel le pourcentage de la PWM incremente de 1 (en ms)
	
	#define COEFF 0.004887
	
	void test_carte_facto_init();
	void test_carte_facto_update();
	
#endif /* ndef TEST_CARTE_FACTO_H */
