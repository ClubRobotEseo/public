/*
 *  THD_SYS_time.h: time functions header
 *  Part of ThacidLCD package
 *  Copyright 2001-2005  Axel Voitier
 *  
 *  deadog@users.sourceforge.net
 *  
 *  This software is a computer program whose purpose is to control liquid crystal displays.
 *  
 *  This software is governed by the CeCILL  license under French law and
 *  abiding by the rules of distribution of free software.  You can  use, 
 *  modify and/ or redistribute the software under the terms of the CeCILL
 *  license as circulated by CEA, CNRS and INRIA at the following URL
 *  "http://www.cecill.info". 
 *  
 *  As a counterpart to the access to the source code and  rights to copy,
 *  modify and redistribute granted by the license, users are provided only
 *  with a limited warranty  and the software's author,  the holder of the
 *  economic rights,  and the successive licensors  have only  limited
 *  liability. 
 *  
 *  In this respect, the user's attention is drawn to the risks associated
 *  with loading,  using,  modifying and/or developing or reproducing the
 *  software by the user in light of its specific status of free software,
 *  that may mean  that it is complicated to manipulate,  and  that  also
 *  therefore means  that it is reserved for developers  and  experienced
 *  professionals having in-depth computer knowledge. Users are therefore
 *  encouraged to load and test the software's suitability as regards their
 *  requirements in conditions enabling the security of their systems and/or 
 *  data to be ensured and,  more generally, to use and operate it in the 
 *  same conditions as regards security. 
 *  
 *  The fact that you are presently reading this means that you have had
 *  knowledge of the CeCILL license and that you accept its terms.
 */

#ifndef __THD_SYS_TIME_H
  #define __THD_SYS_TIME_H

  #include "THD_SYS_types.h"
  
  typedef void THD_timing_t;
  
  #ifdef __cplusplus
  extern "C" {
  #endif
  
  THD_timing_t *THD_Init_Timing (void);
  THD_bool THD_Destroy_Timing (THD_timing_t *timing);
  void THD_Timing (THD_timing_t *timing, Uint32 tps); /* tps in s !! */
  
  #ifdef __cplusplus
      }
  #endif
  
  #ifdef __THD_SYS_TIME_C
  
  #endif /* def __THD_SYS_TIME_C */

#endif /* ndef __THD_SYS_TIME_H */
 
/*
====== system/.../THD_SYS_time ======

===== Summary =====

This file provided a timing system.

===== Definitions =====

^  Return type  ^  Function name  ^  Arguments  ^
| [[#THD_timing_t|THD_timing_t]] * | [[#THD_Init_Timing|THD_Init_Timing]] | (void); |
| [[libthacidlcd:userdoc:functions:thd_sys_types#THD_bool|THD_bool]] | [[#THD_Destroy_Timing|THD_Destroy_Timing]] | ([[#THD_timing_t|THD_timing_t]] *timing); |
| void | [[#THD_Timing|THD_Timing]] | ([[#THD_timing_t|THD_timing_t]] *timing, [[libthacidlcd:userdoc:functions:thd_sys_types#Uint32|Uint32]] tps); |

----

==== THD_timing_t ====

<code c>
typedef THD_port_t THD_timing_t;
</code>

//THD_timing_t// is the type for a timing context.

===== Functions =====

==== THD_Init_Timing ====

<code c>
THD_timing_t *
THD_Init_Timing (void)
</code>

This function create and initialize a timing context.

Returns the new timing context.

----

==== THD_Destroy_Timing ====

<code c>
THD_bool
THD_Destroy_Timing (
  THD_timing_t *timing)
</code>

This function terminate and free a timing context.

//timing// is the timing context to destroy.

Returns THD_FALSE if error, THD_TRUE if not.

----

==== THD_Timing ====

<code c>
void
THD_Timing (
  THD_timing_t *timing,
  Uint32 tps)
</code>

This function don't returns before a certain time.

//timing// is the timing context concerned.\\
//tps// is the time to wait in micro seconds (s).

Returns nothing.

----

 --- //[[lexa@nerim.net|Axel Voitier (deadog)]] 2005/07/18 13:34//
*/
