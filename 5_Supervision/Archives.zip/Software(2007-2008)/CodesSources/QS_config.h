/*
 *  Club Robot ESEO 2006 - 2007
 *  Game Hoover
 *
 *  Fichier : config.h
 *  Package : Qualit� Soft - Configuration
 *  Description : Configuration des modules de QS
 *  Auteur : Axel Voitier
 *  Version 20070129
 */

#ifndef __QS_CONFIG_H
  #define __QS_CONFIG_H

  /*
  #define DEBUG_MODE
  #define TEST_MODE
  #define MATCH_MODE
  */
  #define TEST_MODE

  typedef enum {
	BALISE,
	CARTE_ASSER,
	CARTE_MECA,
	CARTE_P,
	CARTE_SUPERVISSION
  } e_carte;

  #define I_AM	CARTE_SUPERVISSION

  #define PORT_A_IO_MASK	0xFFFF
  #define PORT_B_IO_MASK	0xFF3C
  #define PORT_C_IO_MASK	0xFFFF
  #define PORT_D_IO_MASK	0xFFFF
  #define PORT_E_IO_MASK	0xFFFF
  #define PORT_F_IO_MASK	0xFFFF
  #define PORT_G_IO_MASK	0xFF3C

  #define USE_UART1
  #define USE_CAN1

  #include "QS_configCheck.h"

#endif
