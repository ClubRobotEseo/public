/*
 *  THD_IO_port.c: Input/Output port functions
 *  Part of ThacidLCD package
 *  Copyright 2001-2005  Axel Voitier
 *  
 *  deadog@users.sourceforge.net
 *  
 *  This software is a computer program whose purpose is to control liquid crystal displays.
 *  
 *  This software is governed by the CeCILL  license under French law and
 *  abiding by the rules of distribution of free software.  You can  use, 
 *  modify and/ or redistribute the software under the terms of the CeCILL
 *  license as circulated by CEA, CNRS and INRIA at the following URL
 *  "http://www.cecill.info". 
 *  
 *  As a counterpart to the access to the source code and  rights to copy,
 *  modify and redistribute granted by the license, users are provided only
 *  with a limited warranty  and the software's author,  the holder of the
 *  economic rights,  and the successive licensors  have only  limited
 *  liability. 
 *  
 *  In this respect, the user's attention is drawn to the risks associated
 *  with loading,  using,  modifying and/or developing or reproducing the
 *  software by the user in light of its specific status of free software,
 *  that may mean  that it is complicated to manipulate,  and  that  also
 *  therefore means  that it is reserved for developers  and  experienced
 *  professionals having in-depth computer knowledge. Users are therefore
 *  encouraged to load and test the software's suitability as regards their
 *  requirements in conditions enabling the security of their systems and/or 
 *  data to be ensured and,  more generally, to use and operate it in the 
 *  same conditions as regards security. 
 *  
 *  The fact that you are presently reading this means that you have had
 *  knowledge of the CeCILL license and that you accept its terms.
 */

#define __THD_IO_PORT_C

#include "THD_IO_port.h"


THD_port_t *
THD_IO_Init_Port (
  THD_addr_port_t addr,
  THD_port_type_e type,
  THD_port_t *control_port)
{
  THD_port_t *port=NULL;
  
  if(singleton_port_used == NB_SINGLETON_PORT) {
    #ifdef SHOW_ERROR
    THD_SetError ("THD_IO_Init_Port : no singleton port available\n");
    #endif /* def SHOW_ERROR */
    return NULL;
  }
  	
  port = &port_pool[singleton_port_used++];
  
  port->addr = addr;
  port->type = type;
  
  if(port->type == DATA) {
    if(control_port == NULL) {
      #ifdef SHOW_ERROR
      THD_SetError ("THD_IO_Init_Port : wrong parameter (control_port (3) must be set for a DATA port)\n");
      #endif /* def SHOW_ERROR */
      return THD_FALSE;
    }
    if(control_port->type != CONTROL) {
      #ifdef SHOW_ERROR
      THD_SetError ("THD_IO_Init_Port : wrong parameter (for a DATA port, control_port (3) must be a CONTROL port)\n");
      #endif /* def SHOW_ERROR */
      return THD_FALSE;
    }
    port->control_port = control_port;
  }else
    port->control_port = NULL;
  
  port->status = NOT_INITIALIZED;
    
  return port;
}

THD_bool
THD_IO_Destroy_Port (
  THD_port_t *port)
{
  if(port == NULL)
    return THD_TRUE;
    
  /* Ici on devrait lib�rer celui qui est dans le tableau de singleton, mais �a impose une gestion d'un tableau � trous */
  
  return THD_TRUE;
}

THD_bool
THD_IO_SetStatus_Port (
  THD_port_t *port,
  THD_port_status_e status)
{
  THD_addr_port_t addr;
	
  if((port == NULL) || (port->type == CONTROL)) {
    #ifdef SHOW_ERROR
    THD_SetError ("THD_IO_SetStatus_Port : wrong parameter\n");
    #endif /* def SHOW_ERROR */
    return THD_FALSE;
  }
    
  switch(status) {
    case INPUT:
      if((port->status == OUTPUT) || (port->status == NOT_INITIALIZED)) {
        addr = port->control_port->addr;
        ACCESS_REG(addr) = 0xFFFF;
        port->status = INPUT;
      }
    break;
    case OUTPUT:
      if((port->status == INPUT) || (port->status == NOT_INITIALIZED)) {
	    addr = port->control_port->addr;
        ACCESS_REG(addr) = 0x0000;
        port->status = OUTPUT;
      }
    break;
    case NOT_INITIALIZED:
      return THD_FALSE;
  }
  
  return THD_TRUE;
}

THD_size_port_t
THD_IO_Read_Port (
  THD_port_t *port)
{
  THD_addr_port_t addr;
  
  if(port == NULL) {
    #ifdef SHOW_ERROR
    THD_SetError ("THD_IO_Read_Port : wrong parameter\n");
    #endif /* def SHOW_ERROR */
    return 0;
  }
  
  if((port->type != CONTROL) && (port->status != INPUT)) {
    #ifdef SHOW_ERROR
    THD_SetError ("THD_IO_Send_Port : port have not an INPUT state\n");
    #endif /* def SHOW_ERROR */
    return 0;
  }
  
  addr = port->addr;
  return ACCESS_REG(addr);
}

void
THD_IO_Send_Port (
  THD_port_t *port,
  THD_size_port_t data)
{
  THD_addr_port_t addr;
  
  if(port == NULL) {
    #ifdef SHOW_ERROR
    THD_SetError ("THD_IO_Send_Port : wrong parameter\n");
    #endif /* def SHOW_ERROR */
    return;
  }
  
  if((port->type  != CONTROL) && (port->status != OUTPUT)) {
    #ifdef SHOW_ERROR
    THD_SetError ("THD_IO_Send_Port : port have not an OUTPUT state\n");
    #endif /* def SHOW_ERROR */
    return;
  }
  
  addr = port->addr;
  ACCESS_REG(addr) = data;
}

THD_bit_t *
THD_IO_Init_Bit (
  THD_port_t *port,
  THD_bit_list_e pin)
{
  THD_bit_t *bit=NULL;
  THD_size_port_t set, raz;
  
  if((port == NULL) || (port->type != CONTROL)) {
    #ifdef SHOW_ERROR
    THD_SetError ("THD_IO_Init_Bit : wrong parameter\n");
    #endif /* def SHOW_ERROR */
    return NULL;
  }
  
  if(singleton_bit_used == NB_SINGLETON_BIT) {
    #ifdef SHOW_ERROR
    THD_SetError ("THD_IO_Init_Bit : no singleton bit available\n");
    #endif /* def SHOW_ERROR */
    return NULL;
  }
  	
  bit = &bit_pool[singleton_bit_used++];
  
  bit->port = port;
  bit->pin = pin;
  bit->set_mask = THD_IO_GetSetMask_Bit (pin);
  bit->raz_mask = ~ bit->set_mask;
  bit->status = BIT_FIX;

  set = bit->set_mask;
  raz = bit->raz_mask;
  
  return bit;
}

THD_bool
THD_IO_Destroy_Bit (
  THD_bit_t *bit)
{
  if(bit == NULL)
    return THD_TRUE;
    
  /* Ici on devrait lib�rer celui qui est dans le tableau de singleton, mais �a impose une gestion d'un tableau � trous */
  
  return THD_TRUE;
}

THD_size_port_t
THD_IO_GetSetMask_Bit (
  THD_bit_list_e pin)
{
  /*  THD_bit_list_e est un enum dont les valeurs num�riques correspondent au d�calage de bit � r�aliser pour avoir le mask
   *  C'est une fonction et non une macro pour garder le typage.
   */
  return (THD_size_port_t) (1 << pin);
}

THD_size_port_t
THD_IO_GetStatusMask_Bit (
  THD_bit_t *bit,
  THD_bit_status_e status,
  THD_size_port_t base)
{
  if(bit == NULL) {
    #ifdef SHOW_ERROR
    THD_SetError ("THD_IO_GetStatusMask_Bit : wrong parameter\n");
    #endif /* def SHOW_ERROR */
    return 0;
  }
  
  if(status == BIT_FIX)
    return base;
  else if(status == BIT_HIGH)
    return base | bit->set_mask;
  else
    return base & bit->raz_mask;
}
