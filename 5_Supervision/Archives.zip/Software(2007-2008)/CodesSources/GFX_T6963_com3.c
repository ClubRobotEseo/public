/*
 *  GFX_T6963_com3.c: standart functions adapted for GFX_T6963_com2
 *  Part of ThacidLCD package
 *  Copyright 2001-2005  Axel Voitier
 *  
 *  deadog@users.sourceforge.net
 *  
 *  This software is a computer program whose purpose is to control liquid crystal displays.
 *  
 *  This software is governed by the CeCILL  license under French law and
 *  abiding by the rules of distribution of free software.  You can  use, 
 *  modify and/ or redistribute the software under the terms of the CeCILL
 *  license as circulated by CEA, CNRS and INRIA at the following URL
 *  "http://www.cecill.info". 
 *  
 *  As a counterpart to the access to the source code and  rights to copy,
 *  modify and redistribute granted by the license, users are provided only
 *  with a limited warranty  and the software's author,  the holder of the
 *  economic rights,  and the successive licensors  have only  limited
 *  liability. 
 *  
 *  In this respect, the user's attention is drawn to the risks associated
 *  with loading,  using,  modifying and/or developing or reproducing the
 *  software by the user in light of its specific status of free software,
 *  that may mean  that it is complicated to manipulate,  and  that  also
 *  therefore means  that it is reserved for developers  and  experienced
 *  professionals having in-depth computer knowledge. Users are therefore
 *  encouraged to load and test the software's suitability as regards their
 *  requirements in conditions enabling the security of their systems and/or 
 *  data to be ensured and,  more generally, to use and operate it in the 
 *  same conditions as regards security. 
 *  
 *  The fact that you are presently reading this means that you have had
 *  knowledge of the CeCILL license and that you accept its terms.
 */

#define __GFX_T6963_COM3_C

#include "GFX_T6963_com3.h"


void *
GFX_T6963_DestroyDriver (
  THD_GFX_T6963_com2_t *com2)
{
  THD_CHECK ( , com2 == NULL ,
    return NULL;
  )
    
  GFX_T6963_DestroyCom1 (com2->com1);
  GFX_T6963_DestroyCom2 (com2);
  
  return NULL;
}

/* Fonctions g�n�rales */

#ifndef __c18__
inline
#endif
void
GFX_T6963_TraceObject_Start (
  THD_GFX_T6963_com2_t *com2)
{

}

#ifndef __c18__
inline
#endif
void
GFX_T6963_TraceObject_End (
  THD_GFX_T6963_com2_t *com2)
{

}

THD_bool
GFX_T6963_SetCursorPos (
  THD_GFX_T6963_com2_t *com2,
  THD_pos_t pos)
{ 
  THD_CHECK ( , com2 == NULL || !pos.y || pos.y > com2->txt_size.y || !pos.x || pos.x > com2->txt_size.x ,
    THD_ERROR ("GFX_T6963_SetCursorPos : wrong parameter\n");
    return THD_FALSE;
  )
  
  THD_VERBOSE ("GFX_T6963_SetCursorPos : (%d, %d)\n", pos.x, pos.y);
  
  return GFX_T6963_RegistersSetting (com2, GFX_T6963_SET_CURSOR_POINTER, (pos.x - 1), (pos.y - 1));
}

/* Fonctions texte */

unsigned char
GFX_T6963_TransChar (
  unsigned char caract)
{

  /*
   *  Adaptation � la char map du T6963
   */

  if((caract >= 0x20) && (caract < 0xA0))
    return (caract - 0x20);
  else
    return 0;
}

THD_bool
GFX_T6963_SetPos_Txt (
  THD_GFX_T6963_com2_t *com2,
  THD_pos_t pos)
{
/*
 *  1 <= row <= txt_row
 *  1 <= col <= txt_col
 */
 
  Uint16 start;
  
  THD_CHECK ( , com2 == NULL || !pos.y || pos.y > com2->txt_size.y || !pos.x || pos.x > com2->txt_size.x ,
    THD_ERROR ("GFX_T6963_SetPos_Txt : wrong parameter\n");
    return THD_FALSE;
  )
  
  pos.x--;
  pos.y--;  
  start = com2->txt_home; /* Adresse d'origine ... */
  start += pos.y * com2->txt_area; /* ... Plus le nombre de ligne ... */
  start += pos.x; /* ... Plus la colonne ... Et Voila ! */
  
  THD_VERBOSE ("GFX_T6963_SetPos_Txt : (%d, %d) addr=0x%X\n",  (pos.x + 1), (pos.y + 1), start);
  
  return GFX_T6963_RegistersSetting (com2, GFX_T6963_SET_ADDRESS_POINTER, GFX_T6963_GetLowerByte (start), GFX_T6963_GetUpperByte (start));
}

THD_bool
GFX_T6963_Clear_Txt (
  THD_GFX_T6963_com2_t *com2)
{
  Uint16 pos;
  THD_CHECK ( , com2 == NULL ,
    THD_ERROR ("GFX_T6963_Clear_Txt : wrong parameter\n");
    return THD_FALSE;
  )
  
  THD_CHECK ( GFX_T6963_SetPos_Txt (com2, THD_pos(1, 1)) , == THD_FALSE ,
    return THD_FALSE;
  )
  
  THD_CHECK ( GFX_T6963_DataAutoRW (com2, GFX_T6963_DATA_AUTO_WRITE) , == THD_FALSE ,
    return THD_FALSE;
  )
  
  for(pos = 0 ; pos < (com2->txt_area * com2->txt_size.y) ; pos++) {
    THD_CHECK ( GFX_T6963_AutoDataSend (com2, 0) , == THD_FALSE ,
      return THD_FALSE;
    )
  }
  
  THD_CHECK ( GFX_T6963_DataAutoRW (com2, GFX_T6963_DATA_AUTO_RESET) , == THD_FALSE ,
    return THD_FALSE;
  )
  
  THD_CHECK ( GFX_T6963_SetPos_Txt (com2, THD_pos(1, 1)) , == THD_FALSE ,
    return THD_FALSE;
  )
  
  THD_VERBOSE ("GFX_T6963_Clear_Txt : CLEAR TXT\n");
  
  return THD_TRUE;
}

THD_bool
GFX_T6963_PrintChar_Txt (
  THD_GFX_T6963_com2_t *com2,
  unsigned char c)
{
  unsigned char real_c;
  
  THD_CHECK ( , com2 == NULL ,
    THD_ERROR ("GFX_T6963_PrintChar_Txt : wrong parameter\n");
    return THD_FALSE;
  )
  
  real_c = GFX_T6963_TransChar (c);
  
  THD_VERBOSE ("GFX_T6963_PrintChar_Txt : \"%c\"\n", c);
  
  return GFX_T6963_DataRW (com2, GFX_T6963_DATA_WRITE_ISZ, real_c, NULL);
}

Uint8
GFX_T6963_PrintString_Txt (
  THD_GFX_T6963_com2_t *com2,
  const char *string)
{
  char *use=NULL;
  
  THD_CHECK ( , com2 == NULL || string == NULL ,
    THD_ERROR ("GFX_T6963_PrintString_Txt : wrong parameter\n");
    return 0;
  )
  
  THD_CHECK ( GFX_T6963_DataAutoRW (com2, GFX_T6963_DATA_AUTO_WRITE) , == THD_FALSE ,
    return 0;
  )
  
  for(use = (char *) string ; *use != 0 ; use++) {
    THD_CHECK ( GFX_T6963_AutoDataSend (com2, GFX_T6963_TransChar (*use)) , == THD_FALSE ,
      return 0;
    )
  }
    
  THD_CHECK ( GFX_T6963_DataAutoRW (com2, GFX_T6963_DATA_AUTO_RESET) , == THD_FALSE ,
    return 0;
  )
    
  THD_VERBOSE ("GFX_T6963_PrintString_Txt : (%d) %s\n", use - string, string);
  
  return (char) (use - string);
}

Uint8
GFX_T6963_PrintString2_Txt (
  THD_GFX_T6963_com2_t *com2,
  const char *string)
{
  char *org=(char *)string;

  THD_CHECK ( , com2 == NULL || string == NULL ,
    THD_ERROR ("GFX_T6963_PrintString_Txt : wrong parameter\n");
    return 0;
  )
 while(*string != 0) {
    GFX_T6963_PrintChar_Txt (com2, *string);
	string++;
  }

/*  THD_VERBOSE ("GFX_T6963_PrintString_Txt : (%d) %s\n", string - use, string);*/
  
  return (char) (string - org);
}

THD_bool
GFX_T6963_ClearLine_Txt (
  THD_GFX_T6963_com2_t *com2,
  THD_coord_t line)
{
/*
 *  1 <= line <= txt_row
 */
  Uint8 pos;
 
  THD_CHECK ( , com2 == NULL || !line || line > com2->txt_size.y ,
    THD_ERROR ("GFX_T6963_ClearLine_Txt : wrong parameter\n");
    return THD_FALSE;
  )
  
  THD_CHECK ( GFX_T6963_SetPos_Txt (com2, THD_pos (1, line)) , == THD_FALSE ,
    return THD_FALSE;
  )
  
  THD_CHECK ( GFX_T6963_DataAutoRW (com2, GFX_T6963_DATA_AUTO_WRITE) , == THD_FALSE ,
    return THD_FALSE;
  )
  
  for(pos = 0 ; pos < com2->txt_size.x ; pos++) {
    THD_CHECK ( GFX_T6963_AutoDataSend (com2, 0) , == THD_FALSE ,
      return THD_FALSE;
    )
  }
    
  THD_CHECK ( GFX_T6963_DataAutoRW (com2, GFX_T6963_DATA_AUTO_RESET) , == THD_FALSE ,
    return THD_FALSE;
  )
    
  THD_VERBOSE ("GFX_T6963_ClearLine_Txt : line=%d\n", line);
  
  return THD_TRUE;
}

/* Fonctions graphiques */
THD_bool
GFX_T6963_SetPos_Gfx (
  THD_GFX_T6963_com2_t *com2,
  THD_pos_t pos)
{
  Uint16 start;
  THD_pos_t org_pos;
  
  THD_CHECK ( , com2 == NULL || !pos.y || pos.y > com2->gfx_size.y || !pos.x || pos.x > com2->gfx_size.x ,
    THD_ERROR (("GFX_T6963_SetPos_Gfx : wrong parameter %d %d %d %d\n", pos.x, pos.y, com2->gfx_size.x, com2->gfx_size.y));
    return THD_FALSE;
  )
  
  org_pos = pos;
  pos.x--;
  pos.y--;
  pos.x /= com2->font_width;
  start = com2->gfx_home;
  start += pos.y * com2->gfx_area;
  start += pos.x;
  
  THD_VERBOSE ("GFX_T6963_SetPos_Gfx : (%d, %d) addr=0x%X (byte %d of line %d)\n",  org_pos.x, org_pos.y, start, (pos.x + 1), (pos.y + 1));
  
  return GFX_T6963_RegistersSetting (com2, GFX_T6963_SET_ADDRESS_POINTER, GFX_T6963_GetLowerByte (start), GFX_T6963_GetUpperByte (start));
}

THD_bool
GFX_T6963_Clear_Gfx (
  THD_GFX_T6963_com2_t *com2)
{
  Uint16 pos;

  THD_CHECK ( , com2 == NULL ,
    THD_ERROR ("GFX_T6963_Clear_Gfx : wrong parameter\n");
    return THD_FALSE;
  )
  
  THD_CHECK ( GFX_T6963_SetPos_Gfx (com2, THD_pos(1, 1)) , == THD_FALSE ,
    return THD_FALSE;
  )
  
  THD_CHECK ( GFX_T6963_DataAutoRW (com2, GFX_T6963_DATA_AUTO_WRITE) , == THD_FALSE ,
    return THD_FALSE;
  )
  
  for(pos = 0 ; pos < (com2->gfx_area * com2->gfx_size.y) ; pos++) {
    THD_CHECK ( GFX_T6963_AutoDataSend (com2, 0) , == THD_FALSE ,
      return THD_FALSE;
    )
  }
    
  THD_CHECK ( GFX_T6963_DataAutoRW (com2, GFX_T6963_DATA_AUTO_RESET) , == THD_FALSE ,
    return THD_FALSE;
  )
  
  THD_CHECK ( GFX_T6963_SetPos_Gfx (com2,THD_pos(1, 1)) , == THD_FALSE ,
    return THD_FALSE;
  )
    
  THD_VERBOSE ("GFX_T6963_Clear_Gfx : CLEAR GFX\n");
  
  return THD_TRUE;
}

THD_bool
GFX_T6963_SetPixel_Gfx (
  THD_GFX_T6963_com2_t *com2,
  THD_pos_t pos,
  SET_RESET_e set_mode)
{
/*
 *  1 <= y <= gfx_row
 *  1 <= x <= gfx_col
 */
 
  THD_CHECK ( , com2 == NULL || !pos.y || pos.y > com2->gfx_size.y || !pos.x || pos.x > com2->gfx_size.x ,
    THD_ERROR ("GFX_T6963_SetPixel_Gfx : wrong parameter\n");
    return THD_FALSE;
  )
  
  THD_CHECK ( GFX_T6963_SetPos_Gfx (com2, pos) , == THD_FALSE ,
    return THD_FALSE;
  )

  pos.x--;
  pos.y--;
  
  THD_CHECK ( GFX_T6963_BitSetReset (com2, set_mode, (com2->font_width - 1) - (pos.x % com2->font_width)) , == THD_FALSE ,
    return THD_FALSE;
  )
    
  THD_VERBOSE ("GFX_T6963_SetPixel_Gfx : %s_PIXEL (%d, %d)\n", set_mode == RESET ? "RESET" : "SET", (pos.x + 1), (pos.y + 1));
   
  return THD_TRUE;
}

THD_bool
GFX_T6963_SetByte_Gfx (
  THD_GFX_T6963_com2_t *com2,
  THD_pos_t pos,
  Uint8 byte)
{  
  THD_pos_t org_pos;
  Uint8 byte1, byte2;
   
  THD_CHECK ( , com2 == NULL || !pos.y || pos.y > com2->gfx_size.y || !pos.x || pos.x > com2->gfx_size.x ,
    THD_ERROR ("GFX_T6963_SetByte_Gfx : wrong parameter\n");
    return THD_FALSE;
  )
  
  if(com2->font_width == 8) {
    THD_CHECK ( GFX_T6963_SetPos_Gfx (com2, pos) , == THD_FALSE ,
      return THD_FALSE;
    )
      
    THD_VERBOSE ("GFX_T6963_SetByte_Gfx : (%d, %d) byte=0x%X\n", pos.x, pos.y, byte);
    
    return GFX_T6963_DataRW (com2, GFX_T6963_DATA_WRITE_FIX, byte, NULL);
  }else if(com2->font_width == 6) {
    /*
      | i i i i i i i | i i i i i i i | i i i i i i i |  8 bits squaring (virtual)
      | i i i i i | i i i i i | i i i i i | i i i i i |  6 bits squaring (real)
      => 3*8 = 4*6 ! :-p
     */
    org_pos = pos;
    pos.x--;
    pos.y--;

    THD_CHECK ( GFX_T6963_SetPos_Gfx (com2, THD_pos (((pos.x / 8) * 8) + 1, pos.y + 1)) , == THD_FALSE ,
      return THD_FALSE;
    )
    THD_CHECK ( GFX_T6963_DataRW (com2, GFX_T6963_DATA_READ_ISZ, 0, &byte1) , == THD_FALSE ,
      return THD_FALSE;
    )
    THD_CHECK ( GFX_T6963_DataRW (com2, GFX_T6963_DATA_READ_DSZ, 0, &byte2) , == THD_FALSE ,
      return THD_FALSE;
    )
    
    switch((pos.x / 8) % 3) {
      case 0:
        byte1 = (byte & 0xFC) >> 2;
        byte2 = ((byte & 0x03) << 4) | (byte2 & 0x0F);
      break;
      case 1:
        byte1 = ((byte & 0xF0) >> 4) | (byte1 & 0x30);
        byte2 = ((byte & 0x0F) << 2) | (byte2 & 0x03);
      break;
      case 2:
        byte1 = ((byte & 0xC0) >> 6) | (byte1 & 0x3C);
        byte2 = (byte & 0x3F);
      break;
    }
    byte1 &= 0x3F;
    byte2 &= 0x3F;

    THD_CHECK ( GFX_T6963_DataRW (com2, GFX_T6963_DATA_WRITE_ISZ, byte1, NULL) , == THD_FALSE ,
      return THD_FALSE;
    )
    THD_CHECK ( GFX_T6963_DataRW (com2, GFX_T6963_DATA_WRITE_ISZ, byte2, NULL) , == THD_FALSE ,
      return THD_FALSE;
    )
      
    THD_VERBOSE ("GFX_T6963_SetByte_Gfx : (%d, %d) byte=0x%X\n", org_pos.x, org_pos.y, byte);
    
    return THD_TRUE;
  }
  
  return THD_FALSE;
}
