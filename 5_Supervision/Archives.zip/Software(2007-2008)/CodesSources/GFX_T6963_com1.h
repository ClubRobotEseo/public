/*
 *  GFX_T6963_com1.h: header file for parallel port level for T6963 driver
 *  Part of ThacidLCD package
 *  Copyright 2001-2005  Axel Voitier
 *
 *  deadog@users.sourceforge.net
 *
 *  This software is a computer program whose purpose is to control liquid crystal displays.
 *
 *  This software is governed by the CeCILL  license under French law and
 *  abiding by the rules of distribution of free software.  You can  use,
 *  modify and/ or redistribute the software under the terms of the CeCILL
 *  license as circulated by CEA, CNRS and INRIA at the following URL
 *  "http://www.cecill.info".
 *
 *  As a counterpart to the access to the source code and  rights to copy,
 *  modify and redistribute granted by the license, users are provided only
 *  with a limited warranty  and the software's author,  the holder of the
 *  economic rights,  and the successive licensors  have only  limited
 *  liability.
 *
 *  In this respect, the user's attention is drawn to the risks associated
 *  with loading,  using,  modifying and/or developing or reproducing the
 *  software by the user in light of its specific status of free software,
 *  that may mean  that it is complicated to manipulate,  and  that  also
 *  therefore means  that it is reserved for developers  and  experienced
 *  professionals having in-depth computer knowledge. Users are therefore
 *  encouraged to load and test the software's suitability as regards their
 *  requirements in conditions enabling the security of their systems and/or
 *  data to be ensured and,  more generally, to use and operate it in the
 *  same conditions as regards security.
 *
 *  The fact that you are presently reading this means that you have had
 *  knowledge of the CeCILL license and that you accept its terms.
 */

#ifndef __GFX_T6963_COM1_H
  #define __GFX_T6963_COM1_H

  /* PUBLIC */

  #include "THD_system.h"

  #ifdef __linux__ /* Pour Linux uniquement ... */
    #ifndef GFX_T6963_DEFAULT_DATA_PORT
      #define GFX_T6963_DEFAULT_DATA_PORT       0x378
    #endif /* ndef GFX_T6963_DEFAULT_DATA_PORT */

    #ifndef GFX_T6963_DEFAULT_CONTROL_PORT
      #define GFX_T6963_DEFAULT_CONTROL_PORT    0x37A
    #endif /* ndef GFX_T6963_DEFAULT_CONTROL_PORT */

    #ifndef GFX_T6963_DEFAULT_CD_PIN
      #define GFX_T6963_DEFAULT_CD_PIN          SELECT_IN_17
    #endif /* ndef GFX_T6963_DEFAULT_CD_PIN */

    #ifndef GFX_T6963_DEFAULT_RD_PIN
      #define GFX_T6963_DEFAULT_RD_PIN          AUTOFEED_14
    #endif /* ndef GFX_T6963_DEFAULT_RD_PIN */

    #ifndef GFX_T6963_DEFAULT_WR_PIN
      #define GFX_T6963_DEFAULT_WR_PIN          INIT_16
    #endif /* nedef GFX_T6963_DEFAULT_WR_PIN */

    #ifndef GFX_T6963_DEFAULT_CE_PIN
      #define GFX_T6963_DEFAULT_CE_PIN          STROBE_1
    #endif /* ndef GFX_T6963_DEFAULT_CE_PIN */
  #endif /* def __linux__ */

  typedef struct {
    /* Param d'init */
    THD_addr_port_t addr_data_port, addr_control_port;
    #ifdef EMBEDDED
    THD_addr_port_t addr_data_control_port;
    #endif
    THD_bit_list_e cd_pin, rd_pin, wr_pin, ce_pin;
    /* \ Param d'init */
    THD_timing_t *timing;
    THD_port_t *data_port, *control_port;
    #ifdef EMBEDDED
    THD_port_t *data_control_port;
    #endif
    THD_bit_t *cd_bit, *rd_bit, *wr_bit, *ce_bit;

    THD_bool init;
  } THD_GFX_T6963_com1_t;

  #ifdef __cplusplus
  extern "C" {
  #endif

  #ifdef EMBEDDED
  THD_GFX_T6963_com1_t *GFX_T6963_CreateCom1 (THD_addr_port_t addr_data_port, THD_addr_port_t addr_data_control_port, THD_addr_port_t addr_control_port, THD_bit_list_e cd_pin, THD_bit_list_e rd_pin, THD_bit_list_e wr_pin, THD_bit_list_e ce_pin);
  #else
  THD_GFX_T6963_com1_t *GFX_T6963_CreateCom1 (THD_addr_port_t addr_data_port, THD_addr_port_t addr_control_port, THD_bit_list_e cd_pin, THD_bit_list_e rd_pin, THD_bit_list_e wr_pin, THD_bit_list_e ce_pin);
  #endif
  void *GFX_T6963_DestroyCom1 (THD_GFX_T6963_com1_t *com1);
  #ifdef __linux__
  THD_GFX_T6963_com1_t *GFX_T6963_InitCom1_Default (THD_addr_port_t addr_data_port, THD_addr_port_t addr_control_port);
  #endif
  THD_bool GFX_T6963_InitCom1 (THD_GFX_T6963_com1_t *com1);
  THD_bool GFX_T6963_RequestCom1_Init (THD_GFX_T6963_com1_t *com1);
  THD_bool GFX_T6963_SendData (THD_GFX_T6963_com1_t *com1, Uint8 data);
  Uint8 GFX_T6963_ReadData (THD_GFX_T6963_com1_t *com1);
  THD_bool GFX_T6963_SendCmd (THD_GFX_T6963_com1_t *com1, Uint8 command);
  Uint8 GFX_T6963_ReadStatus (THD_GFX_T6963_com1_t *com1);

  #ifdef __cplusplus
      }
  #endif

  #ifdef __GFX_T6963_COM1_C

    #ifndef EMBEDDED
      #define __THD_INCLUDE_MEMORY_ALLOC
    #endif
    #include "THD_include.h"

    #define VERBOSE_ID "#1 : "
    #define INIT com1->init

    #ifdef __linux__
      #define TEMPO
    #else
      /* #define TEMPO THD_Timing (com1->timing, 10) */
      #define TEMPO
    #endif

    #ifdef EMBEDDED
      #define NB_SINGLETON_COM1 (Uint8) 1
      THD_GFX_T6963_com1_t com1_pool[NB_SINGLETON_COM1];
      Uint8 singleton_com1_used=0;
    #endif

  #endif  /* def __GFX_T6963_COM1_C */

#endif /* ndef \ __GFX_T6963_COM1_H */
