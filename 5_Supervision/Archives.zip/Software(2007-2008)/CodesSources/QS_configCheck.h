#ifndef __QS_CONFIGCHECK_H
  #define __QS_CONFIGCHECK_H

  #if !(defined(DEBUG_MODE) || defined(TEST_MODE) || defined(MATCH_MODE))
	#error "Un mode de fonctionnement doit �tre s�lectionn�"
  #endif

  #ifndef I_AM
	#error "Il faut d�finir a quelle carte appartient le code"
  #endif

  #ifndef PORT_A_IO_MASK
    #error "Le port A n'est pas configur�"
  #endif
  #ifndef PORT_B_IO_MASK
    #error "Le port B n'est pas configur�"
  #endif
  #ifndef PORT_C_IO_MASK
    #error "Le port C n'est pas configur�"
  #endif
  #ifndef PORT_D_IO_MASK
    #error "Le port D n'est pas configur�"
  #endif
  #ifndef PORT_E_IO_MASK
    #error "Le port E n'est pas configur�"
  #endif
  #ifndef PORT_F_IO_MASK
    #error "Le port F n'est pas configur�"
  #endif
  #ifndef PORT_G_IO_MASK
    #error "Le port G n'est pas configur�"
  #endif

#endif
