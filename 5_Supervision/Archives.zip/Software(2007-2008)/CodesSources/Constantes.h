/*
 *  Club Robot ESEO 2007 - 2008
 *  PHOBOSS
 *
 *  Fichier : Constantes.h
 *  Package : SuperVision
 *  Description : constantes pour les fonctions d'affichage
 *  Auteur : Jacen
 *  Version 20080131
 */

#ifndef CONSTANTES_H
	#define CONSTANTES_H
	#define CAN_BUFFER_SIZE 0xFF
	#define NB_MSG_LCD 16

	#define	LCD_WIDTH		240
	#define LCD_HEIGHT		128
	#define BTN_NUMBER		6
	#define BTN_NUMBER_PRECONF		4
	#define BTN_NUMBER_CONFIG		3
	#define BTN_NUMBER_ENVOI		3
	#define BTN_NUMBER_STRATEG		4
	#define BTN_HEIGHT		14
	#define BTN_WIDTH		70
	#define SBTN_HEIGHT		14
	#define SBTN_WIDTH		110
	#define	BTN_OFFSET_Y	2
	#define MAX_TEXT_LEN	9
	#define MAX_STXT_LEN 	10
	#define MAX_CONFIG_LEN	9
	#define MAX_PRECONF_LEN	10
	#define MAX_STRATEG_LEN 10
	#define MAX_ENVOI_LEN	17
	#define MENU_POS_X		10
	#define MENU_POS_Y		5
	#define SMENU_POS_X		93
	#define SMENU_POS_Y		29
	#define SSBTN_HEIGHT    14
	#define SSBTN_WIDTH		60
	#define TITLE_POS_X		20
	#define TITLE_POS_Y		2
	#define STXT_POS_X		17
	#define STXT_POS_Y		5
#endif /*ndef CONSTANTES_H*/
