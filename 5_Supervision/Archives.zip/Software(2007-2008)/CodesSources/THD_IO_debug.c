/*
 *  THD_IO_debug.c: Debug/error functions
 *  Part of ThacidLCD package
 *  Copyright 2001-2005  Axel Voitier
 *  
 *  deadog@users.sourceforge.net
 *  
 *  This software is a computer program whose purpose is to control liquid crystal displays.
 *  
 *  This software is governed by the CeCILL  license under French law and
 *  abiding by the rules of distribution of free software.  You can  use, 
 *  modify and/ or redistribute the software under the terms of the CeCILL
 *  license as circulated by CEA, CNRS and INRIA at the following URL
 *  "http://www.cecill.info". 
 *  
 *  As a counterpart to the access to the source code and  rights to copy,
 *  modify and redistribute granted by the license, users are provided only
 *  with a limited warranty  and the software's author,  the holder of the
 *  economic rights,  and the successive licensors  have only  limited
 *  liability. 
 *  
 *  In this respect, the user's attention is drawn to the risks associated
 *  with loading,  using,  modifying and/or developing or reproducing the
 *  software by the user in light of its specific status of free software,
 *  that may mean  that it is complicated to manipulate,  and  that  also
 *  therefore means  that it is reserved for developers  and  experienced
 *  professionals having in-depth computer knowledge. Users are therefore
 *  encouraged to load and test the software's suitability as regards their
 *  requirements in conditions enabling the security of their systems and/or 
 *  data to be ensured and,  more generally, to use and operate it in the 
 *  same conditions as regards security. 
 *  
 *  The fact that you are presently reading this means that you have had
 *  knowledge of the CeCILL license and that you accept its terms.
 */

#define __THD_IO_DEBUG_C

#include "THD_IO_debug.h"


THD_bool
THD_SetDebugParam (
  settings_t parameter,
  void *value)
{
  
  switch(parameter) {
  #ifdef SHOW_ERROR
   case ERROR:
    ERROR_FILE = (FILE *) value;
    return THD_TRUE;
   break;
  #endif /* def SHOW_ERROR */
  #ifdef SHOW_VERBOSE
   case VERBOSE:
    VERBOSE_FILE = (FILE *) value;
    return THD_TRUE;
   break;
  #endif /* def SHOW_VERBOSE */
   default:
    #ifdef SHOW_ERROR
    THD_SetError ("THD_SetParam : wrong type of parameter (arg1)\n");
    #endif /* def SHOW_ERROR */
    return THD_FALSE;
  }
}

THD_bool
THD_SetError (
  char *string,
  ...)
{
  #ifdef SHOW_ERROR
    char vchar, *vstring=NULL;
    int vint;
    unsigned int vuint;
    double vdouble;
    void *vpoint;
    va_list pointArg;
    
    if(ERROR_FILE == NULL)
      return THD_FALSE;
    #ifdef SHOW_VERBOSE
    if(VERBOSE_FILE == NULL)
      return THD_FALSE;
    #endif /* def SHOW_VERBOSE */
    
    
    if(string == NULL) {
      THD_SetError ("THD_SetError: no string given (arg1) \n");
      return THD_FALSE;
    }
    
    memset(param.error_string, 0, sizeof(param.error_string));
    
    va_start (pointArg, string);
    
    for(char *pos=string ; *pos ; pos++) {
      if(*pos != '%') {
        sprintf(param.error_string, "%s%c", param.error_string, *pos);
        continue;
      }else{
        pos++;
        switch(*pos) {
        case 'c':
          vchar = (char) va_arg(pointArg, int);
          sprintf(param.error_string, "%s%c", param.error_string, vchar);
        break;
        case 'd':
          vint = va_arg(pointArg, int);
          sprintf(param.error_string, "%s%d", param.error_string, vint);
        break;
        case 'i':
          vint = va_arg(pointArg, int);
          sprintf(param.error_string, "%s%d", param.error_string, vint);
        break;
        case 'f':
          vdouble = va_arg(pointArg, double);
          sprintf(param.error_string, "%s%f", param.error_string, vdouble);
        break;
        case 's':
          vstring = va_arg(pointArg, char *);
          sprintf(param.error_string, "%s%s", param.error_string, vstring);
        break;
        case 'u':
          vuint = va_arg(pointArg, unsigned int);
          sprintf(param.error_string, "%s%u", param.error_string, vuint);
        break;
        case 'p':
          vpoint = va_arg(pointArg, void *);
          sprintf(param.error_string, "%s%p", param.error_string, vpoint);
        break;
        default:
          sprintf(param.error_string, "%s%%%c", param.error_string, *pos);
        }
      }
    }
    
    #ifdef SHOW_VERBOSE
    if(VERBOSE_FILE != NULL && VERBOSE_FILE != ERROR_FILE) {
      fprintf(VERBOSE_FILE, "#ERR : %s", param.error_string);
      fflush(VERBOSE_FILE);
    }
    #endif /* def SHOW_VERBOSE */
    
    if(ERROR_FILE != NULL) {
      fprintf(ERROR_FILE, "#ERR : %s", param.error_string);
      fflush(ERROR_FILE);
    }
    
    return THD_TRUE;
  #else /* ifdef SHOW_ERROR */
    return THD_FALSE;
  #endif /* def SHOW_ERROR, #else */
}

char *
THD_GetError (void) {
  #ifdef SHOW_ERROR
    return param.error_string;
  #else /* ifdef SHOW_ERROR */
    return NULL;
  #endif /* def SHOW_ERROR, #else */
}
