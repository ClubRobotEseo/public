#define __QS_PORTS_C

#include "QS_ports.h"

void ports_init (void) {
  Uint16 mask_a=PORT_A_IO_MASK;
  Uint16 mask_b=PORT_B_IO_MASK;
  Uint16 mask_c=PORT_C_IO_MASK;
  Uint16 mask_d=PORT_D_IO_MASK;
  Uint16 mask_e=PORT_E_IO_MASK;
  Uint16 mask_f=PORT_F_IO_MASK;
  Uint16 mask_g=PORT_G_IO_MASK;
  Uint16 mask_ad=0xFFFF;

  #ifdef USE_CAN1
    mask_f = (mask_f & 0xFFFC) | 0x0001;
  #endif
  #ifdef USE_CAN2
    mask_g = (mask_g & 0xFFFC) | 0x0001;
  #endif

  #ifdef USE_UART1
    mask_f = (mask_f & 0xFFF3) | 0x0004;
  #endif
  #ifdef USE_UART2
    mask_f = (mask_f & 0xFFCF) | 0x0010;
  #endif

  #ifdef USE_AN0
	CONFIG_ADPIN(mask_b, mask_ad, 0);
  #endif
  #ifdef USE_AN1
	CONFIG_ADPIN(mask_b, mask_ad, 1);
  #endif
  #ifdef USE_AN2
	CONFIG_ADPIN(mask_b, mask_ad, 2);
  #endif
  #ifdef USE_AN3
	CONFIG_ADPIN(mask_b, mask_ad, 3);
  #endif
  #ifdef USE_AN4
	CONFIG_ADPIN(mask_b, mask_ad, 4);
  #endif
  #ifdef USE_AN5
	CONFIG_ADPIN(mask_b, mask_ad, 5);
  #endif
  #ifdef USE_AN6
	CONFIG_ADPIN(mask_b, mask_ad, 6);
  #endif
  #ifdef USE_AN7
	CONFIG_ADPIN(mask_b, mask_ad, 7);
  #endif
  #ifdef USE_AN8
	CONFIG_ADPIN(mask_b, mask_ad, 8);
  #endif
  #ifdef USE_AN9
	CONFIG_ADPIN(mask_b, mask_ad, 9);
  #endif
  #ifdef USE_AN10
	CONFIG_ADPIN(mask_b, mask_ad, 10);
  #endif
  #ifdef USE_AN11
	CONFIG_ADPIN(mask_b, mask_ad, 11);
  #endif
  #ifdef USE_AN12
	CONFIG_ADPIN(mask_b, mask_ad, 12);
  #endif
  #ifdef USE_AN13
	CONFIG_ADPIN(mask_b, mask_ad, 13);
  #endif
  #ifdef USE_AN14
	CONFIG_ADPIN(mask_b, mask_ad, 14);
  #endif
  #ifdef USE_AN15
	CONFIG_ADPIN(mask_b, mask_ad, 15);
  #endif

  #ifdef USE_ANALOG_EXT_VREF
	mask_a |= 0x0600;
  #endif

  TRISA = mask_a;
  TRISB = mask_b;
  TRISC = mask_c;
  TRISD = mask_d;
  TRISE = mask_e;
  TRISF = mask_f;
  TRISG = mask_g;
  ADPCFG = mask_ad;
}
