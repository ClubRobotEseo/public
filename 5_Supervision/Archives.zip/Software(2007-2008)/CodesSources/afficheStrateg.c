#include "interface.h"

const char SWTxtStrateg[MAX_STXT_LEN] = {
     "Strategie"
};



void afficheStrateg(THD_struct *lcd, config* configOn) 
{
	extern Uint8 swBuffer;
	Uint8 smenu = 0;

	afficheTxtStrateg(lcd, configOn);

	while(1) 
	{
		if(isSWEvent(swBuffer)) 
		{
			switch(getSWEvent(swBuffer)) 
			{
				case MASK_TOP:    /* Actions pour haut*/
					LED_0 = !LED_0;
					if(isSWOn(MASK_TOP)) {
	    				if(smenu > 0) 
						{
		    				sous_undrawCurs(lcd, smenu);
		    				smenu--;
		    				sous_drawCurs(lcd, smenu);
		    			}
            		}
				break;
				case MASK_BOT:
					LED_0 = !LED_0;
					if(isSWOn(MASK_BOT)) {
						if(smenu < BTN_NUMBER_STRATEG-1) {
		    				sous_undrawCurs(lcd, smenu);
		    				smenu++;
		    				sous_drawCurs(lcd,smenu);
						}
            		}
				break;
				case MASK_VALID:
					LED_0 = !LED_0;
					if(isSWOn(MASK_VALID)) {
						LED_1 = 1;
						if(configOn->strateg != smenu) {
							unactive_choice(lcd, configOn->strateg);
							configOn->strateg = smenu;
							active_choice(lcd, configOn->strateg);
						}
					}
				break;
				case MASK_CANCEL:
					LED_0 = !LED_0;
					if(isSWOn(MASK_CANCEL)) {
						LED_1 = 0;
						clearScreen(lcd);
						return;
	   				}
				break;
				/*On met � jour le buffer*/
	      		swBuffer = SW_PORT;
			}
		}
	}
}

void afficheTxtStrateg(THD_struct *lcd, config* configOn) 
{
	Uint8 i;
	char aux[MAX_STXT_LEN+2];
	
	for(i=0; i<BTN_NUMBER_STRATEG; i++)
	{
		TXT_SetPos(lcd, THD_pos(STXT_POS_X,STXT_POS_Y+2*i));
		sprintf(aux,"%s %d",SWTxtStrateg, i);
		TXT_PrintString(lcd, aux);
		GFX_DrawFrame(lcd, THD_pos(SMENU_POS_X+1, SMENU_POS_Y+1+i*(SBTN_HEIGHT+BTN_OFFSET_Y)), THD_pos(SMENU_POS_X+SBTN_WIDTH-1, SMENU_POS_Y-1+i*(SBTN_HEIGHT+BTN_OFFSET_Y)+SBTN_HEIGHT), SET);
	}
	active_choice(lcd, configOn->strateg);
	sous_drawCurs(lcd,0);
}
