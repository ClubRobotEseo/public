/*
 *  THD_SYS_types.h: type definitions
 *  Part of ThacidLCD package
 *  Copyright 2001-2005  Axel Voitier
 *
 *  deadog@users.sourceforge.net
 *
 *  This software is a computer program whose purpose is to control liquid crystal displays.
 *
 *  This software is governed by the CeCILL  license under French law and
 *  abiding by the rules of distribution of free software.  You can  use,
 *  modify and/ or redistribute the software under the terms of the CeCILL
 *  license as circulated by CEA, CNRS and INRIA at the following URL
 *  "http://www.cecill.info".
 *
 *  As a counterpart to the access to the source code and  rights to copy,
 *  modify and redistribute granted by the license, users are provided only
 *  with a limited warranty  and the software's author,  the holder of the
 *  economic rights,  and the successive licensors  have only  limited
 *  liability.
 *
 *  In this respect, the user's attention is drawn to the risks associated
 *  with loading,  using,  modifying and/or developing or reproducing the
 *  software by the user in light of its specific status of free software,
 *  that may mean  that it is complicated to manipulate,  and  that  also
 *  therefore means  that it is reserved for developers  and  experienced
 *  professionals having in-depth computer knowledge. Users are therefore
 *  encouraged to load and test the software's suitability as regards their
 *  requirements in conditions enabling the security of their systems and/or
 *  data to be ensured and,  more generally, to use and operate it in the
 *  same conditions as regards security.
 *
 *  The fact that you are presently reading this means that you have had
 *  knowledge of the CeCILL license and that you accept its terms.
 */

#ifndef __THD_SYS_TYPES_H
  #define __THD_SYS_TYPES_H

  #ifndef NULL
    #define NULL 0
  #endif

  #ifdef __QS_TYPES_H /* Specifique au code du club robot de l'ESEO 07 - Game Hoover */
    typedef enum {
      THD_FALSE,
      THD_TRUE
    } THD_bool;

    #define UINT8_MAX 255
    #define UINT8_MIN 0
    #define SINT8_MAX 127
    #define SINT8_MIN (-128)
    #define UINT16_MAX 65535
    #define UINT16_MIN 0
    #define SINT16_MAX 32767
    #define SINT16_MIN (-32768)
    #define UINT32_MAX 4294967295U
    #define UINT32_MIN 0
    #define SINT32_MAX 2147483647
    #define SINT32_MIN (-SINT32_MAX - 1)
  #else
    typedef enum {
      THD_FALSE,
      THD_TRUE
    } THD_bool;


    typedef unsigned char Uint8;
    #define UINT8_MAX 255
    #define UINT8_MIN 0

    typedef signed char Sint8;
    #define SINT8_MAX 127
    #define SINT8_MIN (-128)

    typedef unsigned short Uint16;
    #define UINT16_MAX 65535
    #define UINT16_MIN 0

    typedef signed short Sint16;
    #define SINT16_MAX 32767
    #define SINT16_MIN (-32768)

    typedef unsigned long Uint32;
    #define UINT32_MAX 4294967295U
    #define UINT32_MIN 0

    typedef signed long Sint32;
    #define SINT32_MAX 2147483647
    #define SINT32_MIN (-SINT32_MAX - 1)
  #endif /* def __QS_TYPES_H, #else */

  typedef Uint16 THD_coord_t; /* Ne pas descendre en dessous de 16 */
  typedef Sint16 THD_Scoord_t; /* Ne pas descendre en dessous de 16 */

  typedef struct {
    THD_coord_t x;
    THD_coord_t y;
  } THD_pos_t;

  typedef struct {
    THD_Scoord_t x;
    THD_Scoord_t y;
  } THD_Spos_t;

  typedef enum {
    RESET,
    SET
  } SET_RESET_e;

  #ifdef __cplusplus
  extern "C" {
  #endif

  THD_pos_t THD_pos (THD_coord_t x, THD_coord_t y);
  THD_Spos_t THD_Spos (THD_Scoord_t x, THD_Scoord_t y);

  #ifdef __cplusplus
      }
  #endif

  #ifdef __THD_SYS_TYPES_C

  #endif /* def __THD_SYS_TYPES_C */

#endif /* ndef __THD_SYS_TYPES_H */

/*
====== system/.../THD_SYS_types ======

===== Summary =====

This file provided type definitions and functions relative to this.

===== Definitions =====

^  Return type  ^  Function name  ^  Arguments  ^
| **inline**  [[#THD_pos_t|THD_pos_t]] | [[#THD_pos|THD_pos]] | ([[#THD_coord_t|THD_coord_t]] x, [[#THD_coord_t|THD_coord_t]] y); |
| **inline**  [[#THD_Spos_t|THD_Spos_t]] | [[#THD_Spos|THD_Spos]] | ([[#THD_Scoord_t|THD_Scoord_t]] x, [[#THD_Scoord_t|THD_Scoord_t]] y); |

----

==== THD_bool ====

<code c>
typedef _Bool THD_bool;
#define THD_FALSE false
#define THD_TRUE true
</code>

//THD_bool// represent a boolean.\\
//THD_FALSE// is the wrong / 0 value.\\
//THAD_TRUE// is the right / 1 value.

In the linux implementation, booleans use the C99 type.

----

==== Uint8 ====

<code c>
typedef unsigned char Uint8;
#define UINT8_MAX UCHAR_MAX
#define UINT8_MIN 0
</code>

//Uint8// is a unsigned interger value on one byte.
//UINT8_MAX// represent the maximum interger value for an Uint8.
//UINT8_MIN// represent the minimum interger value for an Uint8.

----

==== Sint8 ====

<code c>
typedef signed char Sint8;
#define SINT8_MAX SCHAR_MAX
#define SINT8_MIN SCHAR_MIN
</code>

//Sint8// is a signed interger value on one byte.
//SINT8_MAX// represent the maximum interger value for an Sint8.
//SINT8_MIN// represent the minimum interger value for an Sint8.

----

==== Uint16 ====

<code c>
typedef unsigned short Uint16;
#define UINT16_MAX USHRT_MAX
#define UINT16_MIN 0
</code>

//Uint16// is a unsigned interger value on two bytes.
//UINT16_MAX// represent the maximum interger value for an Uint16.
//UINT16_MIN// represent the minimum interger value for an Uint16.

----

==== Sint16 ====

<code c>
typedef signed short Sint16;
#define SINT16_MAX SHRT_MAX
#define SINT16_MIN SHRT_MIN
</code>

//Sint16// is a signed interger value on two bytes.
//SINT16_MAX// represent the maximum interger value for an Sint16.
//SINT16_MIN// represent the minimum interger value for an Sint16.

----

==== Uint32 ====

<code c>
typedef unsigned int Uint32;
#define UINT32_MAX UINT_MAX
#define UINT32_MIN 0
</code>

//Uint32// is a unsigned interger value on four bytes.
//UINT32_MAX// represent the maximum interger value for an Uint32.
//UINT32_MIN// represent the minimum interger value for an Uint32.

----

==== Sint32 ====

<code c>
typedef signed int Sint32;
#define SINT32_MAX INT_MAX
#define SINT32_MIN INT_MIN
</code>

//Sint32// is a signed interger value on four bytes.
//SINT32_MAX// represent the maximum interger value for an Sint32.
//SINT32_MIN// represent the minimum interger value for an Sint32.

----

==== THD_coord_t ====

<code c>
typedef Uint16 THD_coord_t;
</code>

//THD_coord_t// is the type for an unsigned coordinate (one dimension location on the screen).\\
Directly depend to the maximum depth that a controller can support.

----

==== THD_Scoord_t ====

<code c>
typedef Sint16 THD_Scoord_t;
</code>

//THD_Scoord_t// is the type for a signed coordinate (one dimension location on the screen).\\
Directly depend to the maximum depth that a controller can support.

----

==== THD_pos_t ====

<code c>
typedef struct {
  THD_coord_t x;
  THD_coord_t y;
} THD_pos_t;
</code>

//THD_pos_t// is the type for an unsigned position (two dimensions location on the screen).

//THD_pos_t.x// is the X-coordinate (width).\\
//THD_pos_t.y// is the Y-coordinate (height).

----

==== THD_Spos_t ====

<code c>
typedef struct {
  THD_Scoord_t x;
  THD_Scoord_t y;
} THD_Spos_t;
</code>

//THD_Spos_t// is the type for a signed position (two dimensions location on the screen).

//THD_Spos_t.x// is the X-coordinate (width).\\
//THD_Spos_t.y// is the Y-coordinate (height).

----

==== SET_RESET_e ====

<code c>
typedef enum {
  RESET,
  SET
} SET_RESET_e;
</code>

//SET_RESET_e// is the type for the status of one pixel (in a two colors mode).

//RESET// is the off status of a pixel.\\
//SET// is the on status of a pixel.

===== Functions =====

==== THD_pos ====

<code c>
inline THD_pos_t
THD_pos (
  THD_coord_t x,
  THD_coord_t y)
</code>

This function make the translation between two unsigned coordinates, //x// and //y//, and one position.

//x// is the unsigned X-coordinate (width).\\
//y// is the unsigned Y-coordinate (height).\\

Returns an unsigned position correspond to the two coordinates.

----

==== THD_Spos ====

<code c>
inline THD_Spos_t
THD_Spos (
  THD_Scoord_t x,
  THD_Scoord_t y)
</code>

This function make the translation between two signed coordinates, //x// and //y//, and one position.

//x// is the signed X-coordinate (width).\\
//y// is the signed Y-coordinate (height).\\

Returns a signed position correspond to the two coordinates.

----

 --- //[[lexa@nerim.net|Axel Voitier (deadog)]] 2005/07/18 07:13//
*/
