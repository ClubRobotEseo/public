/*Environnement leds et sw*/
#ifndef LEDS_H
#define LEDS_H

#define LED_0 PORTBbits.RB6
#define LED_1 PORTBbits.RB7
#define SW_PORT	((PORTB>>2) & 0x0F)

#endif
