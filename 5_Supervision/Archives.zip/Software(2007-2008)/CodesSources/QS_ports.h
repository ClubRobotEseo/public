#ifndef __QS_PORTS_H
  #define __QS_PORTS_H

  #include "QS_all.h"

  void ports_init (void);

  #ifdef __QS_PORTS_C

    #define CONFIG_ADPIN(reg_port, reg_ad, pin) { \
		reg_port |= 1 << pin; \
		reg_ad &= ~(1 << pin); \
	}

  #endif

#endif
