#define __INTERFACE_C

#include "interface.h"


/* tableau d�clar� dans afficheMenu.c */
extern const char SWTxt[BTN_NUMBER][MAX_TEXT_LEN];



/********************************** FUNCTIONS ************************************************/

void clearScreen(THD_struct *lcd)
{
	TXT_ClearScreen(lcd);
	GFX_ClearScreen(lcd);
}

void affichePret(THD_struct *lcd, config* configOn) 
{
	clearScreen (lcd);
	/*TXT_SetPos(lcd, THD_pos(16,8));
	TXT_PrintString(lcd, " GAME HOOVER");*/
}

void drawCurs(THD_struct *lcd, Uint8 page)
{
	GFX_DrawFrame(lcd, THD_pos(MENU_POS_X, MENU_POS_Y+page*(BTN_HEIGHT+BTN_OFFSET_Y)), THD_pos(MENU_POS_X+BTN_WIDTH, MENU_POS_Y+page*(BTN_HEIGHT+BTN_OFFSET_Y)+BTN_HEIGHT), SET);
}

void sous_drawCursDouble(THD_struct *lcd, Uint8 sous_menu_select)
{
	GFX_DrawFrame(lcd, THD_pos(SMENU_POS_X, SMENU_POS_Y+sous_menu_select*2*(SBTN_HEIGHT+BTN_OFFSET_Y)), THD_pos(SMENU_POS_X+SBTN_WIDTH, SMENU_POS_Y+sous_menu_select*2*(SBTN_HEIGHT+BTN_OFFSET_Y)+SBTN_HEIGHT), SET);
}

void sous_drawCurs(THD_struct *lcd, Uint8 sous_menu_select) {
	GFX_DrawFrame(lcd, THD_pos(SMENU_POS_X, SMENU_POS_Y+sous_menu_select*(SBTN_HEIGHT+BTN_OFFSET_Y)), THD_pos(SMENU_POS_X+SBTN_WIDTH, SMENU_POS_Y+sous_menu_select*(SBTN_HEIGHT+BTN_OFFSET_Y)+SBTN_HEIGHT), SET);
}

void undrawCurs(THD_struct *lcd, Uint8 page)
{
	GFX_DrawFrame(lcd, THD_pos(MENU_POS_X, MENU_POS_Y+page*(BTN_HEIGHT+BTN_OFFSET_Y)), THD_pos(MENU_POS_X+BTN_WIDTH, MENU_POS_Y+page*(BTN_HEIGHT+BTN_OFFSET_Y)+BTN_HEIGHT), RESET);
}

void sous_undrawCurs(THD_struct *lcd, Uint8 sous_menu_select)
{
	GFX_DrawFrame(lcd, THD_pos(SMENU_POS_X, SMENU_POS_Y+sous_menu_select*(SBTN_HEIGHT+BTN_OFFSET_Y)), THD_pos(SMENU_POS_X+SBTN_WIDTH, SMENU_POS_Y+sous_menu_select*(SBTN_HEIGHT+BTN_OFFSET_Y)+SBTN_HEIGHT), RESET);
}

void sous_undrawCursDouble(THD_struct *lcd, Uint8 sous_menu_select)
{
	GFX_DrawFrame(lcd, THD_pos(SMENU_POS_X, SMENU_POS_Y+sous_menu_select*2*(SBTN_HEIGHT+BTN_OFFSET_Y)), THD_pos(SMENU_POS_X+SBTN_WIDTH, SMENU_POS_Y+sous_menu_select*2*(SBTN_HEIGHT+BTN_OFFSET_Y)+SBTN_HEIGHT), RESET);
}

void printTitle(THD_struct *lcd, Uint8 page)
{
	TXT_SetPos(lcd, THD_pos(TITLE_POS_X,TITLE_POS_Y));
	TXT_PrintString(lcd, SWTxt[page]);
}

void eraseTitle(THD_struct *lcd)
{
	const char emptyString[MAX_TEXT_LEN] = "     ";
	TXT_SetPos(lcd, THD_pos(TITLE_POS_X,TITLE_POS_Y));
	TXT_PrintString(lcd, emptyString);
}

void active_choice(THD_struct *lcd, Uint8 smenu) {
	const char string[2] = "#";
	TXT_SetPos(lcd, THD_pos(STXT_POS_X+MAX_STXT_LEN+4,STXT_POS_Y+2*smenu));
	TXT_PrintString(lcd, string);
}

void unactive_choice(THD_struct *lcd, Uint8 smenu) 
{
	const char emptyString[2] = " ";
	TXT_SetPos(lcd, THD_pos(STXT_POS_X+MAX_STXT_LEN+4,STXT_POS_Y+2*smenu));
	TXT_PrintString(lcd, emptyString);
}


void ssous_undrawCursDouble(THD_struct *lcd, Uint8 ligne, Uint8 valeur)
{
	GFX_DrawFrame(lcd, THD_pos(SMENU_POS_X+(SSBTN_WIDTH+BTN_OFFSET_Y)*valeur, SMENU_POS_Y+(((ligne*2)+1)*(SSBTN_HEIGHT+BTN_OFFSET_Y))), THD_pos(SMENU_POS_X+SSBTN_WIDTH+(SSBTN_WIDTH+BTN_OFFSET_Y)*valeur,SMENU_POS_Y+((ligne*2)+1)*(SSBTN_HEIGHT+BTN_OFFSET_Y)+SSBTN_HEIGHT), RESET);	
}

void ssous_drawCursDouble(THD_struct *lcd, Uint8 ligne, Uint8 valeur)
{
	GFX_DrawFrame(lcd, THD_pos(SMENU_POS_X+(SSBTN_WIDTH+BTN_OFFSET_Y)*valeur, SMENU_POS_Y+(((ligne*2)+1)*(SSBTN_HEIGHT+BTN_OFFSET_Y))), THD_pos(SMENU_POS_X+SSBTN_WIDTH+(SSBTN_WIDTH+BTN_OFFSET_Y)*valeur,SMENU_POS_Y+((ligne*2)+1)*(SSBTN_HEIGHT+BTN_OFFSET_Y)+SSBTN_HEIGHT), SET);
}


Uint8 swBuffer = 0x0F;
