#ifndef _DELAY_H_
#define _DELAY_H_
#include "QS_config.h"
#include "QS_types.h"

void DelayUs(Uint32 cpt);
void DelayMs(Uint32 cpt);

#endif
