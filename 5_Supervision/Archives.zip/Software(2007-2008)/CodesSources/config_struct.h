/*
 *  Club Robot ESEO 2007 - 2008
 *  PHOBOSS
 *
 *  Fichier : Constantes.h
 *  Package : SuperVision
 *  Description : structure de configuration du robot
 *  Auteur : Jacen
 *  Version 20080131
 */

#ifndef __CONFIG_STRUCT__
	#define __CONFIG_STRUCT__

	typedef struct 
	{
		Uint8 couleur;				/* 0=rouge, 1=bleue */
		Uint8 preconf;				/* numero de la configuration pr�d�finie 0 - 1 - 2 - 3 */
		Uint8 stock_flash;			/* 0=non, 1=oui */
		Uint8 envoi_can_zigbee;		/* 0=non, 1=oui */
		Uint8 envoi_can_serie;		/* 0=non, 1=oui   -> rs232 */
		Uint8 strateg;				/* numero de la strategie 0 - 1 - 2 - 3 - 4 */
		Uint8 clicodrome;			/* 0=mode normal, 1=recoit ordres par uart */
		Uint8 recalage;             /* 0=non, 1=oui  -> Suivant la couleur s�lectionn�e, le robot se placera au mieux pour le d�part */
		Uint8 lecture_can;          /* 0=non, 1=oui  -> Permet d�afficher � l��cran les messages CAN re�us pendant le match */
	} config;
#endif /* ndef __CONFIG_STRUCT__ */
