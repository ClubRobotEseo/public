/*
 *  GFX_T6963_com2.h: header file for specific T6963 functions level
 *  Part of ThacidLCD package
 *  Copyright 2001-2005  Axel Voitier
 *  
 *  deadog@users.sourceforge.net
 *  
 *  This software is a computer program whose purpose is to control liquid crystal displays.
 *  
 *  This software is governed by the CeCILL  license under French law and
 *  abiding by the rules of distribution of free software.  You can  use, 
 *  modify and/ or redistribute the software under the terms of the CeCILL
 *  license as circulated by CEA, CNRS and INRIA at the following URL
 *  "http://www.cecill.info". 
 *  
 *  As a counterpart to the access to the source code and  rights to copy,
 *  modify and redistribute granted by the license, users are provided only
 *  with a limited warranty  and the software's author,  the holder of the
 *  economic rights,  and the successive licensors  have only  limited
 *  liability. 
 *  
 *  In this respect, the user's attention is drawn to the risks associated
 *  with loading,  using,  modifying and/or developing or reproducing the
 *  software by the user in light of its specific status of free software,
 *  that may mean  that it is complicated to manipulate,  and  that  also
 *  therefore means  that it is reserved for developers  and  experienced
 *  professionals having in-depth computer knowledge. Users are therefore
 *  encouraged to load and test the software's suitability as regards their
 *  requirements in conditions enabling the security of their systems and/or 
 *  data to be ensured and,  more generally, to use and operate it in the 
 *  same conditions as regards security. 
 *  
 *  The fact that you are presently reading this means that you have had
 *  knowledge of the CeCILL license and that you accept its terms.
 */

#ifndef __GFX_T6963_COM2_H
  #define __GFX_T6963_COM2_H
  
  #include "THD_system.h"
  #include "GFX_T6963_com1.h"

  /* PUBLIC */

  /* REGISTER SETTING */
  typedef enum {
    GFX_T6963_SET_CURSOR_POINTER,
    GFX_T6963_SET_OFFSET_REGISTER,
    GFX_T6963_SET_ADDRESS_POINTER
  } THD_GFX_T6963_Register_Setting_e;
  
  /* SET CONTROL WORD */
  typedef enum {
    GFX_T6963_SET_TEXT_HOME_ADDRESS,
    GFX_T6963_SET_TEXT_AREA,
    GFX_T6963_SET_GRAPHIC_HOME_ADDRESS,
    GFX_T6963_SET_GRAPHIC_AREA
  } THD_GFX_T6963_Set_Control_Word_e;
  
  /* MODE SET */
  typedef enum {
    GFX_T6963_OR_MODE,
    GFX_T6963_EXOR_MODE,
    GFX_T6963_AND_MODE,
    GFX_T6963_TEXT_ATTRIBUTE_MODE
  } THD_GFX_T6963_Mode_Set_Logical_e;
  typedef enum {
    GFX_T6963_INTERNAL_CGROM_MODE,
    GFX_T6963_EXTERNAL_CGRAM_MODE
  } THD_GFX_T6963_Mode_Set_CG_e;
  
  /* DISPLAY MODE */
  typedef enum {
    GFX_T6963_DISPLAY_OFF,
    GFX_T6963_DISPLAY_ON
  } THD_GFX_T6963_Display_Mode_State_e;
  typedef enum {
    GFX_T6963_CURSOR_OFF,
    GFX_T6963_CURSOR_ON_BLINK_OFF,
    GFX_T6963_CURSOR_ON_BLINK_ON
  } THD_GFX_T6963_Display_Mode_Cursor_e;
  typedef enum {
    GFX_T6963_DISPLAY_TYPE_TEXT,
    GFX_T6963_DISPLAY_TYPE_GRAPHIC,
    GFX_T6963_DISPLAY_TYPE_BOTH
  } THD_GFX_T6963_Display_Mode_Type_e;
  
  /* DATA AUTO RW */
  typedef enum {
    GFX_T6963_DATA_AUTO_WRITE,
    GFX_T6963_DATA_AUTO_READ,
    GFX_T6963_DATA_AUTO_RESET
  } THD_GFX_T6963_Data_Auto_RW_e;
  
  /* DATA RW */
  typedef enum {
    GFX_T6963_DATA_WRITE_ISZ,
    GFX_T6963_DATA_WRITE_DSZ,
    GFX_T6963_DATA_WRITE_FIX,
    GFX_T6963_DATA_READ_ISZ,
    GFX_T6963_DATA_READ_DSZ = 5,
    GFX_T6963_DATA_READ_FIX = 6
  } THD_GFX_T6963_Data_RW_e;

  typedef enum {
    GFX_T6963_SEND_NODATA,
    GFX_T6963_SEND_1DATA,
    GFX_T6963_SEND_2DATAS
  } THD_GFX_T6963_Command_Data_e;

  /* Defaults */
  #ifndef GFX_T6963_DEFAULT_FONT_WIDTH
    #define GFX_T6963_DEFAULT_FONT_WIDTH	8
  #endif /* ndef GFX_T6963_DEFAULT_FONT_WIDTH */
  
  #ifndef GFX_T6963_DEFAULT_LOGICAL_MODE
    #define GFX_T6963_DEFAULT_LOGICAL_MODE	GFX_T6963_OR_MODE
  #endif /* ndef GFX_T6963_DEFAULT_LOGICAL_MODE */
  
  #ifndef GFX_T6963_DEFAULT_CG_MODE
    #define GFX_T6963_DEFAULT_CG_MODE		GFX_T6963_INTERNAL_CGROM_MODE
  #endif /* ndef GFX_T6963_DEFAULT_CG_MODE */
  
  #ifndef GFX_T6963_DEFAULT_CURSOR_MODE
    #define GFX_T6963_DEFAULT_CURSOR_MODE	GFX_T6963_CURSOR_OFF
  #endif /* ndef GFX_T6963_DEFAULT_CURSOR_MODE */
  
  #ifndef GFX_T6963_DEFAULT_DISPLAY_TYPE
    #define GFX_T6963_DEFAULT_DISPLAY_TYPE	GFX_T6963_DISPLAY_TYPE_BOTH
  #endif /* ndef GFX_T6963_DEFAULT_DISPLAY_TYPE */
  
  #ifndef GFX_T6963_DEFAULT_CURSOR_LINE
    #define GFX_T6963_DEFAULT_CURSOR_LINE	8
  #endif /* ndef GFX_T6963_DEFAULT_CURSOR_LINE */

  typedef struct {
    Uint8 font_width;
    Uint8 font_height;
    Uint16 txt_home;
    Uint8 txt_area;
    THD_pos_t txt_size;
    Uint16 gfx_home;
    Uint8 gfx_area;
    THD_pos_t gfx_size;
    Uint8 logical, cg; /* mode_set */
    Uint8 cursor, display_type; /* diplay_mode */
    Uint8 cursor_line;
  /*  // Start from 1, not 0.
    str_GFX_T6963_position last_pos;
  */
    THD_GFX_T6963_com1_t *com1;
    THD_bool init;
  } THD_GFX_T6963_com2_t;

  
  #ifdef __cplusplus
  extern "C" {
  #endif

  THD_GFX_T6963_com2_t *GFX_T6963_CreateCom2 (THD_GFX_T6963_com1_t *com1, THD_pos_t gfx_size, Uint8 font_width, Uint8 logical, Uint8 cg, Uint8 cursor, Uint8 display_type, Uint8 cursor_line);
  void *GFX_T6963_DestroyCom2 (THD_GFX_T6963_com2_t *com2);
  THD_GFX_T6963_com2_t *GFX_T6963_InitCom2_Default (THD_GFX_T6963_com1_t *com1, THD_pos_t gfx_size, Uint8 font_width);
  THD_bool GFX_T6963_InitCom2 (THD_GFX_T6963_com2_t *com2);
  THD_bool GFX_T6963_RequestCom2_Init (THD_GFX_T6963_com2_t *com2);
  #ifndef __c18__
	#ifndef dsPIC30
	#define inline /* dsPIC30 not defindes when using strict ANSI-C 89 */
	#endif
    inline Uint8 GFX_T6963_GetUpperByte (Uint16 data);
    inline Uint8 GFX_T6963_GetLowerByte (Uint16 data);
  #else
    Uint8 GFX_T6963_GetUpperByte (Uint16 data);
    Uint8 GFX_T6963_GetLowerByte (Uint16 data);
  #endif
  THD_bool GFX_T6963_RegistersSetting (THD_GFX_T6963_com2_t *com2, THD_GFX_T6963_Register_Setting_e mode, Uint8 d1, Uint8 d2);
  THD_bool GFX_T6963_SetControlWord (THD_GFX_T6963_com2_t *com2, THD_GFX_T6963_Set_Control_Word_e mode, Uint8 d1, Uint8 d2);
  THD_bool GFX_T6963_ModeSet (THD_GFX_T6963_com2_t *com2, THD_GFX_T6963_Mode_Set_Logical_e logical, THD_GFX_T6963_Mode_Set_CG_e cg);
  THD_bool GFX_T6963_DisplayMode (THD_GFX_T6963_com2_t *com2, THD_GFX_T6963_Display_Mode_State_e state, THD_GFX_T6963_Display_Mode_Cursor_e cursor, THD_GFX_T6963_Display_Mode_Type_e type);
  THD_bool GFX_T6963_CursorPatternSelect (THD_GFX_T6963_com2_t *com2, Uint8 line);
  THD_bool GFX_T6963_DataAutoRW (THD_GFX_T6963_com2_t *com2, THD_GFX_T6963_Data_Auto_RW_e mode);
  THD_bool GFX_T6963_DataRW (THD_GFX_T6963_com2_t *com2, THD_GFX_T6963_Data_RW_e mode, Uint8 data, Uint8 *result);
  THD_bool GFX_T6963_BitSetReset (THD_GFX_T6963_com2_t *com2, SET_RESET_e mode, Uint8 bit);
  THD_bool GFX_T6963_BitSetReset_AutoData (THD_GFX_T6963_com2_t *com2, SET_RESET_e mode, Uint8 bit);
  THD_bool GFX_T6963_AutoDataSend (THD_GFX_T6963_com2_t *com2, Uint8 data);
  THD_bool GFX_T6963_AutoDataRead (THD_GFX_T6963_com2_t *com2, Uint8 *result);
  
  #ifdef __cplusplus
      }
  #endif

  /* PRIVATE */
  
  #ifdef __GFX_T6963_COM2_C

	#ifndef EMBEDDED
      #define __THD_INCLUDE_MEMORY_ALLOC
	#endif
    #include "THD_include.h"
    
    #define VERBOSE_ID "#2 : "
    #define GFX_T6963_FONT_HEIGHT 8
    
    #define INIT com2->init

	#ifdef EMBEDDED
	  #define NB_SINGLETON_COM2 (Uint8) 1
	  THD_GFX_T6963_com2_t com2_pool[NB_SINGLETON_COM2];
	  Uint8 singleton_com2_used=0;
	#endif

  #endif /* def __GFX_T6963_COM2_C */

#endif /* ndef __GFX_T6963_COM2_H */
