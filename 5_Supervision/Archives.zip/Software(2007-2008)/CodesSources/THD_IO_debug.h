/*
 *  THD_IO_debug.h: header file for debug/error functions
 *  Part of ThacidLCD package
 *  Copyright 2001-2005  Axel Voitier
 *  
 *  deadog@users.sourceforge.net
 *  
 *  This software is a computer program whose purpose is to control liquid crystal displays.
 *  
 *  This software is governed by the CeCILL  license under French law and
 *  abiding by the rules of distribution of free software.  You can  use, 
 *  modify and/ or redistribute the software under the terms of the CeCILL
 *  license as circulated by CEA, CNRS and INRIA at the following URL
 *  "http://www.cecill.info". 
 *  
 *  As a counterpart to the access to the source code and  rights to copy,
 *  modify and redistribute granted by the license, users are provided only
 *  with a limited warranty  and the software's author,  the holder of the
 *  economic rights,  and the successive licensors  have only  limited
 *  liability. 
 *  
 *  In this respect, the user's attention is drawn to the risks associated
 *  with loading,  using,  modifying and/or developing or reproducing the
 *  software by the user in light of its specific status of free software,
 *  that may mean  that it is complicated to manipulate,  and  that  also
 *  therefore means  that it is reserved for developers  and  experienced
 *  professionals having in-depth computer knowledge. Users are therefore
 *  encouraged to load and test the software's suitability as regards their
 *  requirements in conditions enabling the security of their systems and/or 
 *  data to be ensured and,  more generally, to use and operate it in the 
 *  same conditions as regards security. 
 *  
 *  The fact that you are presently reading this means that you have had
 *  knowledge of the CeCILL license and that you accept its terms.
 */

#ifndef __THD_IO_DEBUG_H
  #define __THD_IO_DEBUG_H
  
  #include "THD_SYS_types.h"
  
  #ifdef SHOW_VERBOSE
    #include <stdio.h>
    #define VERBOSE_FILE param.verb_file
    
    #define THD_VERBOSE(...) { \
      if(VERBOSE_FILE != NULL) { \
        fprintf(VERBOSE_FILE, VERBOSE_ID __VA_ARGS__); \
        fflush(VERBOSE_FILE); \
      } \
    }
  #else
	/*#define THD_VERBOSE(...) (void)0 //ceci est du C99 */
	#define THD_VERBOSE /* en ANSI-C89, ISO C90 */
  #endif /* SHOW_VERBOSE */
  
  #ifdef SHOW_ERROR  
    #include <stdio.h>
    #define __ALLOC_ERROR__ "memory allocation failed"
    #define ERROR_FILE param.error_file
    
    #define THD_ERROR(msg) { \
      THD_SetError __VA_ARGS__ ; \
    }
  #else
    #define THD_ERROR(msg) (void)0
  #endif /* SHOW_ERROR */
  
  #if defined(SHOW_ERROR) || defined(SHOW_VERBOSE)
    typedef struct {
      #ifdef SHOW_VERBOSE
      FILE *verb_file;
      #endif /* SHOW_VERBOSE */
      
      #ifdef SHOW_ERROR
      char error_string[BUFSIZ];
      FILE *error_file;
      #endif /* SHOW_ERROR */
    } THD_param_t;
    
    THD_param_t param;
  #endif /* SHOW_ERROR || SHOW_VERBOSE */

  
  typedef enum {
    VERBOSE,
    ERROR
  } settings_t;
  
  #ifdef __cplusplus
  extern "C" {
  #endif
  
  THD_bool THD_SetDebugParam (settings_t parameter, void *value);
  
  THD_bool THD_SetError (char *string, ...);
  char *THD_GetError (void);
  
  #ifdef __cplusplus
      }
  #endif
  
  #ifdef __THD_IO_DEBUG_C
  
  /* Ou pas
    #include <stdlib.h>
    #ifdef SHOW_ERROR
      #include <string.h>
      #include <stdarg.h>
    #endif // SHOW_ERROR
    #ifdef SHOW_VERBOSE
      #include <stdio.h>
    #endif
  */
  
  #endif /* def __THD_IO_DEBUG_C */

#endif /* ndef __THD_IO_DEBUG_H */
 
 
 
