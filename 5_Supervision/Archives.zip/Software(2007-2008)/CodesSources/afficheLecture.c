#include "interface.h"

void afficheLecture(THD_struct *lcd) 
{
	printf("hello world !\n");
}
