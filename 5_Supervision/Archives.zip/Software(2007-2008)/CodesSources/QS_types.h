/*
 *  Club Robot ESEO 2006 - 2007
 *  Game Hoover
 *
 *  Fichier : QS_types.h
 *  Package : Qualit� Soft
 *  Description : D�finition des types pour tout code du robot
 *  Auteur : Axel Voitier (et un peu savon aussi)
 *  Version 20070129
 */

#ifndef __QS_TYPES_H
  #define __QS_TYPES_H

  #if defined(MATCH_MODE) || defined(TEST_MODE)
    /* Type de base pour le dsPIC */
    typedef unsigned char Uint8;
    typedef signed char Sint8;
    typedef unsigned short Uint16;
    typedef signed short Sint16;
    typedef unsigned long Uint32;
    typedef signed long Sint32;

    typedef enum e_bool {
      FALSE,
      TRUE
    } t_bool;
	
	typedef struct {
		Uint16 sid;
		Uint8 dataReceive[8];
		Uint8 taille;
	}mess_CAN;
	
	
  #elif defined(DEBUG_MODE)

  #endif

#endif
