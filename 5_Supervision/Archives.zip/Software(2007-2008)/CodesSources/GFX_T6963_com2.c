/*
 *  GFX_T6963_com2.c: specific T6963 functions level
 *  Part of ThacidLCD package
 *  Copyright 2001-2005  Axel Voitier
 *  
 *  deadog@users.sourceforge.net
 *  
 *  This software is a computer program whose purpose is to control liquid crystal displays.
 *  
 *  This software is governed by the CeCILL  license under French law and
 *  abiding by the rules of distribution of free software.  You can  use, 
 *  modify and/ or redistribute the software under the terms of the CeCILL
 *  license as circulated by CEA, CNRS and INRIA at the following URL
 *  "http://www.cecill.info". 
 *  
 *  As a counterpart to the access to the source code and  rights to copy,
 *  modify and redistribute granted by the license, users are provided only
 *  with a limited warranty  and the software's author,  the holder of the
 *  economic rights,  and the successive licensors  have only  limited
 *  liability. 
 *  
 *  In this respect, the user's attention is drawn to the risks associated
 *  with loading,  using,  modifying and/or developing or reproducing the
 *  software by the user in light of its specific status of free software,
 *  that may mean  that it is complicated to manipulate,  and  that  also
 *  therefore means  that it is reserved for developers  and  experienced
 *  professionals having in-depth computer knowledge. Users are therefore
 *  encouraged to load and test the software's suitability as regards their
 *  requirements in conditions enabling the security of their systems and/or 
 *  data to be ensured and,  more generally, to use and operate it in the 
 *  same conditions as regards security. 
 *  
 *  The fact that you are presently reading this means that you have had
 *  knowledge of the CeCILL license and that you accept its terms.
 */

#define __GFX_T6963_COM2_C

#include "GFX_T6963_com2.h"


static THD_bool command_data (THD_GFX_T6963_com2_t *com2, Uint8 data1, Uint8 data2, Uint8 command, THD_GFX_T6963_Command_Data_e mode);
static THD_bool check_status (THD_GFX_T6963_com2_t *com2);
static THD_bool check_status_auto (THD_GFX_T6963_com2_t *com2);


THD_GFX_T6963_com2_t *
GFX_T6963_CreateCom2 (
  THD_GFX_T6963_com1_t *com1,
  THD_pos_t gfx_size,
  Uint8 font_width,
  Uint8 logical, Uint8 cg, /* mode_set */
  Uint8 cursor, Uint8 display_type, /* display_mode */
  Uint8 cursor_line)
{

  /*
   *  Impl�menter des v�rifications plus pouss�es sur la m�moire (<=64Kb ; Single-Scan / Double-Scan ; ...)
   */

  THD_GFX_T6963_com2_t *com2=NULL;
  Uint16 txt_home, gfx_home;
  Uint8 area;
  THD_pos_t txt_size;
  
  THD_CHECK ( , (com1 == NULL) || !gfx_size.y  || !gfx_size.x || !font_width || ((font_width != (Uint8) 6) && (font_width != (Uint8) 8)) ,
    return NULL;
  )
     
  #ifndef EMBEDDED
    THD_CHECK ( (com2 = (THD_GFX_T6963_com2_t *) calloc(1, sizeof(THD_GFX_T6963_com2_t))) , == NULL ,
      THD_ERROR ("GFX_T6963_CreateCom2 : "__ALLOC_ERROR__"\n");
      return NULL;
    )
  #else
    THD_CHECK ( singleton_com2_used, == NB_SINGLETON_COM2,
	  THD_ERROR ("GFX_T6963_CreateCom2 : no singleton com2 available\n");
	  return NULL;
	)
	com2 = &com2_pool[singleton_com2_used++];
  #endif
  
  if(!logical)
    logical = GFX_T6963_DEFAULT_LOGICAL_MODE;
  if(!cg)
    cg = GFX_T6963_DEFAULT_CG_MODE;
  if(!cursor)
    cursor = GFX_T6963_DEFAULT_CURSOR_MODE;
  if(!display_type)
    display_type = GFX_T6963_DEFAULT_DISPLAY_TYPE;  
  if(!cursor_line)
    cursor_line = GFX_T6963_DEFAULT_CURSOR_LINE;
    
  txt_size.y = gfx_size.y / GFX_T6963_FONT_HEIGHT;
  txt_size.x = gfx_size.x / font_width;
  if((gfx_size.x % font_width) != (Uint8) 0)
    area = txt_size.x + 1;
  else
    area = txt_size.x;
  
  txt_home = 0;
  gfx_home = area * txt_size.y;
  
  com2->font_width = font_width;
  com2->font_height = GFX_T6963_FONT_HEIGHT;
  com2->txt_home = txt_home;
  com2->txt_area = area;
  com2->txt_size = txt_size;
  com2->gfx_home = gfx_home;
  com2->gfx_area = area;
  com2->gfx_size = gfx_size;
  com2->logical = logical;
  com2->cg = cg;
  com2->cursor = cursor;
  com2->display_type = display_type;
  com2->cursor_line = cursor_line;
  
  com2->com1 = com1;
  INIT = THD_TRUE;
  
  return com2;  
}

void *
GFX_T6963_DestroyCom2 (
  THD_GFX_T6963_com2_t *com2)
{
  THD_CHECK ( , com2 == NULL , 
    return NULL;
  )
    
  #ifndef EMBEDDED
    free(com2);
  #else
    /* Ici on devrai normallement liberer le pool d'une position mais c'est trop complexe pour le moment */
  #endif
  
  return NULL;
}

THD_GFX_T6963_com2_t *
GFX_T6963_InitCom2_Default (
  THD_GFX_T6963_com1_t *com1,
  THD_pos_t gfx_size,
  Uint8 font_width)
{
  THD_GFX_T6963_com2_t *com2=NULL;
  
  THD_CHECK ( , (com1 == NULL) || (GFX_T6963_RequestCom1_Init (com1) != THD_TRUE) ||
                !gfx_size.y  || !gfx_size.x || ((font_width != (Uint8) 0) && (font_width != (Uint8) 6) && (font_width != (Uint8) 8)) ,
    THD_ERROR ("GFX_T6963_InitCom2_Default : wrong parameter\n");
    return NULL;
  )
     
  if(!font_width)
    font_width = GFX_T6963_DEFAULT_FONT_WIDTH;
  THD_CHECK ( (com2 = GFX_T6963_CreateCom2 (com1, gfx_size, font_width,
							GFX_T6963_DEFAULT_LOGICAL_MODE, GFX_T6963_DEFAULT_CG_MODE,
							GFX_T6963_DEFAULT_CURSOR_MODE, GFX_T6963_DEFAULT_DISPLAY_TYPE,
							GFX_T6963_DEFAULT_CURSOR_LINE)) , == NULL,
    return NULL;
  )
  
  THD_CHECK ( GFX_T6963_InitCom2 (com2) , == THD_FALSE ,
    com2 = GFX_T6963_DestroyCom2 (com2);
    return NULL;
  )
  
  return com2;
}

THD_bool
GFX_T6963_InitCom2 (
  THD_GFX_T6963_com2_t *com2)
{
  THD_CHECK ( , (com2 == NULL) || (com2->com1 == NULL) || (GFX_T6963_RequestCom1_Init (com2->com1) != THD_TRUE) ,
    THD_ERROR ("GFX_T6963_InitCom2 : wrong parameter\n");
    return THD_FALSE;
  )
  
  INIT = THD_TRUE; /* Init r�alis� */
  
  /* Configuration */
  
  GFX_T6963_SetControlWord (com2, GFX_T6963_SET_TEXT_HOME_ADDRESS, GFX_T6963_GetLowerByte (com2->txt_home), GFX_T6963_GetUpperByte (com2->txt_home));
  GFX_T6963_SetControlWord (com2, GFX_T6963_SET_TEXT_AREA, com2->txt_area, 0);
  GFX_T6963_SetControlWord (com2, GFX_T6963_SET_GRAPHIC_HOME_ADDRESS, GFX_T6963_GetLowerByte (com2->gfx_home), GFX_T6963_GetUpperByte (com2->gfx_home));
  GFX_T6963_SetControlWord (com2, GFX_T6963_SET_GRAPHIC_AREA, com2->gfx_area, 0);
  GFX_T6963_ModeSet (com2, com2->logical, com2->cg);
  GFX_T6963_CursorPatternSelect (com2, com2->cursor_line);
  GFX_T6963_RegistersSetting (com2, GFX_T6963_SET_CURSOR_POINTER, 0, 0);
  GFX_T6963_DisplayMode (com2, GFX_T6963_DISPLAY_ON, com2->cursor, com2->display_type);
  /* GFX_T6963_RegistersSetting (com2, GFX_T6963_SET_OFFSET_REGISTER, 0, 0); */
  /* GFX_T6963_RegistersSetting (com2, GFX_T6963_SET_ADDRESS_POINTER, com2->txt_home % 256, com2->txt_home >> 8); */
  
  return INIT;
}

THD_bool
GFX_T6963_RequestCom2_Init (
  THD_GFX_T6963_com2_t *com2)
{
  THD_CHECK ( , com2 == NULL ,
    THD_ERROR ("GFX_T6963_RequestCom2_Init : wrong parameter\n");
    return THD_FALSE;
  )
  
  return INIT;
}

Uint8
GFX_T6963_GetUpperByte (
  Uint16 data)
{
  return (data >> 8) & 0xFF;
}

Uint8
GFX_T6963_GetLowerByte (
  Uint16 data)
{
  return data & 0xFF;
}

/* T6963 FUNCTIONS */

THD_bool
GFX_T6963_RegistersSetting (
  THD_GFX_T6963_com2_t *com2,
  THD_GFX_T6963_Register_Setting_e mode,
  Uint8 d1,
  Uint8 d2)
{
  Uint8 base=0x20;
  
  THD_CHECK ( , (com2 == NULL) || (INIT == THD_FALSE) ,
    THD_ERROR ("GFX_T6963_RegistersSetting : wrong parameter or com2 not initialized\n");
    return THD_FALSE;
  )
  
  switch(mode) {
   case GFX_T6963_SET_CURSOR_POINTER:
    base += 0x01;
   break;
   case GFX_T6963_SET_OFFSET_REGISTER:
    base += 0x02;
    d2 = 0x00;
   break;
   case GFX_T6963_SET_ADDRESS_POINTER:
    base += 0x04;
   break;
  }
  
  THD_VERBOSE ("GFX_T6963_RegistersSetting : cmd=0x%X d1=0x%X d2=0x%X\n", base, d1, d2);
  
  return command_data (com2, d1, d2, base, GFX_T6963_SEND_2DATAS);
}

THD_bool
GFX_T6963_SetControlWord (
  THD_GFX_T6963_com2_t *com2,
  THD_GFX_T6963_Set_Control_Word_e mode,
  Uint8 d1,
  Uint8 d2)
{
  Uint8 base=0x40;
  
  THD_CHECK ( , (com2 == NULL) || (INIT == THD_FALSE) ,
    THD_ERROR ("GFX_T6963_SetControlWord : wrong parameter or com2 not initialized\n");
    return THD_FALSE;
  )
  
  switch(mode) {
   case GFX_T6963_SET_TEXT_HOME_ADDRESS:
    /* NOTHING TO DO */
   break;
   case GFX_T6963_SET_TEXT_AREA:
    base += 0x01;
    d2 = 0x00;
   break;
   case GFX_T6963_SET_GRAPHIC_HOME_ADDRESS:
    base += 0x02;
   break;
   case GFX_T6963_SET_GRAPHIC_AREA:
    base += 0x03;
    d2 = 0x00;
   break;
  }
  
  
  THD_VERBOSE ("GFX_T6963_SetControlWord : cmd=0x%X d1=0x%X d2=0x%X\n", base, d1, d2);
  
  return command_data (com2, d1, d2, base, GFX_T6963_SEND_2DATAS);
}

THD_bool
GFX_T6963_ModeSet (
  THD_GFX_T6963_com2_t *com2,
  THD_GFX_T6963_Mode_Set_Logical_e logical,
  THD_GFX_T6963_Mode_Set_CG_e cg)
{
  Uint8 base=0x80;
  
  THD_CHECK ( , (com2 == NULL) || (INIT == THD_FALSE) ,
    THD_ERROR ("GFX_T6963_ModeSet : wrong parameter or com2 not initialized\n");
    return THD_FALSE;
  )
  
  switch(logical) {
   case GFX_T6963_OR_MODE:
    /* NOTHING TO DO */
   break;
   case GFX_T6963_EXOR_MODE:
    base += 0x01;
   break;
   case GFX_T6963_AND_MODE:
    base += 0x03;
   break;
   case GFX_T6963_TEXT_ATTRIBUTE_MODE:
    base += 0x04;
   break;
  }
  
  if(cg == GFX_T6963_EXTERNAL_CGRAM_MODE)
    base += 0x08;
    
    
  THD_VERBOSE ("GFX_T6963_ModeSet : cmd=0x%X\n", base);
  
  return command_data (com2, 0, 0, base, GFX_T6963_SEND_NODATA);
}

THD_bool
GFX_T6963_DisplayMode (
  THD_GFX_T6963_com2_t *com2,
  THD_GFX_T6963_Display_Mode_State_e state,
  THD_GFX_T6963_Display_Mode_Cursor_e cursor,
  THD_GFX_T6963_Display_Mode_Type_e type)
{
  Uint8 base=0x90;
  
  THD_CHECK ( , (com2 == NULL) || (INIT == THD_FALSE) ,
    THD_ERROR ("GFX_T6963_DisplayMode : wrong parameter or com2 not initialized\n");
    return THD_FALSE;
  )
  
  if(state != GFX_T6963_DISPLAY_OFF) {
    switch(cursor) {
     case GFX_T6963_CURSOR_OFF:
      /* NOTHING TO DO */
     break;
     case GFX_T6963_CURSOR_ON_BLINK_OFF:
      base += 0x02;
     break;
     case GFX_T6963_CURSOR_ON_BLINK_ON:
      base += 0x03;
     break;
    }
    
    switch(type) {
     case GFX_T6963_DISPLAY_TYPE_TEXT:
      base += 0x04;
      base &= ~0x08;
     break;
     case GFX_T6963_DISPLAY_TYPE_GRAPHIC:
      base += 0x08;
      base &= ~0x04;
     break;
     case GFX_T6963_DISPLAY_TYPE_BOTH:
      base += 0x0C;
     break;
    }
    THD_VERBOSE ("GFX_T6963_DisplayMode : on, cmd=0x%X\n", base);
  }else
    THD_VERBOSE ("GFX_T6963_DisplayMode : off\n");
  
  return command_data (com2, 0, 0, base, GFX_T6963_SEND_NODATA);
}

THD_bool
GFX_T6963_CursorPatternSelect (
  THD_GFX_T6963_com2_t *com2,
  Uint8 line)
{
  Uint8 base=0xA0;
  
  THD_CHECK ( , (com2 == NULL) || (INIT == THD_FALSE) || (line < 1) || (line > 8) ,
    THD_ERROR ("GFX_T6963_CursorPatternSelect : wrong parameter or com2 not initialized\n");
    return THD_FALSE;
  )
  
  base += line - 1;
  
  THD_VERBOSE ("GFX_T6963_CursorPatternSelect : to %d line(s) cmd=0x%X\n", line, base);
  
  return command_data (com2, 0, 0, base, GFX_T6963_SEND_NODATA);  
}

THD_bool
GFX_T6963_DataAutoRW (
  THD_GFX_T6963_com2_t *com2,
  THD_GFX_T6963_Data_Auto_RW_e mode)
{
  THD_CHECK ( , (com2 == NULL) || (INIT == THD_FALSE) ,
    THD_ERROR ("GFX_T6963_DataAutoRW : wrong parameter or com2 not initialized\n");
    return THD_FALSE;
  )
  
  switch(mode) {
   case GFX_T6963_DATA_AUTO_WRITE:
    THD_VERBOSE ("GFX_T6963_DataAutoRW : set auto write, cmd=0x%X\n", 0xB0);
    
    return command_data (com2, 0, 0, 0xB0, GFX_T6963_SEND_NODATA);
   break;
   case GFX_T6963_DATA_AUTO_READ:
    THD_VERBOSE ("GFX_T6963_DataAutoRW : set auto read, cmd=0x%X\n", 0xB1);
    
    return command_data (com2, 0, 0, 0xB1, GFX_T6963_SEND_NODATA);
   break;
   case GFX_T6963_DATA_AUTO_RESET:
    THD_VERBOSE ("GFX_T6963_DataAutoRW : reset auto, cmd=0x%X\n", 0xB2);
    
    return command_data (com2, 0, 0, 0xB2, GFX_T6963_SEND_NODATA);
   break;
  }
  
  return THD_FALSE;
}

THD_bool
GFX_T6963_DataRW (
  THD_GFX_T6963_com2_t *com2,
  THD_GFX_T6963_Data_RW_e mode,
  Uint8 data,
  Uint8 *result)
{
  THD_CHECK ( , (com2 == NULL) || (INIT == THD_FALSE) ,
    THD_ERROR ("GFX_T6963_DataRW : wrong parameter or com2 not initialized\n");
    return THD_FALSE;
  )
  
  switch(mode) {
   case GFX_T6963_DATA_WRITE_ISZ:
    THD_VERBOSE ("GFX_T6963_DataRW : cmd=0x%X data=0x%X\n", 0xC0, data);
    
    return command_data (com2, data, 0, 0xC0, GFX_T6963_SEND_1DATA);
   break;
   case GFX_T6963_DATA_WRITE_DSZ:
    THD_VERBOSE ("GFX_T6963_DataRW : cmd=0x%X data=0x%X\n", 0xC2, data);
    
    return command_data (com2, data, 0, 0xC2, GFX_T6963_SEND_1DATA);
   break;
   case GFX_T6963_DATA_WRITE_FIX:
    THD_VERBOSE ("GFX_T6963_DataRW : cmd=0x%X data=0x%X\n", 0xC4, data);
    
    return command_data (com2, data, 0, 0xC4, GFX_T6963_SEND_1DATA);
   break;
   case GFX_T6963_DATA_READ_ISZ:
    THD_VERBOSE ("GFX_T6963_DataRW : cmd=0x%X\n", 0xC1);
    
    THD_CHECK ( command_data (com2, 0, 0, 0xC1, GFX_T6963_SEND_NODATA) , == THD_FALSE ,
      return THD_FALSE;
    )
      
    if(check_status (com2) == THD_FALSE) {
      THD_ERROR ("GFX_T6963_DataRW : ABORTING (FAILLED ON CHECK STATUS)\n");
      return THD_FALSE;
    }
    *result = GFX_T6963_ReadData (com2->com1);
    
    return THD_TRUE;
   break;
   case GFX_T6963_DATA_READ_DSZ:
    THD_VERBOSE ("GFX_T6963_DataRW : cmd=0x%X\n", 0xC3);
    
    THD_CHECK ( command_data (com2, 0, 0, 0xC3, GFX_T6963_SEND_NODATA) , == THD_FALSE ,
      return THD_FALSE;
    )
      
    if(check_status (com2) == THD_FALSE) {
      THD_ERROR ("GFX_T6963_DataRW : ABORTING (FAILLED ON CHECK STATUS)\n");
      return THD_FALSE;
    }
    *result = GFX_T6963_ReadData (com2->com1);
    
    return THD_TRUE;
   break;
   case GFX_T6963_DATA_READ_FIX:
    THD_VERBOSE ("GFX_T6963_DataRW : cmd=0x%X\n", 0xC5);
    
    THD_CHECK ( command_data (com2, 0, 0, 0xC5, GFX_T6963_SEND_NODATA) , == THD_FALSE ,
      return THD_FALSE;
    )
      
    if(check_status (com2) == THD_FALSE) {
      THD_ERROR ("GFX_T6963_DataRW : ABORTING (FAILLED ON CHECK STATUS)\n");
      return THD_FALSE;
    }
    *result = GFX_T6963_ReadData (com2->com1);
    
    return THD_TRUE;
   break;
  }
  
  return THD_FALSE;
}

/* TODO SCREEN_PEEK command */

/* TODO SCREEN_COPY command */

THD_bool
GFX_T6963_BitSetReset (
  THD_GFX_T6963_com2_t *com2,
  SET_RESET_e mode,
  Uint8 bit)
{
  Uint8 base=0xF0;
  
  THD_CHECK ( , (com2 == NULL) || (INIT == THD_FALSE) || (bit >= com2->font_width) , 
    THD_ERROR ("GFX_T6963_BitSetReset : wrong parameter or com2 not initialized\n");
    return THD_FALSE;
  )
  
  base += bit;
  if(mode == SET)
    base += 0x08;
  
  THD_VERBOSE ("GFX_T6963_BitSetReset : type=%s bit=%d, cmd=0x%X\n", mode == RESET ? "RESET" : "SET", bit, base);
  
  return command_data (com2, 0, 0, base, GFX_T6963_SEND_NODATA);
}

THD_bool
GFX_T6963_BitSetReset_AutoData (
  THD_GFX_T6963_com2_t *com2,
  SET_RESET_e mode,
  Uint8 bit)
{
  Uint8 base=0xF0;
  
  THD_CHECK ( , (com2 == NULL) || (INIT == THD_FALSE) || (bit >= com2->font_width) , 
    THD_ERROR ("GFX_T6963_BitSetReset_AutoData : wrong parameter or com2 not initialized\n");
    return THD_FALSE;
  )
  
  base += bit;
  if(mode == SET)
    base += 0x08;
    
  THD_VERBOSE ("GFX_T6963_BitSetReset_AutoData : type=%s bit=%d, cmd=0x%X\n", mode == RESET ? "RESET" : "SET", bit, base);
  
  return GFX_T6963_AutoDataSend (com2, base);
}

THD_bool
GFX_T6963_AutoDataSend (
  THD_GFX_T6963_com2_t *com2,
  Uint8 data)
{
  THD_CHECK ( , (com2 == NULL) || (INIT == THD_FALSE) ,
    THD_ERROR ("GFX_T6963_AutoDataSend : wrong parameter or com2 not initialized\n");
    return THD_FALSE;
  )
  
  if(check_status_auto (com2) == THD_FALSE) {
    THD_ERROR ("GFX_T6963_AutoDataSend : ABORTING (FAILLED ON CHECK STATUS)\n");
    return THD_FALSE;
  }
  
  return GFX_T6963_SendData (com2->com1, data);
}

THD_bool
GFX_T6963_AutoDataRead (
  THD_GFX_T6963_com2_t *com2,
  Uint8 *result)
{
  THD_CHECK ( , (com2 == NULL) || (INIT == THD_FALSE) ,
    THD_ERROR ("GFX_T6963_AutoDataRead : wrong parameter or com2 not initialized\n");
    return THD_FALSE;
  )
  
  if(check_status_auto (com2) == THD_FALSE) {
    THD_ERROR ("GFX_T6963_AutoDataRead : ABORTING (FAILLED ON CHECK STATUS)\n");
    return THD_FALSE;
  }
  
  *result = GFX_T6963_ReadData (com2->com1);
  
  return THD_TRUE;
}

/* INTERNAL MANIPULATION FUNCTIONS */

static THD_bool
command_data (
  THD_GFX_T6963_com2_t *com2,
  Uint8 data1,
  Uint8 data2,
  Uint8 command,
  THD_GFX_T6963_Command_Data_e mode)
{
  Uint8 data=0;

  THD_CHECK ( , (com2 == NULL) || (INIT == THD_FALSE) || !command ,
    THD_ERROR ("GFX_T6963 -> command_data (static) : wrong parameter or com2 not initialized\n");
    return THD_FALSE;
  )
  
  while(mode != GFX_T6963_SEND_NODATA) {
    if(check_status (com2) == THD_FALSE) {
      THD_ERROR ("GFX_T6963 -> command_data (static) : ABORTING (FAILLED ON CHECK STATUS)\n");
      return THD_FALSE;
    }
    
    data = data1;
    if(mode == GFX_T6963_SEND_2DATAS) {
      data1 = data2;
      mode = GFX_T6963_SEND_1DATA;
    }else if(mode == GFX_T6963_SEND_1DATA) {
      mode = GFX_T6963_SEND_NODATA;
    }
    
    THD_CHECK ( GFX_T6963_SendData (com2->com1, data) , == THD_FALSE ,
      return THD_FALSE;
    )
  }
  
  if(check_status (com2) == THD_FALSE) {
    THD_ERROR ("GFX_T6963 -> command_data (static) : ABORTING (FAILLED ON CHECK STATUS)\n");
    return THD_FALSE;
  }
  
  THD_CHECK ( GFX_T6963_SendCmd (com2->com1, command) , == THD_FALSE ,
    return THD_FALSE;
  )
  
  return THD_TRUE;
}

static THD_bool
check_status (
  THD_GFX_T6963_com2_t *com2)
{
  /*THD_Timing (0x01, 10); */
  return THD_TRUE;
  /*Uint8 ret=0, abort=0;
  
  while(!((ret & 0x23) == 0x23)) {
    if(abort >= 10)
      return THD_FALSE;
      
    ret = GFX_T6963_ReadStatus (com2->com1);
    abort++;
  }
  
  return THD_TRUE;*/
}

static THD_bool
check_status_auto (
  THD_GFX_T6963_com2_t *com2)
{
  /* THD_Timing (0x01, 10); */
  return THD_TRUE;
  /*Uint8 ret=0, abort=0;
  
  while((ret & 0x08) != 0x08) {
    if(abort >= 10)
      return THD_FALSE;
      
    ret = GFX_T6963_ReadStatus (com2->com1);
    abort++;
  }
  
  return THD_TRUE;*/
}
