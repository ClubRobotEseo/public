/*
 *  GFX_T6963_com1.c: parallel port level for T6963 driver
 *  Part of ThacidLCD package
 *  Copyright 2001-2005  Axel Voitier
 *
 *  deadog@users.sourceforge.net
 *
 *  This software is a computer program whose purpose is to control liquid crystal displays.
 *
 *  This software is governed by the CeCILL  license under French law and
 *  abiding by the rules of distribution of free software.  You can  use,
 *  modify and/ or redistribute the software under the terms of the CeCILL
 *  license as circulated by CEA, CNRS and INRIA at the following URL
 *  "http://www.cecill.info".
 *
 *  As a counterpart to the access to the source code and  rights to copy,
 *  modify and redistribute granted by the license, users are provided only
 *  with a limited warranty  and the software's author,  the holder of the
 *  economic rights,  and the successive licensors  have only  limited
 *  liability.
 *
 *  In this respect, the user's attention is drawn to the risks associated
 *  with loading,  using,  modifying and/or developing or reproducing the
 *  software by the user in light of its specific status of free software,
 *  that may mean  that it is complicated to manipulate,  and  that  also
 *  therefore means  that it is reserved for developers  and  experienced
 *  professionals having in-depth computer knowledge. Users are therefore
 *  encouraged to load and test the software's suitability as regards their
 *  requirements in conditions enabling the security of their systems and/or
 *  data to be ensured and,  more generally, to use and operate it in the
 *  same conditions as regards security.
 *
 *  The fact that you are presently reading this means that you have had
 *  knowledge of the CeCILL license and that you accept its terms.
 */

#define __GFX_T6963_COM1_C

#include "GFX_T6963_com1.h"

static THD_bool set_control (THD_GFX_T6963_com1_t *com1, THD_bit_status_e cd_state, THD_bit_status_e rd_state, THD_bit_status_e wr_state, THD_bit_status_e ce_state);

THD_GFX_T6963_com1_t *
GFX_T6963_CreateCom1 (
  THD_addr_port_t addr_data_port,
#ifdef EMBEDDED
  THD_addr_port_t addr_data_control_port,
#endif
  THD_addr_port_t addr_control_port,
  THD_bit_list_e cd_pin,
  THD_bit_list_e rd_pin,
  THD_bit_list_e wr_pin,
  THD_bit_list_e ce_pin)
{
  THD_GFX_T6963_com1_t *com1=NULL;

  #ifdef __linux__
    if(!addr_data_port)
      addr_data_port = GFX_T6963_DEFAULT_DATA_PORT;
    if(!addr_control_port)
      addr_control_port = GFX_T6963_DEFAULT_CONTROL_PORT;

    if(cd_pin == NOT_WIRED)
      cd_pin = GFX_T6963_DEFAULT_CD_PIN;
    if(rd_pin == NOT_WIRED)
      rd_pin = GFX_T6963_DEFAULT_RD_PIN;
    if(wr_pin == NOT_WIRED)
      wr_pin = GFX_T6963_DEFAULT_WR_PIN;
    if(ce_pin == NOT_WIRED)
      ce_pin = GFX_T6963_DEFAULT_CE_PIN;
  #else
    if(!addr_data_port)
      return NULL;
    #ifdef EMBEDDED
    if(!addr_data_control_port)
      return NULL;
    #endif
    if(!addr_control_port)
      return NULL;

    if(cd_pin == NOT_WIRED)
      return NULL;
    if(rd_pin == NOT_WIRED)
      return NULL;
    if(wr_pin == NOT_WIRED)
      return NULL;
    if(ce_pin == NOT_WIRED)
      return NULL;
  #endif

  #ifndef EMBEDDED
    if ( (com1 = (THD_GFX_T6963_com1_t *) calloc(1, sizeof(THD_GFX_T6963_com1_t))) == NULL)
	{
      THD_ERROR ("GFX_T6963_CreateCom1 : "__ALLOC_ERROR__"\n");
      return NULL;
    }
  #else
    if ( singleton_com1_used == NB_SINGLETON_COM1)
	{
      THD_ERROR (("GFX_T6963_CreateCom1 : no singleton com1 available\n"));
      return NULL;
    }
    com1 = &com1_pool[singleton_com1_used++];
  #endif

  com1->addr_data_port = addr_data_port;
  #ifdef EMBEDDED
  com1->addr_data_control_port = addr_data_control_port;
  #endif
  com1->addr_control_port = addr_control_port;
  com1->cd_pin = cd_pin;
  com1->rd_pin = rd_pin;
  com1->wr_pin = wr_pin;
  com1->ce_pin = ce_pin;

  INIT = THD_FALSE;

  return com1;
}

void *
GFX_T6963_DestroyCom1 (
  THD_GFX_T6963_com1_t *com1)
{
  THD_CHECK ( , com1 == NULL ,
    return NULL;
  )

  if(com1->cd_bit != NULL)
    THD_IO_Destroy_Bit (com1->cd_bit);

  if(com1->rd_bit != NULL)
    THD_IO_Destroy_Bit (com1->rd_bit);

  if(com1->wr_bit != NULL)
    THD_IO_Destroy_Bit (com1->wr_bit);

  if(com1->ce_bit != NULL)
    THD_IO_Destroy_Bit (com1->ce_bit);

  if(com1->timing != NULL)
    THD_IO_Destroy_Port (com1->timing);

  if(com1->data_port != NULL)
    THD_IO_Destroy_Port (com1->data_port);

  #ifdef EMBEDDED
  if(com1->data_control_port != NULL)
    THD_IO_Destroy_Port (com1->data_control_port);
  #endif

  if(com1->control_port != NULL)
    THD_IO_Destroy_Port (com1->control_port);

  #ifndef EMBEDDED
    free(com1);
  #else
    /* Ici on devrait normalement liberer le pool d'une position mais c'est trop complexe pour le moment */
  #endif

  return NULL;
}

#ifdef __linux__
THD_GFX_T6963_com1_t *
GFX_T6963_InitCom1_Default (
  THD_addr_port_t addr_data_port,
  THD_addr_port_t addr_control_port)
{
  THD_GFX_T6963_com1_t *com1=NULL;

  if(!addr_data_port)
    addr_data_port = GFX_T6963_DEFAULT_DATA_PORT;
  if(!addr_control_port)
    addr_control_port = GFX_T6963_DEFAULT_CONTROL_PORT;

  THD_CHECK ( (com1 = GFX_T6963_CreateCom1 (addr_data_port, addr_control_port,
                                  GFX_T6963_DEFAULT_CD_PIN,
                                  GFX_T6963_DEFAULT_RD_PIN,
                                  GFX_T6963_DEFAULT_WR_PIN,
                                  GFX_T6963_DEFAULT_CE_PIN)) , == NULL ,
    return NULL;
  )

  THD_CHECK ( GFX_T6963_InitCom1 (com1) , == THD_FALSE ,
    com1 = GFX_T6963_DestroyCom1 (com1);
    return NULL;
  )

  return com1;
}
#endif

THD_bool
GFX_T6963_InitCom1 (
  THD_GFX_T6963_com1_t *com1)
{
  if ( com1 == NULL )
  {
    THD_ERROR ("GFX_T6963_InitCom1 : wrong parameter\n");
    return THD_FALSE;
  }

  if ( (com1->timing = THD_Init_Timing ()) == NULL)
  {
    return THD_FALSE;
  }

  if ( (com1->control_port = THD_IO_Init_Port (com1->addr_control_port, CONTROL, NULL)) == NULL)
  {
    THD_IO_Destroy_Port (com1->timing);
    return THD_FALSE;
  }

  #ifdef EMBEDDED
    THD_CHECK ( (com1->data_control_port = THD_IO_Init_Port (com1->addr_data_control_port, CONTROL, NULL)) , == NULL , /* Port DATA_CONTROL */
      THD_IO_Destroy_Port (com1->timing);
      THD_IO_Destroy_Port (com1->control_port);
      return THD_FALSE;
    )

    THD_CHECK ( (com1->data_port = THD_IO_Init_Port (com1->addr_data_port, DATA, com1->data_control_port)) , == NULL , /* Port DATA */
      THD_IO_Destroy_Port (com1->timing);
      THD_IO_Destroy_Port (com1->control_port);
      THD_IO_Destroy_Port (com1->data_control_port);
      return THD_FALSE;
    )
  #else
    THD_CHECK ( (com1->data_port = THD_IO_Init_Port (com1->addr_data_port, DATA, com1->control_port)) , == NULL , /* Port DATA */
      THD_IO_Destroy_Port (com1->timing);
      THD_IO_Destroy_Port (com1->control_port);
      return THD_FALSE;
    )
  #endif

  THD_IO_SetStatus_Port (com1->data_port, OUTPUT); /* On place le port en sortie */

  com1->cd_bit = THD_IO_Init_Bit (com1->control_port, com1->cd_pin);
  THD_CHECK ( , com1->cd_bit->set_mask == (Uint8) 0 , /* CD doit obligatoirement �tre cabl� ! */
    THD_ERROR ("GFX_T6963_InitCom1 : CD pin must be wired\n");
    THD_IO_Destroy_Port (com1->timing);
    THD_IO_Destroy_Port (com1->data_port);
    THD_IO_Destroy_Port (com1->control_port);
    return THD_FALSE;
  )

  com1->rd_bit = THD_IO_Init_Bit (com1->control_port, com1->rd_pin);
  THD_CHECK ( , com1->rd_bit->set_mask == (Uint8) 0 , /* RD doit obligatoirement �tre cabl� ! */
    THD_ERROR ("GFX_T6963_InitCom1 : RD pin must be wired\n");
    THD_IO_Destroy_Port (com1->timing);
    THD_IO_Destroy_Port (com1->data_port);
    THD_IO_Destroy_Port (com1->control_port);
    THD_IO_Destroy_Bit (com1->cd_bit);
    return THD_FALSE;
  )

  com1->wr_bit = THD_IO_Init_Bit (com1->control_port, com1->wr_pin);
  THD_CHECK ( , com1->wr_bit->set_mask == (Uint8) 0 , /* WR doit obligatoirement �tre cabl� ! */
    THD_ERROR ("GFX_T6963_InitCom1 : WR pin must be wired\n");
    THD_IO_Destroy_Port (com1->timing);
    THD_IO_Destroy_Port (com1->data_port);
    THD_IO_Destroy_Port (com1->control_port);
    THD_IO_Destroy_Bit (com1->cd_bit);
    THD_IO_Destroy_Bit (com1->rd_bit);
    return THD_FALSE;
  )

  com1->ce_bit = THD_IO_Init_Bit (com1->control_port, com1->ce_pin);
  THD_CHECK ( , com1->ce_bit->set_mask == (Uint8) 0 , /* CE doit obligatoirement �tre cabl� ! */
    THD_ERROR ("GFX_T6963_InitCom1 : CE pin must be wired\n");
    THD_IO_Destroy_Port (com1->timing);
    THD_IO_Destroy_Port (com1->data_port);
    THD_IO_Destroy_Port (com1->control_port);
    THD_IO_Destroy_Bit (com1->cd_bit);
    THD_IO_Destroy_Bit (com1->rd_bit);
    THD_IO_Destroy_Bit (com1->wr_bit);
    return THD_FALSE;
  )

  INIT = THD_TRUE; /* Init r�alis� */
  set_control (com1, BIT_HIGH, BIT_HIGH, BIT_HIGH, BIT_HIGH);

  return INIT;
}

THD_bool
GFX_T6963_RequestCom1_Init (
  THD_GFX_T6963_com1_t *com1)
{
  THD_CHECK ( , com1 == NULL ,
    THD_ERROR ("GFX_T6963_RequestCom1Init : wrong parameter\n");
    return THD_FALSE;
  )

  return INIT;
}

THD_bool
GFX_T6963_SendData (
  THD_GFX_T6963_com1_t *com1,
  Uint8 data)
{
  THD_CHECK ( , (com1 == NULL) || (INIT == THD_FALSE) ,
    THD_ERROR ("GFX_T6963_SendData : wrong parameter or com1 not initialized\n");
    return THD_FALSE;
  )

  /*
    Write Data Flow Chart
      Neutral state ; CD = H
      Neutral state ; CD = L
      20ns
      CD = FIX ; RD = H ; WR = L ; CE = L
      Write data port
      80ns
      CD = FIX ; RD = H ; WR = H ; CE = H
      10ns
      Neutral state ; CD = H
  */

  THD_IO_SetStatus_Port (com1->data_port, OUTPUT);
  set_control (com1, BIT_HIGH, BIT_HIGH, BIT_HIGH, BIT_HIGH);
  set_control (com1, BIT_LOW, BIT_HIGH, BIT_HIGH, BIT_HIGH);
  TEMPO;
  set_control (com1, BIT_FIX, BIT_HIGH, BIT_LOW, BIT_LOW);
  THD_IO_Send_Port (com1->data_port, (THD_size_port_t) data);
  TEMPO;
  set_control (com1, BIT_FIX, BIT_HIGH, BIT_HIGH, BIT_HIGH);
  TEMPO;
  set_control (com1, BIT_HIGH, BIT_HIGH, BIT_HIGH, BIT_HIGH);

  THD_VERBOSE ("GFX_T6963_SendData : 0x%X\n", data);

  return THD_TRUE;
}

Uint8
GFX_T6963_ReadData (
  THD_GFX_T6963_com1_t *com1)
{
  THD_size_port_t ret;

  THD_CHECK ( , (com1 == NULL) || (INIT == THD_FALSE) ,
    THD_ERROR ("GFX_T6963_ReadData : wrong parameter or com1 not initialized\n");
    return 0;
  )

  /*
    Read Data Flow Chart
      Raz data port
      Neutral state ; CD = H
      Neutral state ; CD = L
      20ns
      CD = FIX ; RD = L ; WR = H ; CE = L
      150ns
      Read data port
      CD = FIX ; RD = H ; WR = H ; CE = H
      10ns
      Neutral state ; CD = H
  */

  THD_IO_SetStatus_Port (com1->data_port, OUTPUT);
  THD_IO_Send_Port (com1->data_port, (THD_size_port_t) 0x00);

  THD_IO_SetStatus_Port (com1->data_port, INPUT);
  set_control (com1, BIT_HIGH, BIT_HIGH, BIT_HIGH, BIT_HIGH);
  set_control (com1, BIT_LOW, BIT_HIGH, BIT_HIGH, BIT_HIGH);
  TEMPO;
  set_control (com1, BIT_FIX, BIT_LOW, BIT_HIGH, BIT_LOW);
  TEMPO;
  ret = THD_IO_Read_Port(com1->data_port);
  set_control (com1, BIT_FIX, BIT_HIGH, BIT_HIGH, BIT_HIGH);
  TEMPO;
  set_control (com1, BIT_HIGH, BIT_HIGH, BIT_HIGH, BIT_HIGH);

  THD_VERBOSE ("GFX_T6963_ReadData : 0x%X\n", ret);

  return ret;
}

THD_bool
GFX_T6963_SendCmd (
  THD_GFX_T6963_com1_t *com1,
  Uint8 command)
{
  THD_CHECK ( , (com1 == NULL) || (INIT == THD_FALSE) ,
    THD_ERROR ("GFX_T6963_SendCmd : wrong parameter or com1 not initialized\n");
    return THD_FALSE;
  )

  /*
    Write Command Flow Chart
      Neutral state ; CD = L
      Neutral state ; CD = H
      20ns
      CD = FIX ; RD = H ; WR = L ; CE = L
      Write data port
      80ns
      CD = FIX ; RD = H ; WR = H ; CE = H
      10ns
      Neutral state ; CD = L
  */

  THD_IO_SetStatus_Port (com1->data_port, OUTPUT);
  set_control (com1, BIT_LOW, BIT_HIGH, BIT_HIGH, BIT_HIGH);
  set_control (com1, BIT_HIGH, BIT_HIGH, BIT_HIGH, BIT_HIGH);
  TEMPO;
  set_control (com1, BIT_FIX, BIT_HIGH, BIT_LOW, BIT_LOW);
  THD_IO_Send_Port (com1->data_port, (THD_size_port_t) command);
  TEMPO;
  set_control (com1, BIT_FIX, BIT_HIGH, BIT_HIGH, BIT_HIGH);
  TEMPO;
  set_control (com1, BIT_LOW, BIT_HIGH, BIT_HIGH, BIT_HIGH);

  THD_VERBOSE ("GFX_T6963_SendCmd : 0x%X\n", command);

  return THD_TRUE;
}

Uint8
GFX_T6963_ReadStatus (
  THD_GFX_T6963_com1_t *com1)
{
  THD_size_port_t ret;

  THD_CHECK ( , (com1 == NULL) || (INIT == THD_FALSE) ,
    THD_ERROR ("GFX_T6963_ReadStatus : wrong parameter or com1 not initialized\n");
    return 0;
  )

  /*
    Read Status Flow Chart
      Raz data port
      Neutral state ; CD = L
      Neutral state ; CD = H
      20ns
      CD = FIX ; RD = L ; WR = H ; CE = L
      150ns
      Read data port
      CD = FIX ; RD = H ; WR = H ; CE = H
      10ns
      Neutral state ; CD = L
  */

  THD_IO_SetStatus_Port (com1->data_port, OUTPUT);
  THD_IO_Send_Port (com1->data_port, (THD_size_port_t) 0x00);

  THD_IO_SetStatus_Port (com1->data_port, INPUT);
  set_control (com1, BIT_LOW, BIT_HIGH, BIT_HIGH, BIT_HIGH);
  set_control (com1, BIT_HIGH, BIT_HIGH, BIT_HIGH, BIT_HIGH);
  TEMPO;
  set_control (com1, BIT_FIX, BIT_LOW, BIT_HIGH, BIT_LOW);
  TEMPO;
  ret = THD_IO_Read_Port(com1->data_port);
  set_control (com1, BIT_FIX, BIT_HIGH, BIT_HIGH, BIT_HIGH);
  TEMPO;
  set_control (com1, BIT_LOW, BIT_HIGH, BIT_HIGH, BIT_HIGH);

  THD_VERBOSE ("GFX_T6963_ReadStatus : 0x%X\n", ret);

  return ret;
}

/* Static */

/*
  CD : Read : LOW = Data Read, HIGH = Status Read
  CD : Write : LOW = Data Write, HIGH = Command Write
  RD : LOW = Data Read
  WR : LOW = Data Write
  CE : Chip Enable! LOW at communication

  Neutral Flow Chart :
    CD = L/H ; RD = H ; WR = H ; CE = H

  Read Flow Chart :
    Neutral state with CD in its state (CD must be inversed)
    20ns
    CD = FIX ; RD = L ; WR = H ; CE = L
    150ns
    Read data port
    CD = FIX ; RD = H ; WR = H ; CE = H
    10ns
    Neutral state (CD must be inversed)

  Write Flow Chart
    Neutral state with CD in its state (CD must be inversed)
    20ns
    CD = FIX ; RD = H ; WR = L ; CE = L
    Write data port
    80ns
    CD = FIX ; RD = H ; WR = H ; CE = H
    10ns
    Neutral state (CD must be inversed)
*/

static THD_bool
set_control (
  THD_GFX_T6963_com1_t *com1,
  THD_bit_status_e cd_state,
  THD_bit_status_e rd_state,
  THD_bit_status_e wr_state,
  THD_bit_status_e ce_state)
{
  THD_size_port_t base;
  #ifdef SHOW_VERBOSE
    THD_size_port_t base_org;
  #endif /* def SHOW_VERBOSE */

  THD_CHECK ( , (com1 == NULL) || (INIT == THD_FALSE) ,
    return THD_FALSE;
  )

  base = THD_IO_Read_Port (com1->control_port);
  #ifdef SHOW_VERBOSE
    base_org = base;
  #endif /* def SHOW_VERBOSE */

  if(cd_state == BIT_HIGH)
    base = THD_IO_GetStatusMask_Bit (com1->cd_bit, BIT_HIGH, base);
  else if(cd_state == BIT_LOW)
    base = THD_IO_GetStatusMask_Bit (com1->cd_bit, BIT_LOW, base);

  if(rd_state == BIT_HIGH)
    base = THD_IO_GetStatusMask_Bit (com1->rd_bit, BIT_HIGH, base);
  else if(rd_state == BIT_LOW)
    base = THD_IO_GetStatusMask_Bit (com1->rd_bit, BIT_LOW, base);

  if(wr_state == BIT_HIGH)
    base = THD_IO_GetStatusMask_Bit (com1->wr_bit, BIT_HIGH, base);
  else if(wr_state == BIT_LOW)
    base = THD_IO_GetStatusMask_Bit (com1->wr_bit, BIT_LOW, base);

  if(ce_state == BIT_HIGH)
    base = THD_IO_GetStatusMask_Bit (com1->ce_bit, BIT_HIGH, base);
  else if(ce_state == BIT_LOW)
    base = THD_IO_GetStatusMask_Bit (com1->ce_bit, BIT_LOW, base);

  /*THD_VERBOSE ("GFX_T6963 -> set_control (static) : 0x%X -> 0x%X\n", base_org, base);*/

  THD_IO_Send_Port (com1->control_port, base);

  return THD_TRUE;
}
