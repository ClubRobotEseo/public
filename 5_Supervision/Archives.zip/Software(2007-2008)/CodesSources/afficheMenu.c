#include "interface.h"


const char SWTxt[BTN_NUMBER][MAX_TEXT_LEN] = {
	"Pret",
	"Preconf",
	"Config",
	"Envoi",
	"Strateg",
	"Lecture"
};


void affichage(THD_struct *lcd, config* configOn)
{
	Uint8 page = 100;
	
	/************************/
	/* page			 		*/
	/* 0=pret				*/
	/* 1=pr�conf			*/
	/* 2=configuration 		*/
	/* 3=strat�gie			*/
	/* 4=recalage			*/
	/* 5=lecture CAN		*/
	/* 100 = menu principal	*/
	/************************/

	/************************************************************************/
	/*	Multiplier les valeurs ci dessus par 10 pour afficher le menu		*/
	/*	principal avec l'onglet de selection sur le sous menu choisi		*/
	/************************************************************************/


	while(page)
	{
		switch (page)
		{
			case 100: case 10: case 20: case 30: case 40: case 50:
				page /= 10;	/*retour aux valeurs de position des titres*/
				page = afficheMenu(lcd, page);
				break;
			case 0: 
				/*cas de la fin de configuration*/ 
				/* oui c'est inutile on entre pas dans le while avec page =0 */
				break;
			case 1:
				affichePreconf(lcd, configOn);
				page *= 10;
				break;
			case 2:
				afficheConfig(lcd, configOn);
				configOn->preconf=0;
				page *= 10;
				break;
			case 3:
				afficheEnvoi(lcd, configOn);
				page *= 10;
				break;
			case 4: 
				afficheStrateg(lcd, configOn);
				page *= 10;
				break;
			case 5:
				afficheLecture(lcd);
				page *= 10;
				break;
			default:
				printf("Erreur dans la page demand�e par la fonction affichage\n");
				break;
		}
	}
	affichePret(lcd, configOn);
	return;
}

Uint8 afficheMenu(THD_struct *lcd, Uint8 page)
{
	extern Uint8 swBuffer;


	/************************/
	/* page			 		*/
	/* 0=pret				*/
	/* 1=pr�conf			*/
	/* 2=configuration 		*/
	/* 3=strat�gie			*/
	/* 4=recalage			*/
	/* 5=lecture CAN		*/
	/* 100 = menu principal	*/
	/************************/
	page=(page==10)?0:page;
	afficheTxtMenu(lcd, page);

	while(1) 
	{
		if(isSWEvent(swBuffer)) 
		{
			switch(getSWEvent(swBuffer)) 
				{
				case MASK_TOP:    /* Actions pour haut */
					LED_0 = !LED_0;
					if(isSWOn(MASK_TOP)) 
					{
	    				if(page > 0) 
						{
		    				undrawCurs(lcd, page);
		    				page --;
		    				drawCurs(lcd, page);
		    			}
            		}
					break;
				case MASK_BOT:
					LED_0 = !LED_0;
					if(isSWOn(MASK_BOT)) 
					{
						if(page < BTN_NUMBER-1) 
						{
		    				undrawCurs(lcd, page);
		    				page ++;
		    				drawCurs(lcd, page);
						}
            		}
					break;
				case MASK_VALID:
					LED_0 = !LED_0;
					if(isSWOn(MASK_VALID)) 
					{
						LED_1 = 1;
						printTitle(lcd, page);
						return page;
					}
					break;
				case MASK_CANCEL:
					LED_0 = !LED_0;
					if(isSWOn(MASK_CANCEL)) 
					{
						LED_1 = 0;
	    				eraseTitle(lcd);
	   				}
					break;
				/*On met � jour le buffer*/
	      		swBuffer = SW_PORT;
			}
		}
	}
}

void afficheTxtMenu(THD_struct *lcd, Uint8 page)
{
   Uint8 i;
	
	for(i=0; i<BTN_NUMBER; i++)
	{
		TXT_SetPos(lcd, THD_pos(3,2*(i+1)));
		TXT_PrintString(lcd, SWTxt[i]);
		GFX_DrawFrame(lcd, THD_pos(MENU_POS_X+1, MENU_POS_Y+1+i*(BTN_HEIGHT+BTN_OFFSET_Y)), THD_pos(MENU_POS_X+BTN_WIDTH-1, MENU_POS_Y-1+i*(BTN_HEIGHT+BTN_OFFSET_Y)+BTN_HEIGHT), SET);
	}
	drawCurs(lcd, page);
}


void drawMenu(THD_struct *lcd)
{
	Uint8 i;
	
	for(i=0; i<BTN_NUMBER; i++)
	{
		TXT_SetPos(lcd, THD_pos(3,2*(i+1)));
		TXT_PrintString(lcd, SWTxt[i]);
		GFX_DrawFrame(lcd, THD_pos(MENU_POS_X+1, MENU_POS_Y+1+i*(BTN_HEIGHT+BTN_OFFSET_Y)), THD_pos(MENU_POS_X+BTN_WIDTH-1, MENU_POS_Y-1+i*(BTN_HEIGHT+BTN_OFFSET_Y)+BTN_HEIGHT), SET);
	}
}
