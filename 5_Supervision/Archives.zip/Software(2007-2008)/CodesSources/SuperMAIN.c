/*
 *  Club Robot ESEO 2007 - 2008
 *  Game Hoover
 *
 *  Fichier : SuperMAIN.c
 *  Package : SuperVision
 *  Description : 	int main (), initialisation, configuration
 *					et machine d'�tat de la supervision
 *  Auteur : Jacen
 *  Version 20080227
 */
#define __MAIN_C


#include "SuperMAIN.h"

int main(void)
{
	Uint16 i;
	e_etat etat;
	Uint8 last_msg_displayed_vod, last_msg_displayed_jit;
	Uint8 last_line_jit;

	/*Variables du lcd*/
	THD_struct *lcd=NULL;
	/*Initialisation des p�riph*/
	ports_init();
	/* UART_init(); */
	initialisationCAN();

	nb_mess_CAN = 0;
	flag_IT_CAN = 0;
	
	/*Initialisation avec le LCD*/
	LED_0 = 0;
	LED_1 = 0;
	lcd = THD_Init ((int)&PORTE,(int) &TRISE,(int) &PORTG, PIN_8, PIN_2, PIN_1, PIN_7, THD_pos(LCD_WIDTH, LCD_HEIGHT), 6);
	TXT_ClearScreen(lcd);
	GFX_ClearScreen(lcd);
	
	/* menu fabriqu� par Djo et Jacen */
	affichage(lcd,&configOn);

	/*Envoi des param�tres regles a la carte P*/
	/* a venir */
	LED_1 = 1;
	LED_0 = 1;

	/*Machine d'�tat*/
	etat = ENVOI_JIT;
	last_msg_displayed_vod = 0;
	last_msg_displayed_jit = 0;
	last_line_jit = 0;


	for(;;)
	{
		etat = majEtat(etat);
		switch(etat) 
		{
			case ENVOI_JIT:
				if (last_msg_displayed_jit < nb_mess_CAN)
				{
					if(configOn.lecture_can)
					{
						if (last_line_jit > NB_MSG_LCD)
						{
							last_line_jit = 1;
							clearScreen(lcd);
						}
						TXT_SetPos(lcd, THD_pos(1,last_line_jit++));	
						printLCDSIDCAN(buf_CAN[last_msg_displayed_jit].sid,lcd);
						printLCDDATA(buf_CAN[last_msg_displayed_jit],lcd);
						printLCDID((buf_CAN[last_msg_displayed_jit].dataReceive)[buf_CAN[last_msg_displayed_jit].taille-1],lcd);
					}
					if(configOn.envoi_can_serie)
					{
						printSIDCAN(buf_CAN[last_msg_displayed_jit].sid);
						printDATA(buf_CAN[last_msg_displayed_jit]);
						printf("ID MSGCAN = %d - Taille = %d\n\r",(buf_CAN[last_msg_displayed_jit].dataReceive)[buf_CAN[last_msg_displayed_jit].taille-1],buf_CAN[last_msg_displayed_jit].taille);
					}
					last_msg_displayed_jit++;
				}
				break;
	
			case ENVOI_VOD_REV:
				if (last_msg_displayed_vod > NB_MSG_LCD)
				last_msg_displayed_vod -= NB_MSG_LCD;
			case ENVOI_VOD:
				clearScreen(lcd);
				if (last_msg_displayed_vod < nb_mess_CAN)
				{	
					for (i=1; i <= NB_MSG_LCD; i++)
					{
						last_msg_displayed_vod++;
						if (last_msg_displayed_vod < nb_mess_CAN)
						{
							TXT_SetPos(lcd, THD_pos(1,i));	
							printLCDSIDCAN(buf_CAN[last_msg_displayed_vod].sid,lcd);
							printLCDDATA(buf_CAN[last_msg_displayed_vod],lcd);
							printLCDID((buf_CAN[last_msg_displayed_vod].dataReceive)[buf_CAN[last_msg_displayed_vod].taille-1],lcd);
						}
					}
				}
				etat = WAITING;
				break;
			case ENVOI_RS232:
				for (i=0; i<nb_mess_CAN;i++)
				{
					printSIDCAN(buf_CAN[i].sid);
					printDATA(buf_CAN[i]);
					printf("ID MSGCAN = %d - Taille = %d\n\r",(buf_CAN[i].dataReceive)[buf_CAN[i].taille-1],buf_CAN[i].taille);
				}
	
				etat = WAITING;
				break;
			
			case WAITING:
				/* on continue a attendre */
				break;
		}
	}
	_U1RXIE =0;
	return 0;
}

e_etat majEtat (e_etat previous_state)
{
	Uint8 swBuffer;
	/*On met � jour le buffer*/
	swBuffer = SW_PORT;
	
	switch(swBuffer) 
	{
		case TOP:    /* Actions pour haut */
				while(SW_PORT == TOP); /* attente blocante jusqu'� relachement du bouton */
				return ENVOI_VOD_REV;
				break;
		case BOT:
				while(SW_PORT == BOT);
				return ENVOI_VOD;
			break;
		case VALID:
				while(SW_PORT == VALID);
				printf("VALID\n");
				return ENVOI_RS232;
			break;
		case CANCEL:
				while(SW_PORT == CANCEL);
				printf("CANCEL\n");
				return ENVOI_JIT;
			break;
		default:
			return previous_state;
			/* do nothing : attente d'une action utilisateur */
	}
}
