/*
 *  GFX_T6963_com3.h: header file for standart functions adapted for GFX_T6963_com2
 *  Part of ThacidLCD package
 *  Copyright 2001-2005  Axel Voitier
 *  
 *  deadog@users.sourceforge.net
 *  
 *  This software is a computer program whose purpose is to control liquid crystal displays.
 *  
 *  This software is governed by the CeCILL  license under French law and
 *  abiding by the rules of distribution of free software.  You can  use, 
 *  modify and/ or redistribute the software under the terms of the CeCILL
 *  license as circulated by CEA, CNRS and INRIA at the following URL
 *  "http://www.cecill.info". 
 *  
 *  As a counterpart to the access to the source code and  rights to copy,
 *  modify and redistribute granted by the license, users are provided only
 *  with a limited warranty  and the software's author,  the holder of the
 *  economic rights,  and the successive licensors  have only  limited
 *  liability. 
 *  
 *  In this respect, the user's attention is drawn to the risks associated
 *  with loading,  using,  modifying and/or developing or reproducing the
 *  software by the user in light of its specific status of free software,
 *  that may mean  that it is complicated to manipulate,  and  that  also
 *  therefore means  that it is reserved for developers  and  experienced
 *  professionals having in-depth computer knowledge. Users are therefore
 *  encouraged to load and test the software's suitability as regards their
 *  requirements in conditions enabling the security of their systems and/or 
 *  data to be ensured and,  more generally, to use and operate it in the 
 *  same conditions as regards security. 
 *  
 *  The fact that you are presently reading this means that you have had
 *  knowledge of the CeCILL license and that you accept its terms.
 */

#ifndef __GFX_T6963_COM3_H
  #define __GFX_T6963_COM3_H
  
  #include "THD_system.h"
  #include "GFX_T6963_com2.h"
  
  #ifdef __cplusplus
  extern "C" {
  #endif
  
  void *GFX_T6963_DestroyDriver (THD_GFX_T6963_com2_t *com2);
  
  #ifndef __c18__
    inline void GFX_T6963_TraceObject_Start (THD_GFX_T6963_com2_t *com2);
    inline void GFX_T6963_TraceObject_End (THD_GFX_T6963_com2_t *com2);
  #else
    void GFX_T6963_TraceObject_Start (THD_GFX_T6963_com2_t *com2);
    void GFX_T6963_TraceObject_End (THD_GFX_T6963_com2_t *com2);
  #endif
  
  THD_bool GFX_T6963_SetCursorPos (THD_GFX_T6963_com2_t *com2, THD_pos_t pos);
  
  unsigned char GFX_T6963_TransChar (unsigned char caract);
  THD_bool GFX_T6963_SetPos_Txt (THD_GFX_T6963_com2_t *com2, THD_pos_t pos);
  THD_bool GFX_T6963_Clear_Txt (THD_GFX_T6963_com2_t *com2);
  THD_bool GFX_T6963_PrintChar_Txt (THD_GFX_T6963_com2_t *com2, unsigned char c);
  Uint8 GFX_T6963_PrintString_Txt (THD_GFX_T6963_com2_t *com2, const char *string);
  Uint8 GFX_T6963_PrintString2_Txt (THD_GFX_T6963_com2_t *com2, const char *string);
  THD_bool GFX_T6963_ClearLine_Txt (THD_GFX_T6963_com2_t *com2, THD_coord_t line);

  THD_bool GFX_T6963_SetPos_Gfx (THD_GFX_T6963_com2_t *com2, THD_pos_t pos);
  THD_bool GFX_T6963_Clear_Gfx (THD_GFX_T6963_com2_t *com2);
  THD_bool GFX_T6963_SetPixel_Gfx (THD_GFX_T6963_com2_t *com2, THD_pos_t pos, SET_RESET_e set_mode);
  THD_bool GFX_T6963_SetByte_Gfx (THD_GFX_T6963_com2_t *com2, THD_pos_t pos, Uint8 byte);
  
  #ifdef __cplusplus
      }
  #endif
  
  #ifdef __GFX_T6963_COM3_C

  #include <stdio.h>
  
    #ifndef EMBEDDED
      #define __THD_INCLUDE_MEMORY_ALLOC
    #endif
    #include "THD_include.h"
    
    #define VERBOSE_ID "#3 : "
  
  #endif /* def __GFX_T6963_COM3_C */

#endif /* ndef  __GFX_T6963_COM3_H */
