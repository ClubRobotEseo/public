/*
 *  Club Robot ESEO 2006 - 2008
 *  Game Hoover - PHOBOSS
 *
 *  Fichier : SuperCAN.c
 *  Package : SuperVision
 *  Description : fonction CAN
 *  Auteur : Kim (retouch� par Jacen) 
 *  Version 20080227
 */

#define __CAN_C

#include "SuperCAN.h"

void initialisationCAN(void)
{
	C1INTF=0;
	IFS1bits.C1IF=0;
	CAN1SetOperationMode(CAN_IDLE_CON &
		CAN_MASTERCLOCK_1 &
		CAN_REQ_OPERMODE_CONFIG &
		CAN_CAPTURE_DIS);
	CAN1Initialize(CAN_SYNC_JUMP_WIDTH1 &
		CAN_BAUD_PRE_SCALE(2),
		CAN_WAKEUP_BY_FILTER_DIS &
		CAN_PHASE_SEG2_TQ(3) &
		CAN_PHASE_SEG1_TQ(3) &
		CAN_PROPAGATIONTIME_SEG_TQ(3) &
		CAN_SEG2_FREE_PROG &
		CAN_SAMPLE3TIMES);
	ConfigIntCAN1(CAN_INDI_INVMESS_DIS &
		CAN_INDI_WAK_DIS &
		CAN_INDI_ERR_DIS &
		CAN_INDI_TXB2_DIS &
		CAN_INDI_TXB1_DIS &
		CAN_INDI_TXB0_DIS &
		CAN_INDI_RXB1_EN &
		CAN_INDI_RXB0_EN ,
		CAN_INT_PRI_3 &
		CAN_INT_ENABLE);

	C1INTF=0;
	IFS1bits.C1IF=0;

	CAN1SetMask(0, CAN_MASK_SID(MASK_CAN_S) & CAN_MATCH_FILTER_TYPE, CAN_MASK_EID(3));

	CAN1SetRXMode(0,CAN_RXFUL_CLEAR & CAN_BUF0_DBLBUFFER_EN);
	CAN1SetRXMode(1,CAN_RXFUL_CLEAR & CAN_BUF0_DBLBUFFER_EN);
	CAN1SetTXMode(0,CAN_TX_STOP_REQ & CAN_TX_PRIORITY_HIGH );
	CAN1SetTXMode(1,CAN_TX_STOP_REQ & CAN_TX_PRIORITY_HIGH );
	CAN1SetTXMode(2,CAN_TX_STOP_REQ & CAN_TX_PRIORITY_HIGH );

	CAN1SetOperationMode(CAN_IDLE_CON & CAN_MASTERCLOCK_1 & CAN_REQ_OPERMODE_NOR & CAN_CAPTURE_DIS);
}

void envoieMessageCAN(Uint16 sid, Uint8* data, Uint8 taille)
{
	while(!CAN1IsTXReady(0));	
	CAN1SendMessage((CAN_TX_SID(sid)) & (CAN_TX_EID_DIS) & (CAN_SUB_NOR_TX_REQ),
					(CAN_TX_EID(12344)) & (CAN_NOR_TX_REQ),data, taille, 0);

}

void receptionMessageCAN(Uint16* sid, Uint8* data, Uint8* taille)
{
	if(C1RX0CONbits.RXFUL==1)
	{
		/* r�ception d'un message dans le buffer RX0 */
		*sid=C1RX0SID>>2;
		*taille=C1RX0DLCbits.DLC;
		CAN1ReceiveMessage(data,*taille,0);
		C1RX0CONbits.RXFUL=0;
		C1INTF=0;
	}
	else if(C1RX1CONbits.RXFUL==1)
	{
		/* r�ception d'un message dans le buffer RX1 */
		*sid=C1RX1SID>>2;
		*taille=C1RX1DLCbits.DLC;
		CAN1ReceiveMessage(data,*taille,1);
		C1RX1CONbits.RXFUL=0;
		C1INTF=0;
	}
	else 
	{
		*sid=0;
		*taille=0;
	}
	return;
}


void _ISR _C1Interrupt(void)
{
	Uint8 dataReceive[8];
	Uint16 sid;
	Uint8 taille;
	Uint8 i;
	
	IFS1bits.C1IF=0;
		
	if (nb_mess_CAN < CAN_BUFFER_SIZE)
	{
		receptionMessageCAN(&sid,dataReceive,&taille);	
		
		if((sid != CARTE_ASSER_POSITION) && (sid != CARTE_P_POSITION_ROBOT)) 
		{
  			buf_CAN[nb_mess_CAN].sid = sid;
  			for(i=0;i<taille;i++) 
				(buf_CAN[nb_mess_CAN].dataReceive)[i] = dataReceive[i];
  			buf_CAN[nb_mess_CAN].taille = taille;
  			nb_mess_CAN++;
    	}
	}
}
