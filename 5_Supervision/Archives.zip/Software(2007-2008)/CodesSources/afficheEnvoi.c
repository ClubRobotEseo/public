#include "interface.h"


const char SWTxtEnvoi[BTN_NUMBER_ENVOI][MAX_ENVOI_LEN] = {
	"Stock flash",
	"Envoi can zigbee",
	"Envoi can serie"
};

const char SWTxtSEnvoi[BTN_NUMBER_ENVOI*2][MAX_ENVOI_LEN] = {
	"Oui",
	"Non",
	"Oui",
	"Non",
	"Oui",
	"Non"
};




void afficheEnvoi(THD_struct *lcd, config* configOn) 
{
	extern Uint8 swBuffer;
	Uint8 smenu=0;

	afficheTxtEnvoi(lcd, configOn);

	while(1) 
	{
		if(isSWEvent(swBuffer)) 
		{
			switch(getSWEvent(swBuffer)) 
			{
				case MASK_TOP:    /* Actions pour haut */
					LED_0 = !LED_0;
					if(isSWOn(MASK_TOP)) 
					{
	    				if(smenu > 0) 
						{
		    				sous_undrawCursDouble(lcd, smenu);
		    				smenu--;
		    				sous_drawCursDouble(lcd, smenu);
		    			}
            		}
				break;
				case MASK_BOT:
					LED_0 = !LED_0;
					if(isSWOn(MASK_BOT)) 
					{
						if(smenu < BTN_NUMBER_ENVOI-1) 
						{
		    				sous_undrawCursDouble(lcd, smenu);
		    				smenu++;
		    				sous_drawCursDouble(lcd, smenu);
						}
            		}
				break;
				case MASK_VALID:
					LED_0 = !LED_0;
					if(isSWOn(MASK_VALID)) 
					{
						LED_1 = 1;
						switch (smenu)
						{
							case 0:
								ssous_undrawCursDouble(lcd,0,configOn->stock_flash);
		    					configOn->stock_flash = !configOn->stock_flash;
		    					ssous_drawCursDouble(lcd,0,configOn->stock_flash);
								break;
							case 1:
								ssous_undrawCursDouble(lcd,1,configOn->envoi_can_zigbee);
		    					configOn->envoi_can_zigbee= !configOn->envoi_can_zigbee;
		    					ssous_drawCursDouble(lcd,1,configOn->envoi_can_zigbee);
								break;
							case 2:
								ssous_undrawCursDouble(lcd,2,configOn->envoi_can_serie);
		    					configOn->envoi_can_serie= !configOn->envoi_can_serie;
		    					ssous_drawCursDouble(lcd,2,configOn->envoi_can_serie);
								break;
							default:
								printf("erreur dans la fonction afficheenvoi");
								break;
						}
					}
				break;
				case MASK_CANCEL:
					LED_0 = !LED_0;
					if(isSWOn(MASK_CANCEL)) 
					{
						LED_1 = 0;
						clearScreen(lcd);
						return;
	   				}
				break;
				/*On met � jour le buffer*/
	      		swBuffer = SW_PORT;
			}
		}
	}
}


void afficheTxtEnvoi(THD_struct *lcd, config* configOn) 
{
	Uint8 i;
	
	for(i=0; i<BTN_NUMBER_ENVOI; i++)
	{
		TXT_SetPos(lcd, THD_pos(STXT_POS_X,STXT_POS_Y+4*i));
		TXT_PrintString(lcd, SWTxtEnvoi[i]);
		GFX_DrawFrame(lcd, THD_pos(SMENU_POS_X+1, SMENU_POS_Y+2+i*2*(SBTN_HEIGHT+BTN_OFFSET_Y)), THD_pos(SMENU_POS_X+SBTN_WIDTH-1, SMENU_POS_Y-2+i*2*(SBTN_HEIGHT+BTN_OFFSET_Y)+SBTN_HEIGHT), SET);
		TXT_SetPos(lcd, THD_pos(STXT_POS_X,STXT_POS_Y+4*i+2));
		TXT_PrintString(lcd, SWTxtSEnvoi[i*2]);
		TXT_SetPos(lcd, THD_pos(STXT_POS_X+10,STXT_POS_Y+4*i+2));
		TXT_PrintString(lcd, SWTxtSEnvoi[i*2+1]);
	}
	sous_drawCursDouble(lcd, 0);
	ssous_drawCursDouble(lcd,0,configOn->stock_flash);
	/*printf("pwet");*/	
	ssous_drawCursDouble(lcd,1,configOn->envoi_can_zigbee);
	ssous_drawCursDouble(lcd,2,configOn->envoi_can_serie);
}
