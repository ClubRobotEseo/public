 /*
 *  Fichier : SuperMAIN.h
 *  Package : SuperVision
 *  Description : MAIN
 *  Auteur : Kim (GAME HOOVER) (modification par Jacen pour PHOBOSS)
 *  Version 20080227
 */


#ifndef __MAIN_H
	#define __MAIN_H

	#define USE_RS232
	#define USE_PORTS
	#define USE_CAN
  	#define USE_UART
	#define USE_THACID
	#define USE_EVT_BOUTON
	#include "QS_all.h"
	#include "delay.h"
	#include "THD_advanced.h"
	#include "THD_SYS_types.h"
	#include "Constantes.h"
	#include "config_struct.h"
	extern config configOn;

	/*Relatif au main.c partie priv�e*/
	#ifdef __MAIN_C	
		#include "QS_configBits.h"
	    #include <stdio.h> /* for printf */

		/* la configuration de la carte par l'utilisateur */
		config configOn = {0, 0, 0, 1, 1, 0, 0, 0, 0};
		
		/*Machine d'�tat*/
		typedef enum 
		{
			ENVOI_JIT, /* envoi just in time : � la vol�e */
			ENVOI_VOD, /* video on demand : sur pression du bouton */
			ENVOI_VOD_REV, /* pareille mais on revient en arriere */
			ENVOI_RS232, /* on envoie tout sur le port serie */
			WAITING /* on ne fait rien */
	  	}e_etat;

		#define TOP 7
		#define BOT 11
		#define VALID 13
		#define CANCEL 14

		int main(void);
		e_etat majEtat(e_etat previous_state);

		/* Definition du tas */
		__asm__(".global HEAPSIZE");
		__asm__(".equiv HEAPSIZE,0x100");
	#endif

#endif
