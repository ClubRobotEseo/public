/*
 *  Club Robot ESEO 2007 - 2008
 *  Phoboss
 *
 *  Fichier : nomenclatureCAN.h
 *  Package : 
 *  Description : Nomenclature des messages CAN
 *  Auteur : Samuel Martin
 *  Version 20080308
 */

#ifndef __NOMENCLATURE_CAN_H_
	#define __NOMENCLATURE_CAN_H_

/* Codes et messages CAN correspondants */

		/* Carte asser vers carte P */
#define CAN_CODE_0x081 				0x081
#define CAN_MESG_0x081 				"CARTE_P_TRAJ_FINIE"
#define CAN_DATA_0x081(pos) 		"DATA -> X:%d Y:%d A:%.2f \n\r",pos.x,pos.y,pos.a

#define CAN_CODE_0x082 				0x082
#define CAN_MESG_0x082				"CARTE_P_ASSER_ERREUR"
#define CAN_DATA_0x082(pos) 		"DATA -> X:%d Y:%d A:%.2f \n\r",pos.x,pos.y,pos.a

#define CAN_CODE_0x083	 			0x083
#define CAN_MESG_0x083				"CARTE_P_POSITION_ROBOT"
#define CAN_DATA_0x083(pos) 		"DATA -> X:%d Y:%d A:%.2f \n\r",pos.x,pos.y,pos.a

#define CAN_CODE_0x084				0x084
#define CAN_MESG_0x084				"CARTE_P_ROBOT_FREINE"
#define CAN_DATA_0x084				" "

		/*Carte M vers carteP */
#define CAN_CODE_0x085				0x085
#define CAN_MESG_0x085 				"UNUSED_085"
#define CAN_DATA_0x085				" "

#define CAN_CODE_0x086 				0x086
#define CAN_MESG_0x086				"CARTE_P_BALLE_IN_FOURCHE"
#define CAN_DATA_0x086				" "

#define CAN_CODE_0x087				0x087
#define CAN_MESG_0x087				"CARTE_P_PROBLEME"
#define CAN_DATA_0x087				" "

#define CAN_CODE_0x088				0x088
#define CAN_MESG_0x088				"UNUSED_088"
#define CAN_DATA_0x088				" "

  		/* Carte P vers carte asser */
#define CAN_CODE_0x101		 		0x101
#define CAN_MESG_0x101				"CARTE_ASSER_GO_POSITION"
#define CAN_DATA_0x101(data,pos)	"DATA -> X:%d Y:%d %s %s \n\r",pos.x,pos.y,(data[4]==0)?"AVANT":"ARRIERE",(data[5]==0)?"RAPIDE":"LENT"

#define CAN_CODE_0x102				0x102
#define CAN_MESG_0x102				"CARTE_ASSER_VITESSE"
#define	CAN_DATA_0x102(data)		"DATA -> %s \n\r",(data[0]==0)?"RAPIDE":"LENT"

#define CAN_CODE_0x103				0x103
#define CAN_MESG_0x103				"CARTE_ASSER_STOP"
#define CAN_DATA_0x103				" "

#define CAN_CODE_0x104				0x104
#define CAN_MESG_0x104				"CARTE_ASSER_GO_ANGLE"
#define	CAN_DATA_0x104(data)		"DATA -> A:%.2f \n\r",((double)((data[0]<<8)|data[1]))/4096

#define CAN_CODE_0x106				0x106
#define CAN_MESG_0x106				"CARTE_ASSER_CONTI_MULTI"
#define CAN_DATA_0x106(pos)			"DATA -> X:%d Y:%d \n\r",pos.x,pos.y

#define CAN_CODE_0x107				0x107
#define CAN_MESG_0x107				"CARTE_ASSER_STOP_MULTI"
#define CAN_DATA_0x107(data)		"DATA -> %s \n\r",(data[0]==0)?"RAPIDE":"LENT"

#define CAN_CODE_0x108				0x108
#define CAN_MESG_0x108				"CARTE_ASSER_COULEUR"
#define CAN_DATA_0x108(data)		"DATA -> %s \n\r",(data[0]==0)?"ROUGE":"BLEU"	

#define CAN_CODE_0x109				0x109
#define CAN_MESG_0x109				"CARTE_ASSER_POSITION"
#define CAN_DATA_0x109				" "

#define CAN_CODE_0x110				0x110
#define CAN_MESG_0x110				"UNUSED_110"
#define CAN_DATA_0x110				" "

#define CAN_CODE_0x111				0x111
#define CAN_MESG_0x111				"UNUSED_111"
#define CAN_DATA_0x111				" "


		/* Carte P vers Carte M*/
#define CAN_CODE_0x150				0x150
#define CAN_MESG_0x150				"UNUSED_150"
#define CAN_DATA_0x150				" "

#define CAN_CODE_0x181				0x181
#define CAN_MESG_0x181				"CARTE_ACT_BRAS_GAUCHE"
#define CAN_DATA_0x181				" "

#define CAN_CODE_0x182				0x182
#define CAN_MESG_0x182				"CARTE_ACT_BRAS_DROIT"
#define CAN_DATA_0x182				" "

#define CAN_CODE_0x183				0x183
#define CAN_MESG_0x183				"CARTE_ACT_ROULEAU_EJECTE"
#define CAN_DATA_0x183				" "

#define CAN_CODE_0x184				0x184
#define CAN_MESG_0x184				"CARTE_ACT_ROULEAU_AVALE"
#define CAN_DATA_0x184				" "

#define CAN_CODE_0x185				0x185
#define CAN_MESG_0x185				"CARTE_ACT_ENFOURCHE"
#define CAN_DATA_0x185				" "

#define CAN_CODE_0x186				0x186
#define CAN_MESG_0x186				"CARTE_ACT_ON_OFF_ASCENSEUR"
#define CAN_DATA_0x186				" "

#define CAN_CODE_0x187				0x187
#define CAN_MESG_0x187				"CARTE_ACT_POS_BARILLET"
#define CAN_DATA_0x187				" "

#define CAN_CODE_0x188				0x188
#define CAN_MESG_0x188				"CARTE_ACT_EJECTE_BALLE"
#define CAN_DATA_0x188				" "


		/* Broadcast */
#define CAN_CODE_0x790				0x790
#define CAN_MESG_0x790				"BROADCAST_START"
#define CAN_DATA_0x790				" "

#define CAN_CODE_0x7A0				0x7A0
#define CAN_MESG_0x7A0				"BROADCAST_STOP_ALL"
#define CAN_DATA_0x7A0				" "




#endif /* __NOMENCLATURE_CAN_H_ */
