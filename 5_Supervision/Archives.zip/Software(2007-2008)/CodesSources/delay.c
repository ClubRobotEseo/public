#include "delay.h"


void DelayUs(Uint32 cpt){
	Uint32 i;
	cpt=cpt/2;
	for(i=0;i<cpt;i++);
	return;
}

void DelayMs(Uint32 cpt){
	Uint32 i;
	cpt=cpt;
	for(i=0;i<cpt;i++)
		DelayUs(1250);
	return;
}
