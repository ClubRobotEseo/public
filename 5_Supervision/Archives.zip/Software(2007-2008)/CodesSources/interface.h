#ifndef INTERFACE_H_
#define INTERFACE_H_

	#include "THD_advanced.h"
	#include "THD_SYS_types.h"
	#include <stdio.h>
	#include "Constantes.h"
	#include "config_struct.h"

	/*D�finition des masques de boutons*/
	#define MASK_TOP	0x8
	#define MASK_BOT	0x4
	#define MASK_VALID	0x2
	#define MASK_CANCEL	0x1

	#define isSWEvent(buffer) (SW_PORT == buffer ? 0 : 1)
	#define isSWOn(mask) !(SW_PORT & mask)
	#define getSWEvent(buffer) (SW_PORT^buffer)

	typedef struct {
		Uint8 pos_x;
		Uint8 pos_y;
		char *text;
	} IButton;
	void drawMenu(THD_struct *lcd);
	void drawCurs(THD_struct *lcd, Uint8 page);
	void undrawCurs(THD_struct *lcd, Uint8 page);
	void printTitle(THD_struct *lcd, Uint8 page);
	void eraseTitle(THD_struct *lcd);
	void affichage(THD_struct *lcd, config* configOn);
	Uint8 afficheMenu(THD_struct *lcd, Uint8 page);
	void afficheTxtMenu(THD_struct *lcd, Uint8 page);
	void affichePret(THD_struct *lcd, config* configOn);
	void affichePreconf(THD_struct *lcd, config* configOn);
	void afficheTxtPreconf(THD_struct *lcd, config* configOn);
	void afficheConfig(THD_struct *lcd, config* configOn);
	void afficheTxtConfig(THD_struct *lcd, config* configOn);
	void afficheEnvoi(THD_struct *lcd, config* configOn);
	void afficheTxtEnvoi(THD_struct *lcd, config* configOn);
	void afficheStrateg(THD_struct *lcd, config* configOn);
	void afficheTxtStrateg(THD_struct *lcd, config* configOn);
	void afficheLecture(THD_struct *lcd);
	void active_choice(THD_struct *lcd, Uint8 smenu);
	void unactive_choice(THD_struct *lcd, Uint8 smenu);
	void sous_drawCurs(THD_struct *lcd, Uint8 sous_menu_select);
	void sous_drawCursDouble(THD_struct *lcd, Uint8 sous_menu_select);
	void sous_undrawCursDouble(THD_struct *lcd, Uint8 sous_menu_select);
	void sous_undrawCurs(THD_struct *lcd, Uint8 sous_menu_select);
	void ssous_undrawCursDouble(THD_struct *lcd, Uint8 ligne, Uint8 valeur);
	void ssous_drawCursDouble(THD_struct *lcd, Uint8 ligne, Uint8 valeur);
	void clearScreen(THD_struct *lcd);
#endif
