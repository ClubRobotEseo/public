#include "interface.h"

const char SWTxtConfig[BTN_NUMBER_CONFIG][MAX_STXT_LEN] = {
     "Couleur",
     "Recalage",
     "Clicodrome"
};

const char SWTxtSConfig[BTN_NUMBER_CONFIG*2][MAX_STXT_LEN] = {
	"Rouge",
	"Bleu",
	"Oui",
	"Non",
	"Actif",
	"Inactif"
};




void afficheConfig(THD_struct *lcd, config* configOn) 
{
	extern Uint8 swBuffer;

	Uint8 smenu=0;

	afficheTxtConfig(lcd, configOn);

	while(1) 
	{
		if(isSWEvent(swBuffer)) 
		{
			switch(getSWEvent(swBuffer)) 
			{
				case MASK_TOP:    /* Actions pour haut*/
					LED_0 = !LED_0;
					if(isSWOn(MASK_TOP)) 
					{
	    				if(smenu > 0) 
						{
		    				sous_undrawCursDouble(lcd, smenu);
		    				smenu--;
		    				sous_drawCursDouble(lcd, smenu);
		    			}
            		}
				break;
				case MASK_BOT:
					LED_0 = !LED_0;
					if(isSWOn(MASK_BOT)) 
					{
						if(smenu < BTN_NUMBER_CONFIG-1) 
						{
		    				sous_undrawCursDouble(lcd, smenu);
		    				smenu++;
		    				sous_drawCursDouble(lcd, smenu);
						}
            		}
				break;
				case MASK_VALID:
					LED_0 = !LED_0;
					if(isSWOn(MASK_VALID)) 
					{
						LED_1 = 1;
						switch(smenu) 
						{
							case 0:
								ssous_undrawCursDouble(lcd,0,configOn->couleur);
		    					configOn->couleur=!configOn->couleur;
		    					ssous_drawCursDouble(lcd,0,configOn->couleur);
								break;
							case 1:
								ssous_undrawCursDouble(lcd,1,configOn->recalage);
		    					configOn->recalage=!configOn->recalage;
		    					ssous_drawCursDouble(lcd,1,configOn->recalage);
								break;
							case 2:
								ssous_undrawCursDouble(lcd,2,configOn->clicodrome);
		    					configOn->clicodrome=!configOn->clicodrome;
		    					ssous_drawCursDouble(lcd,2,configOn->clicodrome);
								break;
							default:
								printf("erreur dans la fonction afficheConfig");
								break;
						}
					}
				break;
				case MASK_CANCEL:
					LED_0 = !LED_0;
					if(isSWOn(MASK_CANCEL)) 
					{
						LED_1 = 0;
						clearScreen(lcd);
						return;
	   				}
				break;
				/*On met � jour le buffer*/
	      		swBuffer = SW_PORT;
			}
		}
	}
}

void afficheTxtConfig(THD_struct *lcd, config* configOn) 
{
	Uint8 i;
	
	for(i=0; i<BTN_NUMBER_CONFIG; i++)
	{
		TXT_SetPos(lcd, THD_pos(STXT_POS_X,STXT_POS_Y+4*i));
		TXT_PrintString(lcd, SWTxtConfig[i]);
		GFX_DrawFrame(lcd, THD_pos(SMENU_POS_X+1, SMENU_POS_Y+2+i*2*(SBTN_HEIGHT+BTN_OFFSET_Y)), THD_pos(SMENU_POS_X+SBTN_WIDTH-1, SMENU_POS_Y-2+i*2*(SBTN_HEIGHT+BTN_OFFSET_Y)+SBTN_HEIGHT), SET);
		TXT_SetPos(lcd, THD_pos(STXT_POS_X,STXT_POS_Y+4*i+2));
		TXT_PrintString(lcd, SWTxtSConfig[i*2]);
		TXT_SetPos(lcd, THD_pos(STXT_POS_X+10,STXT_POS_Y+4*i+2));
		TXT_PrintString(lcd, SWTxtSConfig[i*2+1]);
	}
	ssous_drawCursDouble(lcd,0,configOn->couleur);
	ssous_drawCursDouble(lcd,1,configOn->recalage);
	ssous_drawCursDouble(lcd,2,configOn->clicodrome);
	sous_drawCursDouble(lcd, 0);
}
