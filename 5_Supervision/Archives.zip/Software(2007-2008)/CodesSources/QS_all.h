/*
 *  Club Robot ESEO 2006 - 2007
 *  Game Hoover
 *
 *  Fichier : QS_all.h
 *  Package : Qualit�Soft
 *  Description : Header g��ale pour tout code du robot
 *  Auteur : Axel Voitier
 *  Version 20070129
 */

#ifndef __QS_ALL_H
  #define __QS_ALL_H

  #include "QS_config.h" /* On charge d'abord la configuration g��ale */

  #if defined(MATCH_MODE) || defined(TEST_MODE)
    #include <p30f6010a.h>
  #endif

  #include "QS_types.h"
  #include "QS_macro.h"
  #include "leds.h"

  #ifdef USE_PORTS
	#include "QS_ports.h"
  #endif
  #ifdef USE_THACID
    #include "THD_advanced.h"
  #endif
  #ifdef USE_UART
	#include "SuperRS232.h"
  #endif
  #ifdef USE_CAN
    #include "superCAN.h"
  #endif
  #ifdef USE_MAIN
    #include "superMAIN.h"
  #endif
  #ifdef USE_MSGCAN
    #include "TraitmntMsgCAN.h"
  #endif
  #ifdef USE_EVT_BOUTON
    #include "interface.h"
	#include "leds.h"
  #endif
#endif

