/*
 *  Club Robot ESEO 2006 - 2007
 *  Game Hoover
 *
 *  Fichier : QS_macro.h
 *  Package : Qualit� Soft
 *  Description : D�finition des types pour tout code du robot
 *  Auteur : Axel Voitier (et un peu savon aussi)
 *  Version 20070129
 */

#ifndef __QS_MACRO_H
  #define __QS_MACRO_H

  #define HIGHINT(x)			((x >> 8) & 0xFF)
  #define LOWINT(x)			(x & 0xFF)

  #define BITS_ON(var, mask)		(var |= mask)
  #define BITS_OFF(var, mask)		(var &= ~0 ^ mask)
  #define BIT_SET(var, bitno)		((var) |= 1 << (bitno))
  #define BIT_CLR(var, bitno)		((var) &= ~(1 << (bitno)))
  #define BIT_TEST(data, bitno)		((data >> bitno) & 0x01)

  #define MIN(a, b)			(((a) > (b)) ? (b) : (a))
  #define MAX(a, b)			(((a) > (b)) ? (a) : (b))

#endif
