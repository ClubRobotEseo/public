/*
 *  Club Robot ESEO 2006 - 2007
 *  Game Hoover
 *
 *  Fichier : SuperRS232.c
 *  Package : SuperVision
 *  Description : fonction rs232 uart1
 *  Auteur : Kim
 *  Version 20070211
 */

#define __RS232_C

#include "SuperRS232.h"

void putc_Serie(Uint8 mes)
{
	while(BusyUART1());
	putcUART1(mes);	
}

void UART_init(void)
{
	Sint16 U1MODEvalue;
	Sint16 U1STAvalue;
	U1MODEvalue = UART_EN & UART_IDLE_CON &
		UART_DIS_WAKE & UART_DIS_LOOPBACK &
		UART_DIS_ABAUD & UART_NO_PAR_8BIT &
		UART_1STOPBIT;
	U1STAvalue = UART_INT_TX &
		UART_TX_PIN_NORMAL &
		UART_TX_ENABLE &
		UART_INT_RX_CHAR &
		UART_ADR_DETECT_DIS &
		UART_RX_OVERRUN_CLEAR ;
	OpenUART1(U1MODEvalue, U1STAvalue, 64);  /*Vitesse 16 -> 34800bps 64-> 9600*/ 
	DisableIntU1RX;
	DisableIntU1TX;
	ConfigIntUART1(UART_RX_INT_EN & UART_RX_INT_PR4 &
		UART_TX_INT_DIS & UART_TX_INT_PR3);
}


void _ISR _U1RXInterrupt(void)
{
	Uint8 Buf[12]; /* la taille d'un message CAN */
	Uint8 * Receiveddata = Buf;
	
	while( DataRdyUART1())
	{
		*(Receiveddata++) = ReadUART1();

		/* pour eviter les comportements ind�sirables */
		if (Receiveddata - Buf >= 12)
			Receiveddata = Buf;
	}
	
	if (configOn.clicodrome)
	{
		/* CARTE_ASSER_GO_POSITION ...*/
		envoieMessageCAN(0x101, Buf, 4);
	}

	IFS0bits.U1RXIF = 0;
}
