#ifndef __QS_CONFIGBITS_H
  #define __QS_CONFIGBITS_H

  #ifndef __MAIN_C
	#error "Ne peut �tre inclu que dans le cadre du fichier main.c"
  #endif

  #if defined(MATCH_MODE) || defined(TEST_MODE)
	/* Bits de configuration du dsPIC .
       A besoin de se trouver apr�s le header du pic
	   et seulement une fois dans le projet (classiquement la main) */
	_FOSC(CSW_FSCM_OFF & XT_PLL4) /* XT PLL x4 & Failsafe clock off */
	_FWDT(WDT_OFF) /* WatchDog off */
	_FBORPOR(PBOR_OFF & MCLR_EN) /* MCLR activ� & */
	_FGS(CODE_PROT_OFF) /* Disable code protection */
  #endif

#endif

