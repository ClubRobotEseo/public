/*
 *  Club Robot ESEO 2006 - 2007
 *  Game Hoover
 *
 *  Fichier : SuperRS232.c
 *  Package : SuperVision
 *  Description : fonction rs232
 *  Auteur : Kim
 *  Version 20070211
 */
 

#ifndef __RS232_H
	#define __RS232_H
	
	#define USE_MSGCAN
	#define USE_MAIN
	#define USE_CAN
	#include "QS_all.h"

	void putc_Serie(Uint8 mes);
	void UART_init(void);
	void _ISR _U1RXInterrupt(void);

	#ifdef __RS232_C
		#include <uart.h>
		/* la configuration de la carte par l'utilisateur */
		extern config configOn;

		/* Definition du tas */
		__asm__(".global HEAPSIZE");
		__asm__(".equiv HEAPSIZE,0x100");
	#endif
#endif

