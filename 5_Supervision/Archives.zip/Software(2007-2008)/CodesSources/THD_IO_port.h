/*
 *  THD_IO_port.h: header file for Input/Output port functions
 *  Part of ThacidLCD package
 *  Copyright 2001-2005  Axel Voitier
 *  
 *  deadog@users.sourceforge.net
 *  
 *  This software is a computer program whose purpose is to control liquid crystal displays.
 *  
 *  This software is governed by the CeCILL  license under French law and
 *  abiding by the rules of distribution of free software.  You can  use, 
 *  modify and/ or redistribute the software under the terms of the CeCILL
 *  license as circulated by CEA, CNRS and INRIA at the following URL
 *  "http://www.cecill.info". 
 *  
 *  As a counterpart to the access to the source code and  rights to copy,
 *  modify and redistribute granted by the license, users are provided only
 *  with a limited warranty  and the software's author,  the holder of the
 *  economic rights,  and the successive licensors  have only  limited
 *  liability. 
 *  
 *  In this respect, the user's attention is drawn to the risks associated
 *  with loading,  using,  modifying and/or developing or reproducing the
 *  software by the user in light of its specific status of free software,
 *  that may mean  that it is complicated to manipulate,  and  that  also
 *  therefore means  that it is reserved for developers  and  experienced
 *  professionals having in-depth computer knowledge. Users are therefore
 *  encouraged to load and test the software's suitability as regards their
 *  requirements in conditions enabling the security of their systems and/or 
 *  data to be ensured and,  more generally, to use and operate it in the 
 *  same conditions as regards security. 
 *  
 *  The fact that you are presently reading this means that you have had
 *  knowledge of the CeCILL license and that you accept its terms.
 */

#ifndef __THD_IO_PORT_H
  #define __THD_IO_PORT_H

  #include "THD_SYS_types.h"
  
  typedef Uint16 THD_addr_port_t;
  typedef Uint8 THD_size_port_t;
  
  #define ACCESS_REG(addr) *((volatile THD_addr_port_t * const) addr)
  
  typedef enum {
    DATA,
    CONTROL
  } THD_port_type_e;
  
  typedef enum {
    INPUT,
    OUTPUT,
    NOT_INITIALIZED
  } THD_port_status_e;
  
  typedef struct THD_port_t {
    THD_addr_port_t addr;
    THD_port_status_e status;
    THD_port_type_e type;
    struct THD_port_t *control_port;
  } THD_port_t;
  
  #ifdef __cplusplus
  extern "C" {
  #endif
  
  THD_port_t *THD_IO_Init_Port (THD_addr_port_t addr, THD_port_type_e type, THD_port_t *control_port);
  THD_bool THD_IO_Destroy_Port (THD_port_t *port);
  THD_bool THD_IO_SetStatus_Port (THD_port_t *port, THD_port_status_e status);
  THD_size_port_t THD_IO_Read_Port (THD_port_t *port);
  void THD_IO_Send_Port (THD_port_t *port, THD_size_port_t data);
  
  #ifdef __cplusplus
      }
  #endif
  
  typedef enum {
    BIT_LOW,
    BIT_HIGH,
    BIT_FIX
  } THD_bit_status_e;
  
  typedef enum {
    PIN_1,
    PIN_2,
    PIN_3,
    PIN_4,
    PIN_5,
    PIN_6,
    PIN_7,
    PIN_8,
    NOT_WIRED
  } THD_bit_list_e;
  
  typedef struct {
    THD_port_t *port;
    THD_bit_list_e pin;
    THD_size_port_t set_mask, raz_mask;
    THD_bit_status_e status;
  } THD_bit_t;
  
  #ifdef __cplusplus
  extern "C" {
  #endif

  THD_bit_t *THD_IO_Init_Bit (THD_port_t *port, THD_bit_list_e pin);
  THD_bool THD_IO_Destroy_Bit (THD_bit_t *bit);
  THD_size_port_t THD_IO_GetSetMask_Bit (THD_bit_list_e pin);
  THD_size_port_t THD_IO_GetStatusMask_Bit (THD_bit_t *bit, THD_bit_status_e status, THD_size_port_t base);
  
  #ifdef __cplusplus
      }
  #endif
  
  #ifdef __THD_IO_PORT_C
    
    #define NB_SINGLETON_PORT (Uint8) 4
    THD_port_t port_pool[NB_SINGLETON_PORT];
    Uint8 singleton_port_used=0;
    
    #define NB_SINGLETON_BIT (Uint8) 4
    THD_bit_t bit_pool[NB_SINGLETON_BIT];
    Uint8 singleton_bit_used=0;
  
  #endif /* def __THD_IO_PORT_C */

#endif /* ndef __THD_IO_PORT_H */

/*
====== system/.../THD_IO_port ======

===== Summary =====

This file provided communications through port functions.

===== Definitions =====

^  Return type  ^  Function name  ^  Arguments  ^
| [[#THD_port_t|THD_port_t]] * | [[#THD_IO_Init_Port|THD_IO_Init_Port]] | ([[#THD_addr_port_t|THD_addr_port_t]] addr, [[#THD_port_type_e|THD_port_type_e]] type, [[#THD_port_t|THD_port_t]] *control_port); |
| [[libthacidlcd:userdoc:functions:thd_sys_types#THD_bool|THD_bool]] | [[#THD_IO_Destroy_Port|THD_IO_Destroy_Port]] | ([[#THD_port_t|THD_port_t]] *port); |
| [[libthacidlcd:userdoc:functions:thd_sys_types#THD_bool|THD_bool]] | [[#THD_IO_SetStatus_Port|THD_IO_SetStatus_Port]] | ([[#THD_port_t|THD_port_t]] *port, [[#THD_port_status_e|THD_port_status_e]] status); |
| [[#THD_size_port_t|THD_size_port_t]] | [[#THD_IO_Read_Port|THD_IO_Read_Port]] | ([[#THD_port_t|THD_port_t]] *port); |
| void | [[#THD_IO_Send_Port|THD_IO_Send_Port]] | ([[#THD_port_t|THD_port_t]] *port, [[#THD_size_port_t|THD_size_port_t]] data); |
| [[#THD_bit_t|THD_bit_t]] * | [[#THD_IO_Init_Bit|THD_IO_Init_Bit]] | ([[#THD_port_t|THD_port_t]] *port, [[#THD_bit_list_e|THD_bit_list_e]] pin); |
| [[libthacidlcd:userdoc:functions:thd_sys_types#THD_bool|THD_bool]] | [[#THD_IO_Destroy_Bit|THD_IO_Destroy_Bit]] | ([[#THD_bit_t|THD_bit_t]] *bit); |
| [[#THD_size_port_t|THD_size_port_t]] | [[#THD_IO_GetSetMask_Bit|THD_IO_GetSetMask_Bit]] | ([[#THD_bit_list_e|THD_bit_list_e]] pin); |
| [[#THD_size_port_t|THD_size_port_t]] | [[#THD_IO_GetStatusMask_Bit|THD_IO_GetStatusMask_Bit]] | ([[#THD_bit_t|THD_bit_t]] *bit, [[#THD_bit_status_e|THD_bit_status_e]] status, [[#THD_size_port_t|THD_size_port_t]] base); |

----

==== THD_addr_port_t ====

<code c>
typedef Uint16 THD_addr_port_t;
</code>

//THD_addr_port_t// is the type for a port address.

----

==== THD_size_port_t ====

<code c>
typedef Uint8 THD_size_port_t;
</code>

//THD_size_port_t// is the type for a port size.

----

==== THD_port_type_e ====

<code c>
typedef enum {
  DATA,
  CONTROL
} THD_port_type_e;
</code>

//THD_port_type_e// is the type for a port mode.

//DATA// describe a data port.\\
//CONTROL// describe a control port.

A port could be both DATA and CONTROL, but for that you must declare two [[#THD_port_t|THD_port_t]].

----

==== THD_port_status_e ====

<code c>
typedef enum {
  INPUT,
  OUTPUT,
  NOT_INITIALIZED
} THD_port_status_e;
</code>

//THD_port_status_e// is the type for a port status.

//INPUT// describe a port that receive data.\\
//OUTPUT// descibe a port that send data.\\
//NOT_INITIALIZED// is a not specified port status.

When a port have a //NOT_INITIALIZED// state, it couldn't send or receive data.\\
If in an implementation a port could have both INPUT and OUTPUT state at the same time, then the impementation must ignore this parameter.

----

==== THD_port_t ====

<code c>
typedef struct THD_port_t {
  THD_addr_port_t addr;
  THD_port_status_e status;
  THD_port_type_e type;
  struct THD_port_t *control_port;
} THD_port_t;
</code>

//THD_port_t// is the type for a port.\\
It contains all informations relative to a port (address with //addr//, status with //status//, type with //type//, and associed control port for a data port with //control_port//).

----

==== THD_bit_status_e ====

<code c>
typedef enum {
  BIT_LOW,
  BIT_HIGH,
  BIT_FIX
} THD_bit_status_e;
</code>

//THD_bit_status_e// is the type for a bit status.

//BIT_LOW// describe the low status for a bit.
//BIT_HIGH// describe the high status for a bit.
//BIT_FIX// is use when a bit of a byte must keep its actual value.

----

==== THD_bit_list_e ====

<code c>
typedef enum {
  ...,
  NOT_WIRED
} THD_bit_list_e;
</code>

//THD_bit_list_e// is the type for a list of control bits.\\
It is platform dependant.\\

//NOT_WIRED// describe a bit not wired between the LCD module and the processor (or program executor).\\
It is platform independant bit type, so you can always find it.

----

==== THD_bit_t ====

<code c>
typedef struct {
  THD_port_t *port;
  THD_bit_list_e pin;
  THD_size_port_t set_mask, raz_mask;
  THD_bit_status_e status;
} THD_bit_t;
</code>

//THD_bit_t// is the type for a bit.\\
It contains all informations relative to a bit (its port with //port//, its placement with //pin// and its status with //status//).

//set_mask// and //raz_mask// are logical masks for lower or raise the bit, defined by the [[#THD_IO_Init_Bit|THD_IO_Init_Bit]] function.

===== Functions =====

==== THD_IO_Init_Port ====

<code c>
THD_port_t *
THD_IO_Init_Port (
  THD_addr_port_t addr,
  THD_port_type_e type,
  THD_port_t *control_port)
</code>

This function create and initialize a port structure.

//addr// is the port address.\\
//type// specify if its a data port or a control port.\\
//control_port// must be set when //type// is DATA, it is the port that control the state (INPUT/OUPUT) of a data port.

Returns the new port structure.

----

==== THD_IO_Destroy_Port ====

<code c>
THD_bool
THD_IO_Destroy_Port (
  THD_port_t *port)
</code>

This function terminate and free a port structure.

//port// is the port structure to destroy.

Returns THD_FALSE if error, THD_TRUE if not.

----

==== THD_IO_SetStatus_Port ====

<code c>
THD_bool
THD_IO_SetStatus_Port (
  THD_port_t *port,
  THD_port_status_e status)
</code>

This function allow to change the port status to INPUT or OUTPUT.\\
Its have action only on DATA ports.

//port// is a DATA port to modify.\\
//status// is the new status to apply.

Returns THD_FALSE if error, THD_TRUE if not.

----

==== THD_IO_Read_Port ====

<code c>
THD_size_port_t
THD_IO_Read_Port (
  THD_port_t *port)
</code>

This function read data on a port.\\
If //port// is a DATA port, this function will check if its state is INPUT.

//port// to reading.

Returns data read on the port.

----

==== THD_IO_Send_Port ====

<code c>
void
THD_IO_Send_Port (
  THD_port_t *port,
  THD_size_port_t data)
</code>

This function send data on aport.\\
If //port// is a DATA port, this function will check if its state is OUTPUT.

//port// where the datawill be send.\\
//data// to sending.

Returns nothing.

----

==== THD_IO_Init_Bit ====

<code c>
THD_bit_t *
THD_IO_Init_Bit (
  THD_port_t *port,
  THD_bit_list_e pin)
</code>

This function create and initialize a bit structure.

//port// is the port where the bit is effective.\\
//pin// specify the "pin" on the port.

Returns the new bit structure.

----

==== THD_IO_Destroy_Bit ====

<code c>
THD_bool
THD_IO_Destroy_Bit (
  THD_bit_t *bit)
</code>

This function free a bit structure.

//bit// is the bit structure to destroy.

Returns THD_FALSE if error, THD_TRUE if not.

----

==== THD_IO_GetSetMask_Bit ====

<code c>
THD_size_port_t
THD_IO_GetSetMask_Bit (
  THD_bit_list_e pin)
</code>

This function returns the set_mask of a bit.\\
Its a platform dependant information.\\
The raz_mask could be determinate by the negation operation :
  raz_mask = ~set_mask;

//pin// is the pin concerned.

Returns the corresponding set_mask.

----

==== THD_IO_GetStatusMask_Bit ====

<code c>
THD_size_port_t
THD_IO_GetStatusMask_Bit (
  THD_bit_t *bit,
  THD_bit_status_e status,
  THD_size_port_t base)
</code>

This function returns the mask for change the state of a bit on a port.

//bit// is the bit to change.\\
//status// is the new state for the bit.\\
//base// is the actual data on the port concerned.

Returns the corresponding mask

----

 --- //[[lexa@nerim.net|Axel Voitier (deadog)]] 2005/07/18 13:16//
*/
