/*
 *	Club Robot ESEO 2010 - 2011
 *	Chek'Norris
 *
 *	Fichier : Selftest.c
 *	Package : Supervision
 *	Description : Envoi et r�ception des messages de selftest.
 *	Auteur : Ronan & Patman
 *	Version 20110120
 */

#define SELFTEST
#define TEMPS_WATCHDOG_ACT 30000	// en ms
#define TEMPS_WATCHDOG_STRAT 1000	// en ms
#define TEMPS_WATCHDOG_ASSER 10000	// en ms
#define TEMPS_WATCHDOG_BALISE 12000	// en ms
#include "Selftest.h"	

void SELFTEST_init()
{
	WATCHDOG_init();
	LED_init();
	
	// initialisation des r�sultats des tests unitaires de chaque module � ERREUR
	// (voir d�finition des tests dans structure test_carte_t dans le header Global_vars_types.h)
	global.test_cartes.etat_moteur_gche = ERREUR;
	global.test_cartes.etat_moteur_dt = ERREUR;
	global.test_cartes.etat_roue_codeuse_gche = ERREUR;
	global.test_cartes.etat_roue_codeuse_dte = ERREUR;
	global.test_cartes.etats_capteurs = ERREUR;
	global.test_cartes.biroute_placee = ERREUR;
	global.test_cartes.etat_balise_ir = ERREUR;
	global.test_cartes.etat_balise_us = ERREUR;
	global.test_cartes.synchro_balise = ERREUR;
	
	global.test_selftest_enable = FALSE;
	
	// initialisation des flags correspondant aux timeout pour les tests de chaque module
	global.flag_act = FALSE;
	global.flag_strat = FALSE;
	global.flag_asser = FALSE;
	global.flag_beacon = FALSE;
	
	// initialisation des r�sultats des tests globales de tous les modules � FALSE
	global.test_cartes.test_strat = FALSE;
	global.test_cartes.test_asser = FALSE;
	global.test_cartes.test_act = FALSE;
	global.test_cartes.test_balise = FALSE;
}

void SELFTEST_update(CAN_msg_t* CAN_msg_received)
{
	static enum
	{
		ATTENTE_APPUI_BOUTON,
		ENVOI_MESSAGE_ACT,
		ATTENTE_REPONSE_ACT,
		ENVOI_MESSAGE_STRAT,
		ATTENTE_REPONSE_STRAT,
		ENVOI_MESSAGE_ASSER,
		ATTENTE_REPONSE_ASSER,
		ENVOI_MESSAGE_BALISE,
		ATTENTE_REPONSE_BALISE,
		PROCEDURE_TERMINEE
	} etat = 0;
	
	Uint8 erreur_reception_ir,erreur_reception_us;
	Uint16 distance_mm;
	Uint8 etat_synchro;
	
	static Uint8 fin_test_balise = 0;
	static watchdog_id_t watchdog_selftest;
	CAN_msg_t CAN_msg_sent;
	
	switch(etat)
	{
		case ATTENTE_APPUI_BOUTON:
			if(global.test_selftest_enable && !global.match_started)
			{
				debug_printf("\r\n_________________________ SELFTEST __________________________\r\n\r\n");
				LED_init();
				etat = ENVOI_MESSAGE_ACT;
				//etat = ENVOI_MESSAGE_STRAT;
			}	
			break;
			
		case ENVOI_MESSAGE_ACT:
			CAN_msg_sent.sid = SUPER_ASK_ACT_SELFTEST;
			CAN_msg_sent.size = 0;
			debug_printf("-> demande selftest carte actionneur\r\n");
			CAN_send(&CAN_msg_sent);
			watchdog_selftest = WATCHDOG_create_flag(TEMPS_WATCHDOG_ACT, (bool_e*) &(global.flag_act));
			etat = ATTENTE_REPONSE_ACT;
			break;
			
		case ATTENTE_REPONSE_ACT:
			if(CAN_msg_received != NULL && global.flag_act == FALSE)
			{
				debug_printf("----- Reception resultat test carte actionneur -----\r\n"); 
				// reception du message CAN et analyse des donn�es
				
			
				WATCHDOG_stop(watchdog_selftest);
				etat = ENVOI_MESSAGE_STRAT;	
				
				//Allumage de la LED verte actionneur si tous les tests sont bons
			}
			else if(global.flag_act == TRUE)
			{
				debug_printf("TIMEOUT carte actionneur\r\n");
				etat = ENVOI_MESSAGE_STRAT;
			}
			break;
			
		case ENVOI_MESSAGE_STRAT:
			debug_printf("-> demande selftest carte strategie\r\n");
			CAN_msg_sent.sid = SUPER_ASK_STRAT_SELFTEST;
			CAN_msg_sent.size = 0;
			CAN_send(&CAN_msg_sent);
			watchdog_selftest = WATCHDOG_create_flag(TEMPS_WATCHDOG_STRAT, (bool_e*) &(global.flag_strat));
			etat = ATTENTE_REPONSE_STRAT;
			break;
			
		case ATTENTE_REPONSE_STRAT:
			if(CAN_msg_received != NULL && global.flag_strat == FALSE){
				debug_printf("----- Reception resultat test carte strategie -----\r\n");
				global.test_cartes.etats_capteurs = CAN_msg_received->data[0];
				
				if(global.test_cartes.etats_capteurs & 0b00000001)
					debug_printf("Capteur DT50 gauche OK\r\n");
				else
					debug_printf("Capteur DT50 gauche ERREUR\r\n");
					
				if(global.test_cartes.etats_capteurs & 0b00000010)
					debug_printf("Capteur DT50 droit OK\r\n");
				else
					debug_printf("Capteur DT50 droit ERREUR\r\n");
					
				if(global.test_cartes.etats_capteurs & 0b00000100)
					debug_printf("Capteur DT50 avant OK\r\n");
				else
					debug_printf("Capteur DT50 avant ERREUR\r\n");

				if(global.test_cartes.etats_capteurs & 0b00001000)
					debug_printf("Capteur DT10 0 OK\r\n");
				else
					debug_printf("Capteur DT10 0 ERREUR\r\n");
					
				if(global.test_cartes.etats_capteurs & 0b00010000)
					debug_printf("Capteur DT10 1 OK\r\n");
				else
					debug_printf("Capteur DT10 1 ERREUR\r\n");

				if(global.test_cartes.etats_capteurs & 0b00100000)
					debug_printf("Capteur DT10 2 OK\r\n");
				else
					debug_printf("Capteur DT10 2 ERREUR\r\n");

				if(global.test_cartes.etats_capteurs & 0b01000000)
					debug_printf("Capteur DT10 3 OK\r\n");
				else
					debug_printf("Capteur DT10 3 ERREUR\r\n");
					
				global.test_cartes.biroute_placee = CAN_msg_received->data[1];
				if(global.test_cartes.biroute_placee)
					debug_printf("Biroute PLACEE\r\n");
				else
					debug_printf("Biroute OUBLIEE\r\n");
				WATCHDOG_stop(watchdog_selftest);
				etat = ENVOI_MESSAGE_ASSER;
				if(global.test_cartes.biroute_placee == OK && (global.test_cartes.etats_capteurs & 0b01111111) == 0b01111111)
				{
					global.test_cartes.test_strat = TRUE;
					LED_V_STRAT = LED_ON;
					LED_R_STRAT = LED_OFF;
				}
				else
					LED_R_STRAT = LED_ON;
			}
			else if(global.flag_strat)
			{
				debug_printf("TIMEOUT carte strategie\r\n");
				etat = ENVOI_MESSAGE_ASSER;
				LED_R_STRAT = LED_ON;
			}	
			break;
			
		case ENVOI_MESSAGE_ASSER:
			debug_printf("-> demande selftest carte asser\r\n");
			CAN_msg_sent.sid = SUPER_ASK_ASSER_SELFTEST;
			CAN_msg_sent.data[0] = (global.config_robot[COLOR]==PURPLE)?FORWARD:REAR;
			CAN_msg_sent.size = 1;
			CAN_send(&CAN_msg_sent);
			watchdog_selftest = WATCHDOG_create_flag(TEMPS_WATCHDOG_ASSER, (bool_e*) &(global.flag_asser));
			etat = ATTENTE_REPONSE_ASSER;
			break;
			
		case ATTENTE_REPONSE_ASSER:
			if(CAN_msg_received != NULL && global.flag_asser == FALSE)
			{
				debug_printf("----- Reception resultat test carte asser -----\r\n");
				global.test_cartes.etat_moteur_gche = CAN_msg_received->data[0];
				global.test_cartes.etat_moteur_dt = CAN_msg_received->data[1];
				global.test_cartes.etat_roue_codeuse_gche = CAN_msg_received->data[2];
				global.test_cartes.etat_roue_codeuse_dte = CAN_msg_received->data[3];
				
				if(global.test_cartes.etat_moteur_gche)
					debug_printf("Etat moteur gauche OK\r\n");
				else
					debug_printf("Etat moteur gauche ERREUR\r\n");
					
				if(global.test_cartes.etat_moteur_dt)
					debug_printf("Etat moteur droit OK\r\n");
				else
					debug_printf("Etat moteur droit ERREUR\r\n");
					
				if(global.test_cartes.etat_roue_codeuse_gche)
					debug_printf("Etat roue codeuse gauche OK\r\n");
				else
					debug_printf("Etat roue codeuse gauche ERREUR\r\n");
					
				if(global.test_cartes.etat_roue_codeuse_dte)
					debug_printf("Etat roue codeuse droite OK\r\n");
				else
					debug_printf("Etat roue codeuse droite ERREUR\r\n");
					
				WATCHDOG_stop(watchdog_selftest);
				etat = ENVOI_MESSAGE_BALISE;
				
				if(global.test_cartes.etat_moteur_gche == OK && global.test_cartes.etat_moteur_dt == OK
					&& global.test_cartes.etat_roue_codeuse_gche == OK && global.test_cartes.etat_roue_codeuse_dte == OK)
				{
					global.test_cartes.test_asser = TRUE;
					LED_V_ASSER = LED_ON;
					LED_R_ASSER = LED_OFF;
				}		
			}
			else if(global.flag_asser)
			{
				debug_printf("TIMEOUT carte asser\r\n");
				etat = ENVOI_MESSAGE_BALISE;
			}
			break;
			
		case ENVOI_MESSAGE_BALISE:
			CAN_msg_sent.sid = SUPER_ASK_BEACON_SELFTEST;
			CAN_msg_sent.size = 0;
			debug_printf("-> demande selftest balise\r\n");
			CAN_send(&CAN_msg_sent);
			watchdog_selftest = WATCHDOG_create_flag(TEMPS_WATCHDOG_BALISE, (bool_e*) &(global.flag_beacon));
			etat = ATTENTE_REPONSE_BALISE;
			break; 
			
		case ATTENTE_REPONSE_BALISE:
			if(CAN_msg_received != NULL && global.flag_beacon == FALSE)
			{
				if(CAN_msg_received->sid == BEACON_IR_SELFTEST)
				{
					debug_printf("----- Reception resultat test balise IR -----\r\n");
					fin_test_balise++;
					erreur_reception_ir = CAN_msg_received->data[0];
					if(!erreur_reception_ir)
					{
						global.test_cartes.etat_balise_ir = OK;
						debug_printf("test IR OK\r\n");
					}
					else
					{
						debug_printf("test IR ERREUR\r\n");	
					}
				}
				if(CAN_msg_received->sid == BEACON_US_SELFTEST)
				{
					debug_printf("----- Reception resultat test balise US -----\r\n");
					fin_test_balise++;
					erreur_reception_us = CAN_msg_received->data[1];
					distance_mm = 10*CAN_msg_received->data[2];
					etat_synchro = CAN_msg_received->data[3];
					if(!erreur_reception_us)
					{
						global.test_cartes.etat_balise_us = OK;
						debug_printf("test US OK\r\n");
					}
					else
					{
						debug_printf("test US ERREUR\r\n");
						debug_printf("erreur_reception_us : %d\r\n",erreur_reception_us);
					}
					if(etat_synchro > TEMPS_SYNCHRO)
					{
						global.test_cartes.synchro_balise = OK; 
						debug_printf("synchro OK -> nombre de secondes : %d\r\n",etat_synchro);
					}
					else
					{
						debug_printf("synchro ERREUR -> nombre de secondes : %d\r\n",etat_synchro);
					}
					debug_printf("distance estimee : %d mm\r\n",distance_mm);
				}
			}
			if(!global.flag_beacon && fin_test_balise == NOMBRE_TESTS_BALISE)
			{
				fin_test_balise = 0;
				WATCHDOG_stop(watchdog_selftest);
				if(global.test_cartes.synchro_balise && global.test_cartes.etat_balise_us
					&& global.test_cartes.etat_balise_ir)
				{
					global.test_cartes.test_balise = TRUE;
					LED_R_BALISE = LED_OFF;
					LED_V_BALISE = LED_ON;
				}
				etat = PROCEDURE_TERMINEE;
			}
			if(global.flag_beacon)
			{
				debug_printf("TIMEOUT balise\r\n");
				etat = PROCEDURE_TERMINEE;
			}	
			break;
			
		case PROCEDURE_TERMINEE:
			if(global.test_cartes.test_act && global.test_cartes.test_strat 
				&& global.test_cartes.test_asser && global.test_cartes.test_balise)
			{
				LED_V_ROBOT = LED_ON;
				LED_R_ROBOT = LED_OFF;
			}
			debug_printf("______________________ FIN SELFTEST ________________________\r\n");
			etat = ATTENTE_APPUI_BOUTON;
			global.test_selftest_enable = FALSE;
			break;	
				
		default : 
			break;
	}
}	

void LED_init(){
	LED_R_ASSER = LED_ON;
	LED_R_ACT = LED_ON;
	LED_R_STRAT = LED_ON;
	LED_R_BALISE = LED_ON;
	LED_R_ROBOT = LED_ON;
	LED_V_ASSER = LED_OFF;
	LED_V_ACT = LED_OFF;
	LED_V_STRAT = LED_OFF;
	LED_V_BALISE = LED_OFF;
	LED_V_ROBOT = LED_OFF;
}
