/*
 *	Club Robot ESEO 2009 - 2010
 *	Chomp
 *
 *	Fichier : Interface.c
 *	Package : Supervision
 *	Description : Interface de configuration
 *	Auteur : Ronan & Aur�lien
 *	Version 20100119
 */

#define INTERFACE_C
#include "Interface.h"

#ifdef INTERFACE_GRAPHIQUE

static element_list_t strategy_list = {10, {"strat0","strat1","strat2","strat3","strat4","strat5","strat6","strat7","strat8","strat9"}};
static element_list_t color_list = {2,{"Bleu","rouge"}};
static element_list_t yes_no_list = {2,{"Non", "Oui"}};

void INTERFACE_GRAPHIQUE_init()
{	
	global.interface_graphique_enable = FALSE;
	global.indice_line = STRATEGIE;
	
	/* Strat�gies */
	global.interface_line[STRATEGIE].name = "Strategie";
	global.interface_line[STRATEGIE].element_list = &strategy_list;
	
	/* Couleurs */
	global.interface_line[COLOR].name = "Couleur";
	global.interface_line[COLOR].element_list = &color_list;

	/* Evitement */
	global.interface_line[EVITEMENT].name = "Evitement";
	global.interface_line[EVITEMENT].element_list = &yes_no_list;

	/* Balise */
	global.interface_line[BALISE].name = "Balise";
	global.interface_line[BALISE].element_list = &yes_no_list;

	/* Transmission */
	global.interface_line[TRANSMIT].name = "Transmission";
	global.interface_line[TRANSMIT].element_list = &yes_no_list;

	/* Buffer */
	global.interface_line[BUFFER].name = "Buffer";
	global.interface_line[BUFFER].element_list = &yes_no_list;
}

void INTERFACE_GRAPHIQUE_process_u1rx(void)
{
	static Uint32 sequence_read;
	Uint8 byte_read;
					
	if(UART1_data_ready() && global.interface_graphique_enable)
	{
		byte_read = UART1_get_next_msg();
		
		switch(byte_read)
		{
			case 0x01:	//D�but d'un message can, oops !!! c'�tait pas pour nous
				global.interface_graphique_enable = FALSE;
			break;
			case '\E':
				sequence_read=0;
				sequence_read=byte_read;
			break;
			case '[':
				if(sequence_read=='\E')
					sequence_read = (sequence_read<<8) + byte_read;
				else sequence_read=0;
			break;
			case 'A':
			case 'B':
			case 'C':
			case 'D':
				if(sequence_read==0x1B5B) /* 1B : '\E' et 5B ='[' */
				{
					sequence_read = (sequence_read<<8) + byte_read;
					INTERFACE_GRAPHIQUE_analyse_sequence_read(sequence_read);	
				}
				else sequence_read=0;
			break;	
			case '\r':
			case '\n':
				interface_graphique_envoi_message_can();
			break;
			default:
				sequence_read=0;
			break;
		}		
	}	
}	

void INTERFACE_GRAPHIQUE_analyse_sequence_read(Uint32 sequence_read)
{
	volatile line_t* line = &((global.interface_line)[global.indice_line]);
	element_list_t* element_list = line->element_list;

	switch(sequence_read)
	{
		case FLECHE_HAUT: 
			INTERFACE_GRAPHIQUE_afficher_ligne(global.indice_line, FALSE);
			global.indice_line=(global.indice_line-1+NB_CONFIG_FIELDS)%NB_CONFIG_FIELDS;
			INTERFACE_GRAPHIQUE_afficher_ligne(global.indice_line, TRUE);	
		break;
		case FLECHE_BAS:
			INTERFACE_GRAPHIQUE_afficher_ligne(global.indice_line, FALSE);
			global.indice_line=(global.indice_line+1)%NB_CONFIG_FIELDS;
			INTERFACE_GRAPHIQUE_afficher_ligne(global.indice_line, TRUE);
		break;
		case FLECHE_GAUCHE:
			global.config_robot[global.indice_line]=(global.config_robot[global.indice_line]-1+(element_list->nb_elements))%(element_list->nb_elements);
			INTERFACE_GRAPHIQUE_afficher_ligne(global.indice_line, TRUE);
		break;
		case FLECHE_DROITE:
			global.config_robot[global.indice_line]=(global.config_robot[global.indice_line]+1)%(element_list->nb_elements);
			INTERFACE_GRAPHIQUE_afficher_ligne(global.indice_line, TRUE);
		break;
		default:
		break;
	}
}

void INTERFACE_GRAPHIQUE_afficher_tout_le_menu()
{
	Uint8 i;
	
	print_UART1(HIDE_CURSOR);
	print_UART1(WRITE_WHITE_ON_BLACK);
	print_UART1(ERASE_DISPLAY);
	moveto(1,1);
	
	print_UART1("                     Interface de configuration de CHOMP !\r\n");
	INTERFACE_GRAPHIQUE_afficher_config_actuelle();
			
	for(i=0; i<NB_CONFIG_FIELDS; i++)
		INTERFACE_GRAPHIQUE_afficher_ligne(i, FALSE);
	INTERFACE_GRAPHIQUE_afficher_ligne(global.indice_line, TRUE);
}

void INTERFACE_GRAPHIQUE_afficher_config_actuelle() 
{
	Uint8 i;
	char chaine_temp[32];
	
	moveto(1,2);
	print_UART1("________________________________________________________________________________\r\n\r\n");
	for(i=0; i<NB_CONFIG_FIELDS; i++)
	{
		sprintf(
				chaine_temp,
				" %s %s \r\n",
				global.interface_line[i].name,
				(global.interface_line[i].element_list)->elements[global.config_robot[i]]
		);
		print_UART1(chaine_temp);
	}
	print_UART1("________________________________________________________________________________\r\n");
}

void INTERFACE_GRAPHIQUE_afficher_ligne(Uint8 numero_de_ligne, bool_e surligner)
{
	char ligne_a_envoyer[100];	//80 caract�res plus caracteres de controle
	moveto(2,12+(2*numero_de_ligne));	// positionnement en d�but de ligne (x, y)
	sprintf(
			ligne_a_envoyer,										//ligne � ecrire par sprintf 
			"%38s %s< %s >%s " ,	 								//format
			global.interface_line[numero_de_ligne].name, 			//nom de la ligne
			surligner?WRITE_BLACK_ON_WHITE:WRITE_WHITE_ON_BLACK,	//surlign� ou non
			(global.interface_line[numero_de_ligne].element_list)->elements[global.config_robot[numero_de_ligne]], //config courante sur la ligne
			WRITE_WHITE_ON_BLACK									//si surlign� on arr�te le surlignement
			);
	print_UART1(ligne_a_envoyer);
}

#endif /* def INTERFACE_GRAPHIQUE */

#ifdef INTERFACE_TEXTE

void INTERFACE_TEXTE_process_u1rx(void)
{
	Uint8 byte_read;
	
	if (global.flags.u1rx && global.interface_graphique_enable)
	{
		byte_read = UART1_get_next_msg();
		if(byte_read == 0x01)	//D�but d'un message can, oops !!! c'�tait pas pour nous
			global.interface_graphique_enable = FALSE;
		else
		{
			if(byte_read != '\n')
				INTERFACE_TEXTE_ajoute_caractere_buffer(byte_read);
			
			//ECHO DU CARACTERE....
			UART1_putc(byte_read);
			if(byte_read=='\b')
			{
				UART1_putc(' ');
				UART1_putc('\b');
			}			
			
			if(byte_read == '\r')
			{
				INTERFACE_TEXTE_execute_buffer();
				INTERFACE_TEXTE_vide_buffer();
				INTERFACE_TEXTE_afficher_menu();
			}	
		}			
	}
}	

void INTERFACE_TEXTE_execute_buffer(void)
{
	bool_e detection_commande_invalide = FALSE;
	
	/*
		COMMANDES || ARGUMENTS POSSIBLES
		strat   ||   0,1,2,3,4,5,6,7,8,9 
	*/
	
	if(INTERFACE_TEXTE_valider_commande("strat",5))
	{
			global.config_robot[STRATEGIE] = global.interface_graphique_buffer[6] - '0';
	}
	/*
		COMMANDES || ARGUMENTS POSSIBLES
		color   ||   b, B, blue, BLUE, bleu, BLEU, r, R, red, RED, rouge, ROUGE... 
	*/
	
	else if(INTERFACE_TEXTE_valider_commande("color",5))
	{
		if(global.interface_graphique_buffer[6] == 'r' || global.interface_graphique_buffer[6] == 'R')
			global.config_robot[COLOR] = YELLOW;
		else if(global.interface_graphique_buffer[6] == 'b' || global.interface_graphique_buffer[6] == 'B')
			global.config_robot[COLOR] = BLUE;
		else
			detection_commande_invalide = TRUE;
	}
	else if(INTERFACE_TEXTE_valider_commande("evit",4))
	{
		if(INTERFACE_TEXTE_detection_y_n(global.interface_graphique_buffer[5], EVITEMENT) == FALSE)
			detection_commande_invalide = TRUE;		
	}
	else if(INTERFACE_TEXTE_valider_commande("balise",6))
	{
		if(INTERFACE_TEXTE_detection_y_n(global.interface_graphique_buffer[7], BALISE) == FALSE)
			detection_commande_invalide = TRUE;
	}
	else if(INTERFACE_TEXTE_valider_commande("transmit",8))
	{
		if(INTERFACE_TEXTE_detection_y_n(global.interface_graphique_buffer[9], TRANSMIT) == FALSE)
			detection_commande_invalide = TRUE;
	}	
	else if(INTERFACE_TEXTE_valider_commande("buffer",6))
	{
		if(INTERFACE_TEXTE_detection_y_n(global.interface_graphique_buffer[7], BUFFER) == FALSE)
			detection_commande_invalide = TRUE;
	}			
	else if(INTERFACE_TEXTE_valider_commande("go",2))
	{
		//Envoi du message can
		interface_graphique_envoi_message_can();
		
		print_UART1("\r\n\r\nEnvoi du message CAN de la configuration suivante :\r\n");
		print_UART1("\r\n---------------------------------------------------------------------\r\n");
	}		
	else
	{
		detection_commande_invalide = TRUE;	
	}
	
	if(detection_commande_invalide == TRUE)
		print_UART1("Commande invalide\r\n");
}	

bool_e INTERFACE_TEXTE_valider_commande(char * chaine, Uint8 taille)
{
	Uint8 i;
	bool_e bret;
	bret = TRUE;
	
	//V�rification que la chaine contenue dans le buffer a une taille suffisante !
	if(global.interface_graphique_buffer_index < taille)
		bret = FALSE;
	else	
	{
		for(i = 0; i< taille; i++)
		{
			if(chaine[i] != global.interface_graphique_buffer[i])
				bret = FALSE;
		}	
	}
		
	return bret;
}	

bool_e INTERFACE_TEXTE_detection_y_n(Uint8 caractere, Uint8 param)
{
	if(caractere == 'y' || caractere == 'Y')
			global.config_robot[param] = TRUE;
	else if(caractere == 'n' || caractere == 'N')
			global.config_robot[param] = FALSE;
	else
		return FALSE;	//MAUVAISE COMMANDE
		
	return TRUE; 	//BONNE COMMANDE
}
	
	/*
		COMMANDES || ARGUMENTS POSSIBLES
		evit   ||   y, Y, n, N, yes, YES, no, NO, non
		balise ||   y, Y, n, N, yes, YES, no, NO, non
		transmit   ||   y, Y, n, N, yes, YES, no, NO, non
		buffer ||   y, Y, n, N, yes, YES, no, NO, non
	*/

void INTERFACE_TEXTE_ajoute_caractere_buffer(Uint8 byte_read)
{
	if(byte_read == '\b')
	{
		if(global.interface_graphique_buffer_index >0)
			global.interface_graphique_buffer_index--;
	}
	else 
	{
		if(global.interface_graphique_buffer_index < TAILLE_BUFFER_INTERFACE_TEXTE)
		{
			global.interface_graphique_buffer[global.interface_graphique_buffer_index] = byte_read;
			global.interface_graphique_buffer_index++;
		}
	}
}		

void INTERFACE_TEXTE_vide_buffer(void)
{
	global.interface_graphique_buffer_index = 0;
}	

void INTERFACE_TEXTE_afficher_menu()
{
	//Pas de menu si interface d�sactiv�e !!!
	if(global.interface_graphique_enable == FALSE)
		return;

	print_UART1("| strat ");
	UART1_put_Uint8(global.config_robot[STRATEGIE]);
	
	print_UART1(" || color ");
	if(global.config_robot[COLOR] == YELLOW)
		print_UART1("yellow");	
	else
		print_UART1("blue");
		
	print_UART1(" || evit ");
	INTERFACE_TEXTE_print_y_n(global.config_robot[EVITEMENT]);

	print_UART1(" || balise ");
	INTERFACE_TEXTE_print_y_n(global.config_robot[BALISE]);
	
	print_UART1(" || transmit ");
	INTERFACE_TEXTE_print_y_n(global.config_robot[TRANSMIT]);
	
	print_UART1(" || buffer ");
	INTERFACE_TEXTE_print_y_n(global.config_robot[BUFFER]);
		
	print_UART1(" |\r\n");
}

void INTERFACE_TEXTE_print_y_n(bool_e bool)
{
	if(bool == TRUE)
		print_UART1("y");	
	else
		print_UART1("n");
}	

#endif /* def INTERFACE_TEXTE */

void interface_graphique_envoi_message_can()
{
	CAN_msg_t message;
	
	message.sid = SUPER_ASK_CONFIG;	
	message.size = 8;
	message.data[0] = global.config_robot[STRATEGIE];
	message.data[1] = global.config_robot[COLOR];
	message.data[2] = global.config_robot[EVITEMENT];
	message.data[3] = global.config_robot[BALISE];
	
	CAN_send(&message);
	BUFFER_add(message); // Ajout dans le buffer du message de config envoy� � la carte strat�gie
}
	
void print_UART1(char* s)
{
	Uint16 index=0;
	while(s[index]!='\0')
	{
		UART1_putc(s[index]);
		index++;
	}
}

void UART1_put_Uint8(Uint8 i)
{
	if(i>=100)
	{
		UART1_putc((i/100)%10+'0');
	}	
	if(i>=10)
	{
		UART1_putc((i/10)%10+'0');
	}
		
	UART1_putc((i%10)+'0');
}

void moveto(Uint8 x, Uint8 y)
{
	char chaine[8];
	sprintf(chaine,"\E[%d;%dH",y,x);
	print_UART1(chaine);
}
