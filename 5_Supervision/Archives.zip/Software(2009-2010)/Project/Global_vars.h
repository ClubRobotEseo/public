/*
 *  Club Robot ESEO 2008 - 2010
 *  Archi-Tech'
 *
 *  Fichier : Global_config.h
 *  Package : Standard_Project
 *  Description : Variables globales d�finies specifiquement pour
					le code de la carte l'executant.
 *  Auteur : Jacen (inspir� du package QS d'Axel Voitier)
 *  Version 20081010
 */

#ifndef GLOBAL_VARS_H
	#define GLOBAL_VARS_H

	#ifndef QS_GLOBAL_VARS_H
		#error "Il est interdit d'inclure directement Global_vars.h, lire le CQS."
	#endif
	
	volatile bufferCirculaire_t buffer;
	volatile Uint16 TIMER3_loops;		//compte les quarts de secondes �coul� depuis le lancement du Timer 3
	volatile Uint16 compteur_de_secondes;
	volatile Uint16 compteur_de_secondes_precedent_buffer;
	volatile Uint16 compteur_de_secondes_precedent_uart;
	
	volatile bool_e bouton;						//�tat du bouton actuel
	volatile Uint8 bouton_chrono_appui_long; 	//compteur des quarts de seconde pout d�tect� un appui �gal � 2 secondes
	
	volatile bool_e interface_graphique_enable;	
	volatile bool_e match_started;
	
	#ifdef INTERFACE_GRAPHIQUE
		volatile line_t interface_line[NB_CONFIG_FIELDS];
		volatile Uint8 indice_line;
	#endif /* def INTERFACE_GRAPHIQUE */
	
	#ifdef INTERFACE_TEXTE
		volatile Uint8 interface_graphique_buffer[TAILLE_BUFFER_INTERFACE_TEXTE];	//buffer de stockage des caract�res
		volatile Uint8 interface_graphique_buffer_index;
	#endif /* def INTERFACE_TEXTE */
		
	volatile Uint8 config_robot[NB_CONFIG_FIELDS];	//tableau de configuration du match
	
	
	/*  Note : Variables globales communes � tous les codes
	 *
	 *	Buffer de reception de l'UART 1
	 *	Uint8 u1rxbuf[UART_RX_BUF_SIZE];
	 *
	 *	Buffer de reception de l'UART 2
	 *	Uint8 u2rxbuf[UART_RX_BUF_SIZE];
	 *
	 *	Buffer de reception des messages du bus CAN
	 *	CAN_msg_t can_buffer[CAN_BUF_SIZE];
	 *	Position du dernier message recu
	 *	volatile Uint16 can_rx_num;
	 *
	 *	Buffer de reception des messages du bus CAN2
	 *	CAN_msg_t can2_buffer[CAN_BUF_SIZE];
	 *	Position du dernier message recu
	 *	volatile Uint16 can2_rx_num;
	 */
	 
	 
#endif /* ndef GLOBAL_VARS_H */
