/*
 *	Club Robot ESEO 2009 - 2010
 *	Chomp
 *
 *	Fichier : Can_watch.c
 *	Package : Supervision
 *	Description : 
 *	Auteur : Ronan
 *	Version 20100422
 */
 
#define CAN_WATCH_C
#include "Can_watch.h"
 
void CAN_WATCH_init() {
	TIMER3_run(250);	//Timer cadenc� EN PERMANENCE � 250ms...	 
}
 
 void CAN_WATCH_update() {
	
	if(CAN_data_ready())
	{ 
		CAN_msg_t can_msg;

		LED_CAN= !LED_CAN;
		can_msg=CAN_get_next_msg();
		
		if(global.config_robot[TRANSMIT])
		{	
			switch(can_msg.sid)
			{
				// Messages que la super envoie.
				case BROADCAST_POSITION_ROBOT:
					//Traitement sp�cial pour les messages d'asser position : maxi 1 par seconde !
					if(global.compteur_de_secondes-4>global.compteur_de_secondes_precedent_uart) //global.compteur_de_secondes est incr�ment� toutes les 250 ms ...
					{
						CANmsgToU2tx(&can_msg);	
						global.compteur_de_secondes_precedent_uart=global.compteur_de_secondes;
					}
					break;		
				case BEACON_ADVERSARY_POSITION:
					// pas de transmission
					break;
				default:	
					CANmsgToU2tx(&can_msg);	
					break;	
			}
		}
		if(global.config_robot[BUFFER])
			BUFFER_add(can_msg);	
		
		// Messages qui nous sont destin�s.
		switch(can_msg.sid)
		{
			case BROADCAST_START:
				global.match_started=TRUE;
				global.TIMER3_loops=0; 		//On initialise la variable qui compte le nombre de boucle du Timer 1
			break;
			
			case BROADCAST_STOP_ALL:
				global.match_started=FALSE;
				global.config_robot[BUFFER]=FALSE;
			break;
			
			case BROADCAST_COULEUR:
				global.config_robot[COLOR]=can_msg.data[0];
			break;
			
			case SUPER_CONFIG_IS:
					global.config_robot[STRATEGIE]=can_msg.data[0];
					global.config_robot[COLOR]=can_msg.data[1];
					global.config_robot[EVITEMENT]=can_msg.data[2];
					global.config_robot[BALISE]=can_msg.data[3];
						
				if(global.interface_graphique_enable) 
				{
					#ifdef INTERFACE_GRAPHIQUE
						
						print_UART1(ERASE_DISPLAY);
						moveto(1,1);
						print_UART1("Envoi du message CAN de la configuration suivante :");
						INTERFACE_GRAPHIQUE_afficher_config_actuelle();
						moveto(20,12);
						print_UART1("\r\nLe Robot est configure !\r\n");
						moveto(22,14);
						print_UART1("\r\nAu revoir, bon match !\r\n");
			
					#endif /* def INTERFACE_GRAPHIQUE */
					
					#ifdef INTERFACE_TEXTE
							
						print_UART1("---------------------------------------------------------------------\r\n");
						print_UART1("\r\nLe Robot est configure !\r\n");
						print_UART1("\r\nAu revoir, bon match !\r\n");
				
					#endif /* def INTERFACE_TEXTE */
										
					global.interface_graphique_enable = FALSE;
				}	
			break;
			
			default:
			break;			
		}	
	}		
}	

void _ISR _T3Interrupt() {
	
	global.compteur_de_secondes++;
	
	if(global.match_started)
	{
		global.TIMER3_loops++;	
	}	
	
	IFS0bits.T3IF=0;
}
