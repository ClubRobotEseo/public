/*
 *	Club Robot ESEO 2009 - 2010
 *	Chomp
 *
 *	Fichier : Can_injector.c
 *	Package : Supervision
 *	Description : Injection des messages arrivant de l'UART2 et de l'UART1 sur le CAN 
 *	Auteur : Ronan
 *	Version 20100422
 */
 
#define CAN_INJECTOR_C

#include "Can_injector.h"

void CAN_INJECTOR_init() {

}

void CAN_INJECTOR_update() {
	
	static CAN_msg_t can_msg_1;
	static CAN_msg_t can_msg_2;
	
	if(!global.interface_graphique_enable)
	{
		if(u1rxToCANmsg(&can_msg_1))
		{	
			CAN_send(&can_msg_1);
			LED_USER = !LED_USER;
		}	
	}
	
	if(u2rxToCANmsg(&can_msg_2))
	{	
		CAN_send(&can_msg_2);
		LED_USER = !LED_USER;
	}
}

