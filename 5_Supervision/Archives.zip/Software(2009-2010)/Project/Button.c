/*
 *	Club Robot ESEO 2009 - 2010
 *	Chomp
 *
 *	Fichier : Button.c
 *	Package : Supervision
 *	Description : Gestion de l'appui sur le bouton de la carte supervision 
 *	Auteur : Ronan
 *	Version 20100422
 */
 
#define INTERFACE_C
#include "Button.h"

void BUTTON_init() {
	TIMER2_run(100);	//Timer cadenc� EN PERMANENCE � 100ms...
}
void BUTTON_update() {
	
	static bool_e bouton_precedent = FALSE;
	global.bouton = BOUTON;
		
	//L'utilisateur vient d'appuyer sur le bouton
	if(bouton_precedent == BOUTON_OFF && global.bouton == BOUTON_ON)
		global.bouton_chrono_appui_long = 20;	//(20*100ms = 2sec !)
	
	//On s'interroge de la dur�e de l'appui	
	if(bouton_precedent == BOUTON_ON)
	{
		if(global.bouton_chrono_appui_long == 0)
		{	//APPUI LONG : Buffer Flush
			BUFFER_flush();	
			while(BOUTON != BOUTON_OFF);
			global.bouton = BOUTON_OFF;	
		}	
		else
		{
			if(global.bouton == BOUTON_OFF)
			{	//APPUI COURT : Affichage de l'interface graphique !
				global.interface_graphique_enable = TRUE;
				//global.config_robot[TRANSMIT]=FALSE;
				
				#ifdef INTERFACE_GRAPHIQUE
					INTERFACE_GRAPHIQUE_afficher_tout_le_menu();
 				#endif /* def INTERFACE_GRAPHIQUE */	

				#ifdef INTERFACE_TEXTE
					print_UART1("Bienvenue sur l'interface de configuration du robot CHOMP !\r\n");
					print_UART1("\r\nPour configurer le CHOMP, veuillez entrer le parametre, UN ESPACE, et le choix souhaite\r\n\r\n");
					INTERFACE_TEXTE_afficher_menu();
				#endif /* def INTERFACE_TEXTE */			
			}	
		}
	}
	
	//Mise � jour de "bouton_precedent" pour le prochain passage
	bouton_precedent = global.bouton;
}	

void _ISR _T2Interrupt() {
	
	if(global.bouton_chrono_appui_long != 0)
		global.bouton_chrono_appui_long--;
		
	IFS0bits.T2IF=0;
}

