/*
 *	Club Robot ESEO 2009 - 2010
 *	Chomp
 *
 *	Fichier : Button.h
 *	Package : Supervision
 *	Description : Gestion de l'appui sur le bouton de la carte supervision 
 *	Auteur : Ronan
 *	Version 20100422
 */
 
#include "../QS/QS_all.h"

#ifndef BUTTON_H
	#define BUTTON_H
	#define BOUTON_ON	0
	#define BOUTON_OFF	1
	#include "Buffer.h"
	#include "Interface.h"
	
	void BUTTON_init();
	void BUTTON_update();
		
#endif
