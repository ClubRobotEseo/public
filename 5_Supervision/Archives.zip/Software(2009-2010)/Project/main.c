/*
 *	Club Robot ESEO 2008 - 2010
 *	Archi-Tech', PACMAN
 *
 *	Fichier : main.h
 *	Package : Supervision
 *	Description : sequenceur de la supervision
 *	Auteur : Jacen
 *	Version 20100105
 */

#define MAIN_C
#include "main.h"

int main (void)
{	
	init();
	
	while (1)
	{		
		/* V�rification de l'appui sur le bouton */
		BUTTON_update();
		
		/* V�rification de la r�ception d'un message CAN et traitement de ce message */		
		CAN_WATCH_update();
	
		/* V�rification de la r�ception d'un message de type CAN sur UART1 et l'UART2 */
		CAN_INJECTOR_update();
		
		#ifdef INTERFACE_GRAPHIQUE
			INTERFACE_GRAPHIQUE_process_u1rx();		
		#endif /* def INTERFACE_GRAPHIQUE */
		
		#ifdef INTERFACE_TEXTE
			INTERFACE_TEXTE_process_u1rx();				
		#endif /* def INTERFACE_TEXTE */
		
	}
	return 0;
}

void init(void)
{
	PORTS_init();
	CAN_init();
	UART_init();
	TIMER_init();
	BUFFER_init();
	CAN_WATCH_init();
	CAN_INJECTOR_init();
	BUTTON_init();
	
	#ifdef INTERFACE_GRAPHIQUE
		INTERFACE_GRAPHIQUE_init();
	#endif /* def INTERFACE_GRAPHIQUE */
	
	//CONFIGURATION PAR DEFAUT
	global.config_robot[STRATEGIE]=1;
	global.config_robot[COLOR]=RED;
	global.config_robot[EVITEMENT]=TRUE;
	global.config_robot[BALISE]=TRUE;
	global.config_robot[TRANSMIT]=TRUE;
	global.config_robot[BUFFER]=TRUE;	
	
	//INITIALISATION DES LEDS
	LED_RUN =1;
	LED_CAN =0;
	LED_USER =0;
	LED_TEST =0;
}
