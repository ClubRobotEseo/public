/*
 *  Club Robot ESEO 2008 - 2010
 *  Archi-Tech', PACMAN
 *
 *  Fichier : Global_config.h
 *  Package : Standard_Project
 *  Description : Configuration des modules de QS
 *  Auteur : Jacen
 *  Version 20100415
 */

#ifndef GLOBAL_CONFIG_H
	#define GLOBAL_CONFIG_H
	#include "../QS/QS_types.h"

	/* Belle interface graphique ou simple interface texte !*/  
	#define INTERFACE_GRAPHIQUE
//	#define INTERFACE_TEXTE
	
	/* Le mode verbeux active debug_printf */
	//#define VERBOSE_MODE

	/* Pour certaines config particulieres, il faut definir qui on est
	 * a l'aide d'une des valeurs du type cartes_e de QS_types.h */
	#define I_AM CARTE_SUPER
	#define I_AM_CARTE_SUPER

	/* Il faut choisir � quelle frequence on fait tourner le PIC */
	#define FREQ_10MHZ
	
	/* Les instructions ci dessous d�finissent le comportement des
	 * entrees sorties du pic. une configuration en entree correspond
	 * a un bit a 1 (Input) dans le masque, une sortie a un bit a
	 * 0 (Output).
	 * Toute connection non utilisee doit etre configuree en entree
	 * (risque de griller ou de faire bruler le pic) 
	 */

	#define PORT_A_IO_MASK	0xFFFF
	#define PORT_B_IO_MASK	0xFFFF
	#define PORT_C_IO_MASK	0xFFFF
		#define BOUTON PORTCbits.RC1	//Bouton mis � l'arrache !
	#define PORT_D_IO_MASK	0xF0FF
	#define PORT_E_IO_MASK	0xFFFF
	#define PORT_F_IO_MASK	0xFFFF
	#define PORT_G_IO_MASK	0xFFFF
	/* Les instructions suivantes permettent de configurer certainesF
	 * entrees/sorties du pic pour realiser des fonctionnalites
	 * particulieres comme une entree analogique 
	 */

	#define USE_CAN
//	#define USE_CAN2
/*	Nombre de messages CAN conserv�s 
	pour traitement hors interuption */
	#define CAN_BUF_SIZE		8

	#define USE_UART1
	#define USE_UART1RXINTERRUPT
	#define USE_UART2
	#define USE_UART2RXINTERRUPT
/*	Taille de la chaine de caracteres memorisant
	les caracteres recus sur UART */
	#define UART_RX_BUF_SIZE	42

/* choix de la fr�quence des PWM */
	#define FREQ_PWM_1KHZ


	//Taille du buffer de m�morisation des caract�res de l'interface texte ...
	#define TAILLE_BUFFER_INTERFACE_TEXTE 20
	
	
	//Taille du buffer de m�morisation des messages CAN pendant le match...
	//ATTENTION : il faut qu'il soit grand, jusqu'a full memoire !!!
	#define BUFFER_SIZE		400

	
#endif /* ndef GLOBAL_CONFIG_H */
