/*
 *	Club Robot ESEO 2008 - 2009
 *	Archi'Tech
 *
 *	Fichier : Test_main.h
 *	Package : Supervision
 *	Description : fonction principale permettant
 *				l'appel des fonctions de test de la carte Super
 *	Auteur : Jacen
 *	Version 20081214
 */

#ifndef TEST_MAIN_H
	#define TEST_MAIN_H
	
	#include "../QS/QS_all.h"
	#ifdef TEST_MODE
		#include "../QS/QS_ports.h"
		#include "Super_uart.h"
		#include "../QS/QS_can.h"
		#include "../QS/QS_CANmsgList.h"

	#endif /* def TEST_MODE */	
#endif /* ndef MAIN_H */
