/*
 *	Club Robot ESEO 2008 - 2009
 *	Archi-Tech'
 *
 *	Fichier : Test_main.c
 *	Package : Projet Standard
 *	Description : fonction principale permettant
 *				l'appel des fonctions de test
 *				de la carte supervision
 *	Auteur : Jacen
 *	Version 20081209
 */

#define TEST_MAIN_C
#include "Test_main.h"

#ifdef TEST_MODE

	int main (void)
	{
		
		CAN_msg_t receivedCanMsg, UartToCanMsg;

		PORTS_init();
		UART_init();
		CAN_init();
		
		
		LED_0 =1;
		LED_1 =1;
		LED_2 =1;
		LED_3 =1;
	
		
		while (1)
		{
			if (global.flags.u1rx)
			{
				UART2_putc(UART1_get_next_msg());
				LED_1 = !LED_1;
			}

			if (global.flags.canrx)
			{
				LED_0 = !LED_0;
				receivedCanMsg = CAN_get_next_msg();
				if (receivedCanMsg.sid)
				{
					CANmsgToU2tx (&receivedCanMsg);
					//CAN_send(&receivedCanMsg);
				}
			}
			
			if (global.flags.u2rx)
			{
				LED_2 = !LED_2;
				if(u2rxToCANmsg(&UartToCanMsg))
				{
					LED_3 = !LED_3;
					CAN_send(&UartToCanMsg);
				}	
			}			
		}
		return 0;
	}


#endif /* def TEST_MODE */
