/*
 *  Club Robot ESEO 2008 - 2009
 *  Archi-Tech'
 *
 *  Fichier : Global_config.h
 *  Package : Standard_Project
 *  Description : Variables globales d�finies specifiquement pour
					le code de la carte l'executant.
 *  Auteur : Jacen (inspir� du package QS d'Axel Voitier)
 *  Version 20081010
 */

#ifndef GLOBAL_VARS_H
	#define GLOBAL_VARS_H

	#ifndef QS_GLOBAL_VARS_H
		#error "Il est interdit d'inclure directement Global_vars.h, lire le CQS."
	#endif
	
	volatile bufferCirculaire_t buffer;
	volatile Uint16 TIMER3_loops;		//compte les quarts de secondes �coul� depuis le lancement du Timer 3
	volatile Uint8 couleur_Match;		//prend les diff�rentes valeurs qui sont utilis�es pour piloter la LED bicolor, dans l'ordre : OFF(0),VERT(1),ROUGE(2),ORANGE(3)
	volatile Uint8 affiche_lecture_offset;
	volatile Uint8 count_BEACON_POS_msg;				//compte les messages �ponymes modulo quatre
	volatile Uint8 count_CARTE_P_POSITION_ROBOT_msg;	//compte les messages �ponymes modulo quatre
	volatile Uint8 confirmation_config;					//mis � 1 lors de la confirmation de r�ception de la configuration
	/*  Note : Variables globales communes � tous les codes
	 *
	 *	Buffer de reception de l'UART 1
	 *	Uint8 u1rxbuf[UART_RX_BUF_SIZE];
	 *
	 *	Buffer de reception de l'UART 2
	 *	Uint8 u2rxbuf[UART_RX_BUF_SIZE];
	 *
	 *	Buffer de reception des messages du bus CAN
	 *	CAN_msg_t can_buffer[CAN_BUF_SIZE];
	 *	Position du dernier message recu
	 *	volatile Uint16 can_rx_num;
	 *
	 *	Buffer de reception des messages du bus CAN2
	 *	CAN_msg_t can2_buffer[CAN_BUF_SIZE];
	 *	Position du dernier message recu
	 *	volatile Uint16 can2_rx_num;
	 */

#endif /* ndef GLOBAL_VARS_H */
