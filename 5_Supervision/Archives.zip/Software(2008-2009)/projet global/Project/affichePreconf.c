#include "interface.h"

const char SWTxtPreconf[MAX_STXT_LEN] = "Preconfig";
const char SWTxtNoPreconf[MAX_STXT_LEN] = "ConfPerso";


void affichePreconf(THD_struct *lcd, config* configOn) 
{
	extern Uint8 swBuffer;
	Uint8 smenu = 0;

	afficheTxtPreconf(lcd, configOn);

	while(1) 
	{
		if(isSWEvent(swBuffer)) 
		{
			switch(getSWEvent(swBuffer)) 
			{
				case MASK_TOP:    /* Actions pour haut*/
					if(isSWOn(MASK_TOP)) 
					{
	    				if(smenu > 0) 
						{
		    				sous_undrawCurs(lcd, smenu);
		    				smenu--;
		    				sous_drawCurs(lcd, smenu);
		    			}
            		}
				break;
				case MASK_BOT:
					if(isSWOn(MASK_BOT)) 
					{
						if(smenu < BTN_NUMBER_PRECONF-1) 
						{
		    				sous_undrawCurs(lcd, smenu);
		    				smenu++;
		    				sous_drawCurs(lcd, smenu);
						}
            		}
				break;
				case MASK_VALID:
					if(isSWOn(MASK_VALID)) 
					{
						if(configOn->preconf != smenu) 
						{
							unactive_choice(lcd, configOn->preconf);
							configOn->preconf = smenu;
							active_choice(lcd, configOn->preconf);
						}
					}
				break;
				case MASK_CANCEL:
					if(isSWOn(MASK_CANCEL)) 
					{
						clearScreen(lcd);
						return;
	   				}
				break;
				case MASK_COLOR:
					if(isSWOn(MASK_COLOR))
					{
						askNewColor(configOn);
					}
				break;
			}
			/*On met � jour le buffer*/
    		swBuffer = SW_PORT;
		}
		checkFlags(lcd, configOn);		//parallelisation du menu et de la r�ception des messages
	}
}

void afficheTxtPreconf(THD_struct *lcd, config* configOn) 
{
	Uint8 i=0;
	char aux[MAX_STXT_LEN+2];

	TXT_SetPos(lcd, THD_pos(STXT_POS_X,STXT_POS_Y+2*i));
	/*sprintf(aux,"%s",SWTxtNoPreconf);*/
	TXT_PrintString(lcd, SWTxtNoPreconf /*aux*/ );
	GFX_DrawFrame(lcd, THD_pos(SMENU_POS_X+1, SMENU_POS_Y+1+i*(SBTN_HEIGHT+BTN_SMENU_OFFSET_Y)), THD_pos(SMENU_POS_X+SBTN_WIDTH-1, SMENU_POS_Y-1+i*(SBTN_HEIGHT+BTN_SMENU_OFFSET_Y)+SBTN_HEIGHT), SET);

	
	for(i=1; i<BTN_NUMBER_PRECONF; i++)
	{
		TXT_SetPos(lcd, THD_pos(STXT_POS_X,STXT_POS_Y+2*i));
		sprintf(aux,"%s %d",SWTxtPreconf, i);
		TXT_PrintString(lcd, aux);
		GFX_DrawFrame(lcd, THD_pos(SMENU_POS_X+1, SMENU_POS_Y+1+i*(SBTN_HEIGHT+BTN_SMENU_OFFSET_Y)), THD_pos(SMENU_POS_X+SBTN_WIDTH-1, SMENU_POS_Y-1+i*(SBTN_HEIGHT+BTN_SMENU_OFFSET_Y)+SBTN_HEIGHT), SET);
	}	
	active_choice(lcd, configOn->preconf);
	/*affiche la config actuelle � l'entr�e dans le menu*/
	sous_drawCurs(lcd, 0);
}

