#define __INTERFACE_C

#include "interface.h"
#include "Buffer.h"		// test parall�lisation
#include "../QS/QS_can.h"
#include "TraitmntMsgCAN.h"

/* tableau d�clar� dans afficheMenu.c */
extern const char SWTxt[BTN_NUMBER][MAX_TEXT_LEN];

/* le buffer est initialis� � "aucun bouton n'est press�" */
Uint8 swBuffer=0b01100111;

/********************************** FUNCTIONS ************************************************/

void enMatch(THD_struct *lcd)
{
	clearScreen (lcd);
	TXT_SetPos(lcd, THD_pos(16,8));
	TXT_PrintString(lcd, "ARCHI'TECH");
	
	TXT_SetPos(lcd, THD_pos(19,10));
	TXT_PrintString(lcd, "PRET");
	
	while(1)
	{
		if(isSWEvent(swBuffer)) 
		{
			switch(getSWEvent(swBuffer)) 
			{
				case MASK_VALID:
					if(isSWOn(MASK_VALID))
					{
						BUFFER_flush();		//Lors de l'appui sur le bouton VALID (id�alement en fin de match) on vide le buffer (ne pas oublier de brancher un pc sur l'uart2 avant)
					}
				break;
			}
			/*On met � jour le buffer*/
    		swBuffer = SW_PORT;
		}
		checkCANAndWrite(lcd);
	}
}

void checkCANAndWrite(THD_struct *lcd)
{
	static CAN_msg_t receivedCanMsg;
	/*const char null[MAX_TEXTCAN_LEN]="";
	
	if(global.affiche_lecture_offset >= MAX_OFFSET)
	{
		Uint8 i;
		for(i=0;i<=MAX_OFFSET;i++)		//boucle d'effacement de l'�cran
		{
			TXT_SetPos(lcd, THD_pos(AFFICHE_ORIGINE_X,AFFICHE_ORIGINE_Y+i));
			TXT_PrintString(lcd, null);
		}
		global.affiche_lecture_offset = 0;		//r�initialisation de l'offset
	}*/
	
	if(global.affiche_lecture_offset >= MAX_OFFSET)		//Cas d'effacement de l'�cran lorsque 14 messages ont �t� �crits
	{
		clearScreen(lcd);
		TXT_SetPos(lcd, THD_pos(15,1));			//On r��crit le titre
		TXT_PrintString(lcd, "MATCH EN COURS");
		global.affiche_lecture_offset = 0;		//r�initialisation de l'offset
	}
	
	if (global.flags.canrx)
	{
		receivedCanMsg = CAN_get_next_msg();
		if (receivedCanMsg.sid)
		{
			LED_3 = !LED_3;
			switch(receivedCanMsg.sid)
			{
				case BROADCAST_START:
					clearScreen (lcd);		//On efface l'�cran quand le match commence pour permettre l'affichage en direct des messages CAN
					TXT_SetPos(lcd, THD_pos(15,1));
					TXT_PrintString(lcd, "MATCH EN COURS");
				
				default:
					BUFFER_add(receivedCanMsg);
					CANmsgToU2tx (&receivedCanMsg);			//on renvoie le message sur l'UART2
					TXT_SetPos(lcd, THD_pos(AFFICHE_ORIGINE_X,AFFICHE_ORIGINE_Y+global.affiche_lecture_offset));
					printLCDSIDCAN(receivedCanMsg.sid,lcd);
					printLCDDATA(receivedCanMsg,lcd);
					printLCDSIZE(receivedCanMsg.size,lcd);
					global.affiche_lecture_offset++;		//on incr�mente le d�calage pour pr�parer l'affichage du prochain message
					break;
			}
		}
	}

	if (global.flags.u2rx)
	{
		if(u2rxToCANmsg (&receivedCanMsg))
		{
			LED_2 = !LED_2;
			BUFFER_add(receivedCanMsg);
			CAN_send(&receivedCanMsg);			//on renvoie le message sur le CAN
			TXT_SetPos(lcd, THD_pos(AFFICHE_ORIGINE_X,AFFICHE_ORIGINE_Y+global.affiche_lecture_offset));
			printLCDSIDCAN(receivedCanMsg.sid,lcd);
			printLCDDATA(receivedCanMsg,lcd);
			printLCDSIZE(receivedCanMsg.size,lcd);
			global.affiche_lecture_offset++;	//on incr�mente le d�calage pour pr�parer l'affichage du prochain message
		}
	}
	
	if (global.flags.u1rx)		//On arr�te pas pour autant de surveiller l'UART1
	{
		LED_1 = !LED_1;
		UART2_putc(UART1_get_next_msg());
	}
}

void checkFlags(THD_struct *lcd, config* configOn)
{
	static CAN_msg_t receivedCanMsg;
	
	if (global.flags.u1rx)
	{
		LED_1 = !LED_1;
		UART2_putc(UART1_get_next_msg());
	}

	if (global.flags.canrx)
	{
		receivedCanMsg = CAN_get_next_msg();
		if (receivedCanMsg.sid)
		{
			LED_3 = !LED_3;
			switch(receivedCanMsg.sid)
			{
				case BROADCAST_COULEUR:
					changeColor(receivedCanMsg, configOn);		//Changement de couleur effectif
					break;
				
				case SUPER_CONFIG_IS:
					global.confirmation_config = 1;		//Cette variable globale sera utilis�e par la fonction affiche pr�t pour d�tecter la r�ception de la configuration
					
					clearScreen (lcd);
					TXT_SetPos(lcd, THD_pos(16,8));
					TXT_PrintString(lcd, "ARCHI'TECH");
					
					TXT_SetPos(lcd, THD_pos(10,10));
					TXT_PrintString(lcd, "Configuration bien recue");
					
					char config[25];
					sprintf(config,"%d %d %d %d %d %d %d %d %d %d",configOn->couleur,configOn->preconf,(receivedCanMsg.data)[0],(receivedCanMsg.data)[1],(receivedCanMsg.data)[2],(receivedCanMsg.data)[3],(receivedCanMsg.data)[4],(receivedCanMsg.data)[5],configOn->envoi_can_zigbee,configOn->envoi_uart_zigbee);
					TXT_SetPos(lcd, THD_pos(12,12));
					TXT_PrintString(lcd, config);		// �criture de la confirmation de configuration re�ue
					
					TXT_SetPos(lcd, THD_pos(1,14));
					TXT_PrintString(lcd, "Validez pour terminer la configuration");
					break;
					
				default:
					// message ne provoquant aucune r�action carte super
					break;
			}	
			BUFFER_add(receivedCanMsg);
			CANmsgToU2tx (&receivedCanMsg);
		}
	}
	
	if (global.flags.u2rx)
	{
		if(u2rxToCANmsg (&receivedCanMsg))
		{
			LED_2 = !LED_2;
			BUFFER_add(receivedCanMsg);
			CAN_send(&receivedCanMsg);			//on renvoie le message sur le CAN
//			CANmsgToU2tx (&receivedCanMsg);		//renvoie du message sur uart2
		}
	}
}

void askNewColor(config* configOn)
{
	if(isSWEvent(swBuffer))
	{
		if(getSWEvent(swBuffer) == MASK_COLOR && isSWOn(MASK_COLOR)) 
		{
			CAN_msg_t newColormsg;
			Uint8 newColor;
			newColormsg.sid = SUPER_ASK_COLOR;
			newColormsg.size = 1;
			if(configOn->couleur == 2) newColor = 0;	//Cas sp�cial � la premi�re occurence car la couleur est initialis�e � 2=ind�finie, on demande alors la couleur O -> rouge pour configOn
			else newColor = !configOn->couleur;			//Sinon on demande l'inverse de la couleur actuelle
			(newColormsg.data)[0] = newColor;
			CAN_send(&newColormsg);						//On envoie le message
		}
		swBuffer = SW_PORT;
	}
}

void changeColor(CAN_msg_t newColormsg, config* configOn)
{
	configOn->couleur = (newColormsg.data)[0];		//Le champ couleur de la configuration est mis � jour
	if (configOn->couleur)
		global.couleur_Match = ROUGE;	//La variable globale couleur est mise � jour
	else
		global.couleur_Match = VERT;
	SetLedColor(global.couleur_Match);				//La couleur de la LED est mise � jour
}

void clearScreen(THD_struct *lcd)
{
	TXT_ClearScreen(lcd);
	GFX_ClearScreen(lcd);
}

void affichePret(THD_struct *lcd, config* configOn) 
{
	global.confirmation_config = 0;		//On abaisse le "drapeau" de confirmation
	
	clearScreen (lcd);
	TXT_SetPos(lcd, THD_pos(16,8));
	TXT_PrintString(lcd, "ARCHI'TECH");
	
	CAN_msg_t configuration;				//Cr�ation du message de configuration � destination de la carte P
	configuration.sid = SUPER_ASK_CONFIG;
	(configuration.data)[0] = configOn->strateg;				//premier octet de donn�es : la strat�gie choisie
	(configuration.data)[1] = configOn->depot_zone_1;		//deuxi�me octet de donn�es : le d�p�t en zone 1
	(configuration.data)[2] = configOn->depot_zone_2;		//troisi�me octet de donn�es : le d�p�t en zone 2
	(configuration.data)[3] = configOn->depot_zone_3;		//quatri�me octet de donn�es : le d�p�t en zone 3
	(configuration.data)[4] = configOn->evitement;			//cinqui�me octet de donn�es : l'�vitement
	(configuration.data)[5] = configOn->balises;				//sixi�me octet de donn�es : les balises
	configuration.size = 6;
	
	CAN_send(&configuration);
	
	TXT_SetPos(lcd, THD_pos(10,10));
	TXT_PrintString(lcd, "Configuration non recue");
	
	TXT_SetPos(lcd, THD_pos(1,12));
	TXT_PrintString(lcd, "Appuyez sur CANCEL pour revenir au menu");
	
	while(1) 
	{
		if(isSWEvent(swBuffer)) 
		{
			switch(getSWEvent(swBuffer)) 
			{
				case MASK_VALID:
					if(isSWOn(MASK_VALID) /*&& global.confirmation_config*/)		//Pour la belgique on accepte de d�marrer le match m�me sans confirmation .On ne peut valider que si la configuration a bien �t� re�ue
					{
						enMatch(lcd);
						return;
					}
				break;
				case MASK_CANCEL:
					if(isSWOn(MASK_CANCEL)) 
					{
						clearScreen(lcd);
						return;
	   				}
				break;
			}
			/*On met � jour le buffer*/
    		swBuffer = SW_PORT;
		}
		checkFlags(lcd, configOn);
	}
}


/* Affichage des cadres du menu principal */

void drawCurs(THD_struct *lcd, Uint8 page)
{
	GFX_DrawFrame(lcd, THD_pos(MENUP_POS_X, MENUP_POS_Y+page*(BTN_MENUP_HEIGHT+BTN_MENUP_OFFSET_Y)), THD_pos(MENUP_POS_X+BTN_MENUP_WIDTH, MENUP_POS_Y+page*(BTN_MENUP_HEIGHT+BTN_MENUP_OFFSET_Y)+BTN_MENUP_HEIGHT), SET);
}

void undrawCurs(THD_struct *lcd, Uint8 page)
{
	GFX_DrawFrame(lcd, THD_pos(MENUP_POS_X, MENUP_POS_Y+page*(BTN_MENUP_HEIGHT+BTN_MENUP_OFFSET_Y)), THD_pos(MENUP_POS_X+BTN_MENUP_WIDTH, MENUP_POS_Y+page*(BTN_MENUP_HEIGHT+BTN_MENUP_OFFSET_Y)+BTN_MENUP_HEIGHT), RESET);
}


/* Affichage des cadres des sous menus */

void sous_drawCurs(THD_struct *lcd, Uint8 sous_menu_select)
{
	GFX_DrawFrame(lcd, THD_pos(SMENU_POS_X, SMENU_POS_Y+sous_menu_select*(SBTN_HEIGHT+BTN_SMENU_OFFSET_Y)), THD_pos(SMENU_POS_X+SBTN_WIDTH, SMENU_POS_Y+sous_menu_select*(SBTN_HEIGHT+BTN_SMENU_OFFSET_Y)+SBTN_HEIGHT), SET);
}

void sous_undrawCurs(THD_struct *lcd, Uint8 sous_menu_select)
{
	GFX_DrawFrame(lcd, THD_pos(SMENU_POS_X, SMENU_POS_Y+sous_menu_select*(SBTN_HEIGHT+BTN_SMENU_OFFSET_Y)), THD_pos(SMENU_POS_X+SBTN_WIDTH, SMENU_POS_Y+sous_menu_select*(SBTN_HEIGHT+BTN_SMENU_OFFSET_Y)+SBTN_HEIGHT), RESET);
}

void sous_drawCursDouble(THD_struct *lcd, Uint8 sous_menu_select)
{
	GFX_DrawFrame(lcd, THD_pos(SMENU_POS_X, SMENU_POS_Y+sous_menu_select*2*(SBTN_HEIGHT+BTN_SMENU_OFFSET_Y)), THD_pos(SMENU_POS_X+SBTN_WIDTH, SMENU_POS_Y+sous_menu_select*2*(SBTN_HEIGHT+BTN_SMENU_OFFSET_Y)+SBTN_HEIGHT), SET);
}

void sous_undrawCursDouble(THD_struct *lcd, Uint8 sous_menu_select)
{
	GFX_DrawFrame(lcd, THD_pos(SMENU_POS_X, SMENU_POS_Y+sous_menu_select*2*(SBTN_HEIGHT+BTN_SMENU_OFFSET_Y)), THD_pos(SMENU_POS_X+SBTN_WIDTH, SMENU_POS_Y+sous_menu_select*2*(SBTN_HEIGHT+BTN_SMENU_OFFSET_Y)+SBTN_HEIGHT), RESET);
}


/* Affichage des cadres des sous sous menus */

void ssous_undrawCursDouble(THD_struct *lcd, Uint8 ligne, Uint8 valeur)
{
	GFX_DrawFrame(lcd, THD_pos(SSMENU_POS_X+(SSBTN_WIDTH+BTN_SSMENU_OFFSET_Y+BTN_SSMENU_OFFSET_X)*!valeur, SSMENU_POS_Y+(((ligne*2)+1)*(SSBTN_HEIGHT+BTN_SSMENU_OFFSET_Y))), THD_pos(SSMENU_POS_X+SSBTN_WIDTH+(SSBTN_WIDTH+BTN_SSMENU_OFFSET_Y+BTN_SSMENU_OFFSET_X)*!valeur,SSMENU_POS_Y+((ligne*2)+1)*(SSBTN_HEIGHT+BTN_SSMENU_OFFSET_Y)+SSBTN_HEIGHT), RESET);		/* !valeur pour que '1' corresponde bien � "oui" et '0' � "non" */	
}

void ssous_drawCursDouble(THD_struct *lcd, Uint8 ligne, Uint8 valeur)
{
	GFX_DrawFrame(lcd, THD_pos(SSMENU_POS_X+(SSBTN_WIDTH+BTN_SSMENU_OFFSET_Y+BTN_SSMENU_OFFSET_X)*!valeur, SSMENU_POS_Y+(((ligne*2)+1)*(SSBTN_HEIGHT+BTN_SSMENU_OFFSET_Y))), THD_pos(SSMENU_POS_X+SSBTN_WIDTH+(SSBTN_WIDTH+BTN_SSMENU_OFFSET_Y+BTN_SSMENU_OFFSET_X)*!valeur,SSMENU_POS_Y+((ligne*2)+1)*(SSBTN_HEIGHT+BTN_SSMENU_OFFSET_Y)+SSBTN_HEIGHT), SET);		/* !valeur pour que '1' corresponde bien � "oui" et '0' � "non" */
}



void printTitle(THD_struct *lcd, Uint8 page)
{
	TXT_SetPos(lcd, THD_pos(TITLE_POS_X,TITLE_POS_Y));
	TXT_PrintString(lcd, SWTxt[page]);
}

void eraseTitle(THD_struct *lcd)
{
	const char emptyString[MAX_TEXT_LEN] = "       ";
	TXT_SetPos(lcd, THD_pos(TITLE_POS_X,TITLE_POS_Y));
	TXT_PrintString(lcd, emptyString);
}

void active_choice(THD_struct *lcd, Uint8 smenu) {
	const char string[2] = "#";
	TXT_SetPos(lcd, THD_pos(STXT_POS_X+MAX_STXT_LEN+4,STXT_POS_Y+2*smenu));
	TXT_PrintString(lcd, string);
}

void unactive_choice(THD_struct *lcd, Uint8 smenu) 
{
	const char emptyString[2] = " ";
	TXT_SetPos(lcd, THD_pos(STXT_POS_X+MAX_STXT_LEN+4,STXT_POS_Y+2*smenu));
	TXT_PrintString(lcd, emptyString);
}
