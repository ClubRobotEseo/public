#include "interface.h"
#include "batterie.h"


const char SWTxt[BTN_NUMBER][MAX_TEXT_LEN] = {
	"Pret",
	"Preconfig",
	"Strategies",
	"Zones depot",
	"Config",
	"Echanges",
	"Lecture"
};


void affichage(THD_struct *lcd, config* configOn)
{
	Uint8 page = 100;
	
	/************************/
	/* page			 		*/
	/* 0=pret				*/
	/* 1=pr�conf			*/
	/* 2=configuration 		*/
	/* 3=strat�gie			*/
	/* 4=recalage			*/
	/* 5=lecture CAN		*/
	/* 100 = menu principal	*/
	/************************/

	/************************************************************************/
	/*	Multiplier les valeurs ci dessus par 10 pour afficher le menu		*/
	/*	principal avec l'onglet de selection sur le sous menu choisi		*/
	/************************************************************************/


	while(1)
	{
		switch (page)
		{
			case 100: case 10: case 20: case 30: case 40: case 50: case 60:
				page /= 10;		/*retour aux valeurs de position des titres*/
				page = afficheMenu(lcd, page, configOn);
				break;
			case 0: 
				affichePret(lcd, configOn);
				page = 100;
				break;
			case 1:
				affichePreconf(lcd, configOn);
				page *= 10;
				break;
			case 2:
				afficheStrateg(lcd, configOn);
				configOn->preconf=0;
				page *= 10;
				break;
			case 3:
				afficheDepot(lcd, configOn);
				configOn->preconf=0;
				page *= 10;
				break;
			case 4:
				afficheConfig(lcd, configOn);
				configOn->preconf=0;
				page *= 10;
				break;
			case 5: 
				afficheEchange(lcd, configOn);
				configOn->preconf=0;
				page *= 10;
				break;
			case 6:
				afficheLecture(lcd, configOn);
				page *= 10;
				break;
			default:
				printf("Erreur dans la page demand�e par la fonction affichage\n");
				break;
		}
	}
}

Uint8 afficheMenu(THD_struct *lcd, Uint8 page, config* configOn)
{
	extern Uint8 swBuffer;


	/************************/
	/* page			 		*/
	/* 0=pret				*/
	/* 1=pr�conf			*/
	/* 2=configuration 		*/
	/* 3=strat�gie			*/
	/* 4=recalage			*/
	/* 5=lecture CAN		*/
	/* 100 = menu principal	*/
	/************************/
	page=(page==10)?0:page;
	afficheTxtMenu(lcd, page);
	
	affiche_batterie(lcd);		/* Affichage de la batterie */
	
	while(1) 
	{
		if(isSWEvent(swBuffer)) 
		{
			switch(getSWEvent(swBuffer)) 
			{
				case MASK_TOP:    /* Actions pour haut */
					if(isSWOn(MASK_TOP)) 
					{
	    				if(page > 0) 
						{
		    				undrawCurs(lcd, page);
		    				page --;
		    				drawCurs(lcd, page);
		    			}
            		}
					break;
				case MASK_BOT:
					if(isSWOn(MASK_BOT)) 
					{
						if(page < BTN_NUMBER-1) 
						{
		    				undrawCurs(lcd, page);
		    				page ++;
		    				drawCurs(lcd, page);
						}
            		}
					break;
				case MASK_VALID:
					if(isSWOn(MASK_VALID)) 
					{
						efface_batterie(lcd);
						printTitle(lcd, page);
						return page;
					}
					break;
				case MASK_CANCEL:
					if(isSWOn(MASK_CANCEL)) 
					{
	   				}
					break;
				case MASK_COLOR:
					if(isSWOn(MASK_COLOR))
					{
						askNewColor(configOn);
					}
					break;
			}
			/*On met � jour le buffer*/
      		swBuffer = SW_PORT;
		}
		checkFlags(lcd, configOn);		//parallelisation du menu et de la r�ception des messages
	}
}

void afficheTxtMenu(THD_struct *lcd, Uint8 page)
{
   Uint8 i;
	
	for(i=0; i<BTN_NUMBER; i++)
	{
		TXT_SetPos(lcd, THD_pos(3,2*(i+1)));
		TXT_PrintString(lcd, SWTxt[i]);
		GFX_DrawFrame(lcd, THD_pos(MENUP_POS_X+1, MENUP_POS_Y+1+i*(BTN_MENUP_HEIGHT+BTN_MENUP_OFFSET_Y)), THD_pos(MENUP_POS_X+BTN_MENUP_WIDTH-1, MENUP_POS_Y-1+i*(BTN_MENUP_HEIGHT+BTN_MENUP_OFFSET_Y)+BTN_MENUP_HEIGHT), SET);
	}
	drawCurs(lcd, page);
}


void drawMenu(THD_struct *lcd)
{
	Uint8 i;
	
	for(i=0; i<BTN_NUMBER; i++)
	{
		TXT_SetPos(lcd, THD_pos(3,2*(i+1)));
		TXT_PrintString(lcd, SWTxt[i]);
		GFX_DrawFrame(lcd, THD_pos(MENUP_POS_X+1, MENUP_POS_Y+1+i*(BTN_MENUP_HEIGHT+BTN_MENUP_OFFSET_Y)), THD_pos(MENUP_POS_X+BTN_MENUP_WIDTH-1, MENUP_POS_Y-1+i*(BTN_MENUP_HEIGHT+BTN_MENUP_OFFSET_Y)+BTN_MENUP_HEIGHT), SET);
	}
}
