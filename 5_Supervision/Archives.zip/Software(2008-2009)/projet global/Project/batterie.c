#include "batterie.h"
#include "..\QS\QS_adc.h"

void affiche_batterie(THD_struct *lcd)
{	
	TXT_SetPos(lcd, THD_pos(BATTERIE_TITRE_X,BATTERIE_TITRE_Y));
	TXT_PrintString(lcd, "Batterie 24 Volts");
	GFX_DrawFrame (lcd, THD_pos(BATTERIE_POS_X+BATTERIE_WIDTH/3,BATTERIE_POS_Y-BATTERIE_HEIGHT/12), THD_pos(BATTERIE_POS_X+2*(BATTERIE_WIDTH/3),BATTERIE_POS_Y), SET);		/* Dessin du haut de l'icone de batterie */
	GFX_DrawFrame (lcd, THD_pos(BATTERIE_POS_X,BATTERIE_POS_Y), THD_pos(BATTERIE_POS_X+BATTERIE_WIDTH,BATTERIE_POS_Y+BATTERIE_HEIGHT), SET);
	
	Uint16 Vbat;
	Vbat = (ADC_getValue(0));		/* L'entr�e analogique que l'on utilise est la seule s�lectionn�e, donc la premi�re, donc num�rot�e 0 */
	char Info[30];
	sprintf(Info,"%s : %.2f Volts",((double)Vbat*24/459.16<20)?"Faible !":"Connectee",(double)Vbat*24/459.16);
	TXT_SetPos(lcd, THD_pos(BATTERIE_INFO_X,BATTERIE_INFO_Y));
	TXT_PrintString(lcd, Info);
	
	if((double)Vbat*24/459.16<=20.)
	{
		GFX_DrawRect (lcd, THD_pos(BATTERIE_POS_X+BATTERIE_WIDTH/3,BATTERIE_POS_Y+BATTERIE_HEIGHT/6), THD_pos(BATTERIE_POS_X+2*(BATTERIE_WIDTH/3),BATTERIE_POS_Y+2*(BATTERIE_HEIGHT/3)), SET);
		GFX_DrawRect (lcd, THD_pos(BATTERIE_POS_X+BATTERIE_WIDTH/3,BATTERIE_POS_Y+2*(BATTERIE_HEIGHT/3)+BATTERIE_HEIGHT/12), THD_pos(BATTERIE_POS_X+2*(BATTERIE_WIDTH/3),BATTERIE_POS_Y+2*(BATTERIE_HEIGHT/3)+3*(BATTERIE_HEIGHT/12)), SET);
	}
	else
	{
		Uint8 voltage_batterie = (((double)Vbat*24/459.16)-20)*66/6;	/* les valeurs d'entr�e du graphe varient entre 0 et 66 et l'on varie de 20 � 26 */
		Uint8 Pos_y_niveau_batterie = (voltage_batterie>0)? BATTERIE_POS_Y+BATTERIE_HEIGHT-2-voltage_batterie : 0;		/* calcul de la position en Y du niveau de remplissage de la batterie */
		GFX_DrawRect (lcd, THD_pos(BATTERIE_POS_X+2,Pos_y_niveau_batterie), THD_pos(BATTERIE_POS_X+BATTERIE_WIDTH-2,BATTERIE_POS_Y+BATTERIE_HEIGHT-1), SET);		/* Affichage du niveau de remplissage de la batterie sous forme d'un rectangle plein */
	}
}


void efface_batterie(THD_struct *lcd)
{
	TXT_SetPos(lcd, THD_pos(BATTERIE_TITRE_X,BATTERIE_TITRE_Y));
	TXT_PrintString(lcd, "                 ");
	GFX_DrawRect (lcd, THD_pos(BATTERIE_POS_X,BATTERIE_POS_Y-BATTERIE_HEIGHT/12), THD_pos(BATTERIE_POS_X+BATTERIE_WIDTH,BATTERIE_POS_Y+BATTERIE_HEIGHT+1), RESET);		/* utilisation de DrawRect car il faut aussi effacer l'int�rieur de la batterie, rectangle plus grand que BATTERIE_HEIGHT car il faut aussi effacer le petit bout du haut */
	TXT_SetPos(lcd, THD_pos(BATTERIE_INFO_X,BATTERIE_INFO_Y));
	TXT_PrintString(lcd, "                              ");
}


void rafraichit_batterie(THD_struct *lcd)
{
	efface_batterie(lcd);
	affiche_batterie(lcd);
}
