/*
 *  Club Robot ESEO 2007 - 2008
 *  PHOBOSS
 *
 *  Fichier : Constantes.h
 *  Package : SuperVision
 *  Description : structure de configuration du robot
 *  Auteur : Jacen
 *  Version 20080131
 */

#ifndef __CONFIG_STRUCT__
	#define __CONFIG_STRUCT__

	typedef struct 
	{
		Uint8 couleur;				/* 0=rouge, 1=vert, 2=ind�finie, initialis�e � 2 dans le main*/
		Uint8 preconf;				/* numero de la configuration pr�d�finie 0 - 1 - 2 - 3 */
		Uint8 strateg;				/* numero de la strategie 0 - 1 - 2 - 3 - 4 */
		Uint8 depot_zone_1;			/* 0=non, 1=oui */
		Uint8 depot_zone_2;			/* 0=non, 1=oui */
		Uint8 depot_zone_3;			/* 0=non, 1=oui */
		Uint8 evitement;            /* 0=non, 1=oui */
		Uint8 balises;				/* 0=inactives, 1=actives */
		Uint8 envoi_can_zigbee;		/* 0=non, 1=oui */
		Uint8 envoi_uart_zigbee;	/* 0=non, 1=oui */
	} config;
#endif /* endef __CONFIG_STRUCT__ */
