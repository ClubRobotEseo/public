#include "interface.h"

const char SWTxtDepot[BTN_NUMBER_CONFIG][MAX_STXT_LEN] = {
     "Zone 1",
     "Zone 2",
     "Zone 3"
};

const char SWTxtSDepot[2][MAX_STXT_LEN] = {
	"Oui",
	"Non",
};




void afficheDepot(THD_struct *lcd, config* configOn) 
{
	extern Uint8 swBuffer;

	Uint8 smenu=0;

	afficheTxtDepot(lcd, configOn);

	while(1) 
	{
		if(isSWEvent(swBuffer)) 
		{
			switch(getSWEvent(swBuffer)) 
			{
				case MASK_TOP:    /* Actions pour haut*/
					if(isSWOn(MASK_TOP)) 
					{
	    				if(smenu > 0) 
						{
		    				sous_undrawCursDouble(lcd, smenu);
		    				smenu--;
		    				sous_drawCursDouble(lcd, smenu);
		    			}
            		}
				break;
				case MASK_BOT:
					if(isSWOn(MASK_BOT)) 
					{
						if(smenu < BTN_NUMBER_CONFIG-1) 
						{
		    				sous_undrawCursDouble(lcd, smenu);
		    				smenu++;
		    				sous_drawCursDouble(lcd, smenu);
						}
            		}
				break;
				case MASK_VALID:
					if(isSWOn(MASK_VALID)) 
					{
						switch(smenu) 
						{
							case 0:
								ssous_undrawCursDouble(lcd,0,configOn->depot_zone_1);
		    					configOn->depot_zone_1=!configOn->depot_zone_1;
		    					ssous_drawCursDouble(lcd,0,configOn->depot_zone_1);
								break;
							case 1:
								ssous_undrawCursDouble(lcd,1,configOn->depot_zone_2);
		    					configOn->depot_zone_2=!configOn->depot_zone_2;
		    					ssous_drawCursDouble(lcd,1,configOn->depot_zone_2);
								break;
							case 2:
								ssous_undrawCursDouble(lcd,2,configOn->depot_zone_3);
		    					configOn->depot_zone_3=!configOn->depot_zone_3;
		    					ssous_drawCursDouble(lcd,2,configOn->depot_zone_3);
								break;
							default:
								printf("erreur dans la fonction afficheConfig");
								break;
						}
					}
				break;
				case MASK_CANCEL:
					if(isSWOn(MASK_CANCEL)) 
					{
						clearScreen(lcd);
						return;
	   				}
				break;
				case MASK_COLOR:
					if(isSWOn(MASK_COLOR))
					{
						askNewColor(configOn);
					}
				break;
			}
			/*On met � jour le buffer*/
	      	swBuffer = SW_PORT;
		}
		checkFlags(lcd, configOn);		//parallelisation du menu et de la r�ception des messages
	}
}

void afficheTxtDepot(THD_struct *lcd, config* configOn) 
{
	Uint8 i;
	
	for(i=0; i<BTN_NUMBER_CONFIG; i++)
	{
		TXT_SetPos(lcd, THD_pos(STXT_POS_X,STXT_POS_Y+4*i));
		TXT_PrintString(lcd, SWTxtDepot[i]);
		GFX_DrawFrame(lcd, THD_pos(SMENU_POS_X+1, SMENU_POS_Y+1+i*2*(SBTN_HEIGHT+BTN_SMENU_OFFSET_Y)), THD_pos(SMENU_POS_X+SBTN_WIDTH-1, SMENU_POS_Y-1+i*2*(SBTN_HEIGHT+BTN_SMENU_OFFSET_Y)+SBTN_HEIGHT), SET);
		TXT_SetPos(lcd, THD_pos(STXT_POS_X,STXT_POS_Y+4*i+2));
		TXT_PrintString(lcd, SWTxtSDepot[0]);
		TXT_SetPos(lcd, THD_pos(STXT_POS_X+10,STXT_POS_Y+4*i+2));
		TXT_PrintString(lcd, SWTxtSDepot[1]);
	}
	ssous_drawCursDouble(lcd,0,configOn->depot_zone_1);
	ssous_drawCursDouble(lcd,1,configOn->depot_zone_2);
	ssous_drawCursDouble(lcd,2,configOn->depot_zone_3);
	sous_drawCursDouble(lcd, 0);
}
