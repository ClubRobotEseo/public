/*
 *  Club Robot ESEO 2008 - 2009
 *  ARCHI'TECH
 *
 *  Fichier : Constantes.h
 *  Package : SuperVision
 *  Description : constantes pour les fonctions d'affichage
 *  Auteur : Jacen, Jixi
 *  Version 20090131
 */

#ifndef CONSTANTES_H
	#define CONSTANTES_H
	#define CAN_BUFFER_SIZE 0xFF
	#define NB_MSG_LCD 		16

	#define	LCD_WIDTH		240
	#define LCD_HEIGHT		128

	/* constantes titre */
	#define TITLE_POS_X		20
	#define TITLE_POS_Y		2

	/* constantes boutons */
	#define BTN_NUMBER				7
	#define BTN_NUMBER_PRECONF		4
	#define BTN_NUMBER_CONFIG		3
	#define BTN_NUMBER_ECHANGES		2
	#define BTN_NUMBER_PRET			1
	#define BTN_NUMBER_STRATEG		4


	/* constantes textes */
	#define MAX_TEXT_LEN		12
	#define MAX_STXT_LEN 		12
	#define MAX_CONFIG_LEN		9
	#define MAX_PRECONF_LEN		10
	#define MAX_STRATEG_LEN 	10
	#define MAX_ECHANGES_LEN	17

	/* constantes menu principal */
	#define MENUP_POS_X 		10
	#define MENUP_POS_Y 		5
	#define BTN_MENUP_HEIGHT 	14
	#define BTN_MENUP_WIDTH 	72
	#define BTN_MENUP_OFFSET_Y 	2		/* D�calage lors du passage d'une ligne � l'autre */

	/* constantes sous menus */
	#define SMENU_POS_X			100
	#define SMENU_POS_Y			29	
	#define SBTN_HEIGHT			14
	#define SBTN_WIDTH			110
	#define BTN_SMENU_OFFSET_Y	2
	#define STXT_POS_X			18
	#define STXT_POS_Y			5

	/* constantes sous sous menus */
	#define SSMENU_POS_X		101
	#define SSMENU_POS_Y		30
	#define SSBTN_HEIGHT    	12
	#define SSBTN_WIDTH			48	
	#define BTN_SSMENU_OFFSET_Y	4
	#define BTN_SSMENU_OFFSET_X 8		/* D�calage horizontal dans les sous sous menus */
	
	/* constantes du menu Affiche lecture */
	#define AFFICHE_ORIGINE_X	1
	#define AFFICHE_ORIGINE_Y	3
	#define MAX_OFFSET			14
	#define MAX_TEXTCAN_LEN		100

#endif /*ndef CONSTANTES_H*/
