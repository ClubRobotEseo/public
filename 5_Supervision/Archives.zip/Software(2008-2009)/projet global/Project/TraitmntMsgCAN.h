/*
 *  Club Robot ESEO 2006 - 2007
 *  Game Hoover
 *
 *  Fichier : TraitmntMsgCAN.h
 *  Package : SuperVision
 *  Description : affichage messages CAN
 *  Auteur : Kim
 *  Version 20070505
 */


#ifndef __MSGCAN_H_
	#define __MSGCAN_H_
	
	#include "THD_advanced.h"
	#include "nomenclatureCAN.h"
	#include "..\QS\QS_all.h"
	#include "../QS/QS_CANmsgList.h"
	#include <stdio.h>
	#include <ctype.h>

	void printSIDCAN(Uint16 sid);
	void printDATA(CAN_msg_t msg_CAN);
	void printLCDDATA(CAN_msg_t msg_CAN,THD_struct *lcd);
	void printLCDSIZE(Uint8 size,THD_struct *lcd);
	void printLCDSIDCAN(Uint16 sid,THD_struct *lcd);


	typedef struct {
	    Uint16 x, y;
	    double a;
	} t_position;

	void pos_from_can_P (
	Uint8 *data, /* Donn�es de position au format can { Hx, Lx, Hy, Ly, Ha, La }*/
	t_position *pos) /* Position � remplir */;
	void pos_from_can_A (
	Uint8 *data, /* Donn�es de position au format can { Hx, Lx, Hy, Ly, Ha, La }*/
	t_position *pos) /* Position � remplir */;

#endif
