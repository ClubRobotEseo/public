/*
 *  THD_advanced.c: advanced functions
 *  Part of ThacidLCD package
 *  Copyright 2001-2006  Axel Voitier
 *  
 *  deadog@users.sourceforge.net
 *  
 *  This software is a computer program whose purpose is to control liquid crystal displays.
 *  
 *  This software is governed by the CeCILL  license under French law and
 *  abiding by the rules of distribution of free software.  You can  use, 
 *  modify and/ or redistribute the software under the terms of the CeCILL
 *  license as circulated by CEA, CNRS and INRIA at the following URL
 *  "http://www.cecill.info". 
 *  
 *  As a counterpart to the access to the source code and  rights to copy,
 *  modify and redistribute granted by the license, users are provided only
 *  with a limited warranty  and the software's author,  the holder of the
 *  economic rights,  and the successive licensors  have only  limited
 *  liability. 
 *  
 *  In this respect, the user's attention is drawn to the risks associated
 *  with loading,  using,  modifying and/or developing or reproducing the
 *  software by the user in light of its specific status of free software,
 *  that may mean  that it is complicated to manipulate,  and  that  also
 *  therefore means  that it is reserved for developers  and  experienced
 *  professionals having in-depth computer knowledge. Users are therefore
 *  encouraged to load and test the software's suitability as regards their
 *  requirements in conditions enabling the security of their systems and/or 
 *  data to be ensured and,  more generally, to use and operate it in the 
 *  same conditions as regards security. 
 *  
 *  The fact that you are presently reading this means that you have had
 *  knowledge of the CeCILL license and that you accept its terms.
 */

#define __THD_ADVANCED_C

#include "THD_advanced.h"


THD_GFX_T6963_com2_t *
THD_Init (
  THD_addr_port_t addr_data_port,
  THD_addr_port_t addr_data_control_port,
  THD_addr_port_t addr_control_port,
  THD_bit_list_e cd_pin,
  THD_bit_list_e rd_pin,
  THD_bit_list_e wr_pin,
  THD_bit_list_e ce_pin,
  THD_pos_t gfx_size,
  Uint8 font_width)
{
  THD_GFX_T6963_com1_t *com1=NULL;
  THD_GFX_T6963_com2_t *com2=NULL;

  com1 = GFX_T6963_CreateCom1 (addr_data_port, addr_data_control_port, addr_control_port, cd_pin, rd_pin, wr_pin, ce_pin);
  GFX_T6963_InitCom1 (com1);
  com2 = GFX_T6963_InitCom2_Default (com1, gfx_size, font_width);

  return com2;
}

THD_bool
GFX_DrawVLine (
  THD_GFX_T6963_com2_t *com2,
  THD_pos_t pos_start,
  THD_coord_t y_end,
  SET_RESET_e set_mode)
{
/*
 *  1 <= y <= gfx_row
 *  1 <= x <= gfx_col
 */

  THD_coord_t y;
  THD_Scoord_t isz_y, dy;

  if(com2 == NULL || !pos_start.x || pos_start.x > com2->gfx_size.x || !pos_start.y || pos_start.y > com2->gfx_size.y || !y_end || y_end > com2->gfx_size.y) {
    #ifdef SHOW_ERROR
    THD_SetError ("GFX_DrawVline : wrong parameter\n");
    #endif /* def SHOW_ERROR */
    return THD_FALSE;
  }

  dy = y_end - pos_start.y;
  if(dy > 0) isz_y = 1;
  else if(dy == 0) isz_y = 0;
  else { isz_y = -1; dy = -dy; }

  y = pos_start.y;
  while(dy >= 0) {
    GFX_T6963_SetPixel_Gfx (com2, THD_pos (pos_start.x, y), set_mode);
    y += isz_y;
    dy--;
  }
  
  #ifdef SHOW_VERBOSE
  if(VERBOSE_FILE != NULL) {
    fprintf(VERBOSE_FILE, VERBOSE_ID"GFX_DrawVline : from (%d, %d) to (%d, %d)\n", pos_start.x, pos_start.y, pos_start.x, y_end);
    fflush(VERBOSE_FILE);
  }
  #endif /* def SHOW_VERBOSE */
  
  return THD_TRUE;
}

THD_bool
GFX_DrawHLine (
  THD_GFX_T6963_com2_t *com2,
  THD_pos_t pos_start,
  THD_coord_t x_end,
  SET_RESET_e set_mode)
{
/*
 *  1 <= y <= gfx_row
 *  1 <= x <= gfx_col
 */

  THD_coord_t x;
  THD_Scoord_t isz_x, dx;

  if(com2 == NULL || !pos_start.x || pos_start.x > com2->gfx_size.x || !pos_start.y || pos_start.y > com2->gfx_size.y || !x_end || x_end > com2->gfx_size.x) {
    #ifdef SHOW_ERROR
    THD_SetError ("GFX_DrawHline : wrong parameter\n");
    #endif /* def SHOW_ERROR */
    return THD_FALSE;
  }

  dx = x_end - pos_start.x;
  if(dx > 0) isz_x = 1;
  else if(dx == 0) isz_x = 0;
  else { isz_x = -1; dx = -dx; }

  x = pos_start.x;
  while(dx >= 0) {
    GFX_T6963_SetPixel_Gfx (com2, THD_pos (x, pos_start.y), set_mode);
    x += isz_x;
    dx--;
  }
  
  #ifdef SHOW_VERBOSE
  if(VERBOSE_FILE != NULL) {
    fprintf(VERBOSE_FILE, VERBOSE_ID"GFX_DrawHline : from (%d, %d) to (%d, %d)\n", pos_start.x, pos_start.y, x_end, pos_start.y);
    fflush(VERBOSE_FILE);
  }
  #endif /* def SHOW_VERBOSE */
  
  return THD_TRUE;
}

THD_bool
GFX_DrawFrame (
  THD_GFX_T6963_com2_t *com2,
  THD_pos_t pos_start,
  THD_pos_t pos_end,
  SET_RESET_e set_mode)
{
  if(com2 == NULL || !pos_start.y || pos_start.y > com2->gfx_size.y || !pos_end.y || pos_end.y > com2->gfx_size.y || !pos_start.x || pos_start.x > com2->gfx_size.x || !pos_end.x || pos_end.x > com2->gfx_size.x) 
	{
		#ifdef SHOW_ERROR
		THD_SetError ("GFX_TraceCadre : wrong parameter\n");
		#endif /* def SHOW_ERROR */
		return THD_FALSE;
	}
  
	/* Top line */
	GFX_DrawHLine (com2, pos_start, pos_end.x, set_mode);
	/* Bottom line */
	GFX_DrawHLine (com2, THD_pos (pos_start.x, pos_end.y), pos_end.x, set_mode);
	/* Left line */
	GFX_DrawVLine (com2, pos_start, pos_end.y, set_mode);
	/* Right line */
	GFX_DrawVLine (com2, THD_pos (pos_end.x, pos_start.y), pos_end.y, set_mode);

  return THD_TRUE;
}

THD_bool
GFX_DrawRect (
  THD_GFX_T6963_com2_t *com2,
  THD_pos_t pos_start,
  THD_pos_t pos_end,
  SET_RESET_e set_mode)
{
	/* r�indent� par Jacen (club robot de l'eseo 2008-2009 */
	/* /!\ changement du style d'identation */
	int i;
	if(com2 == NULL || !pos_start.y || pos_start.y > com2->gfx_size.y || !pos_end.y || pos_end.y > com2->gfx_size.y || !pos_start.x || pos_start.x > com2->gfx_size.x || !pos_end.x || pos_end.x > com2->gfx_size.x) 
	{
		#ifdef SHOW_ERROR
		THD_SetError ("GFX_TraceCadre : wrong parameter\n");
		#endif /* def SHOW_ERROR */
		return THD_FALSE;
	}
	
	for(i=pos_start.y;i<pos_end.y;i++) 
	{
		GFX_DrawHLine (com2, THD_pos(pos_start.x,i), pos_end.x, set_mode);
	}
  	
	return THD_TRUE;
}
