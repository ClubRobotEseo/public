/*
 *  Club Robot ESEO 2006 - 2007
 *  Game Hoover
 *
 *  Fichier : TraitmntMsgCAN.c
 *  Package : SuperVision
 *  Description : affichage messages CAN
 *  Auteur : Kim
 *  Version 20070505
 */

#define __MSGCAN_C

#include "TraitmntMsgCAN.h"


void printLCDSIDCAN(Uint16 sid,THD_struct *lcd){

	switch 	(sid) {
		case 0x790 : 
					 TXT_PrintString(lcd,"BROAD_START ");
					 break;
		case 0x7A0 : TXT_PrintString(lcd,"BROAD_STOP_ALL ");
					 break;
		/* Carte asser vers carte P */
		case 0x081 : TXT_PrintString(lcd,"P_TRAJ_FIN ");
					 break;
		case 0x082 : TXT_PrintString(lcd,"P_ASS_ERR ");
					 break;
		case 0x083 : TXT_PrintString(lcd,"P_POS_ROBOT ");
					 break;
		case 0x084 : TXT_PrintString(lcd,"P_ROBOT_FREIN");
					 break;
  		/* Carte P vers carte asser */
		case 0x101 : TXT_PrintString(lcd,"A_GO_POS ");
					 break;
		case 0x102 : TXT_PrintString(lcd,"A_VIT ");
					 break;
		case 0x103 : TXT_PrintString(lcd,"A_STOP ");
					 break;
		case 0x104 : TXT_PrintString(lcd,"A_GO_ANG ");
					 break;
		case 0x106 : TXT_PrintString(lcd,"A_CONTI_MUL ");
					 break;
		case 0x107 : TXT_PrintString(lcd,"A_STOP_MUL ");
					 break;
		case 0x108 : TXT_PrintString(lcd,"A_COUL ");
					 break;
		case 0x109 : TXT_PrintString(lcd,"A_POS ");
					 break;
		case 0x110 : TXT_PrintString(lcd,"A_DEBL ");
					 break;
		case 0x111 : TXT_PrintString(lcd,"A_DEBUG ");
					 break;
		/*Carte M vers carteP */
		case 0x085 : TXT_PrintString(lcd,"P_OBJET_IN ");
					 break;
		case 0x086 : TXT_PrintString(lcd,"P_PRET_A_TIR ");
					 break;
		case 0x087 : TXT_PrintString(lcd,"P_SHOOT ");
					 break;
		case 0x088 : TXT_PrintString(lcd,"P_CAS_CON ");
					 break;
	/* Carte P vers Carte M*/
		case 0x181 : TXT_PrintString(lcd,"M_OUVRE ");
					 break;
		case 0x182 : TXT_PrintString(lcd,"M_FERME ");
					 break;
		case 0x183 : TXT_PrintString(lcd,"M_TIRE ");
					 break;
		case 0x184 : TXT_PrintString(lcd,"M_VIT_BR ");
					 break;
		case 0x185 : TXT_PrintString(lcd,"M_AUTO ");
					 break;
		case 0x150 : TXT_PrintString(lcd,"P_TELEM ");
					 break;
		default :    TXT_PrintString(lcd," XXX");
					break;
	}
}


void printLCDDATA(CAN_msg_t msg_CAN,THD_struct *lcd){
	unsigned char dataReceive[8];
	int sid;
	char taille;
	char dataLCD[35];
	Uint8 j;
	t_position pos;

	sid = msg_CAN.sid;
	taille = msg_CAN.size;
	for(j=0;j<taille;j++) 
		dataReceive[j] = (msg_CAN.data)[j];

	switch 	(sid) {
		/* Carte asser vers carte P */
		case 0x081 : pos_from_can_A (dataReceive,&pos);
					 sprintf(dataLCD,"X:%d Y:%d A:%.2f",pos.x,pos.y,pos.a);
					 TXT_PrintString(lcd,dataLCD);
					 break;
		case 0x082 : pos_from_can_A (dataReceive,&pos);
					 sprintf(dataLCD,"X:%d Y:%d A:%.2f",pos.x,pos.y,pos.a);
					 TXT_PrintString(lcd,dataLCD);
					 break;
		case 0x083 : pos_from_can_A (dataReceive,&pos);
					 sprintf(dataLCD,"X:%d Y:%d A:%.2f",pos.x,pos.y,pos.a);
					 TXT_PrintString(lcd,dataLCD);
					 break;
  		/* Carte P vers carte asser */
		case 0x101 : pos_from_can_P (dataReceive,&pos);
					 sprintf(dataLCD,"X:%d Y:%d %s %s",pos.x,pos.y, (dataReceive[4] == 0) ? "AV" : "AR",
							 (dataReceive[5] == 0) ? "RAP" : "LEN");
					 TXT_PrintString(lcd,dataLCD);	
					 break;
		case 0x102 : sprintf(dataLCD,"%s",(dataReceive[0] == 0) ? "RAP" : "LEN");
					 TXT_PrintString(lcd,dataLCD);
					 break;
		case 0x104 : sprintf(dataLCD,"A:%.2f",((double) ((dataReceive[0] << 8) | dataReceive[1])) / 4096);
					 TXT_PrintString(lcd,dataLCD);
					 break;
		case 0x106 : pos_from_can_P (dataReceive,&pos);
					 sprintf(dataLCD,"X:%d Y:%d",pos.x,pos.y);
					 TXT_PrintString(lcd,dataLCD);
					 break;
		case 0x107 : sprintf(dataLCD,"%s",(dataReceive[0] == 0) ? "RAP" : "LEN");
					 TXT_PrintString(lcd,dataLCD);
					 break;
		case 0x108 : sprintf(dataLCD,"%s",(dataReceive[0] == 0) ? "ROUG" : "BLEU");
					 TXT_PrintString(lcd,dataLCD);
					 break;
		/*Carte M vers carteP */
		case 0x086 : sprintf(dataLCD,"%s",(dataReceive[0] == 0) ? "CAN" : "BOUT");
					 TXT_PrintString(lcd,dataLCD);
					 break;
		case 0x088 : sprintf(dataLCD,"%s (%d)",(dataReceive[0] == 0) ? "PIL" : ((dataReceive[0] == 1) ? "BLOC" : "WAIT"), dataReceive[0]);
					 TXT_PrintString(lcd,dataLCD);
					 break;
		case 0x150 : pos_from_can_P (dataReceive,&pos);
					 sprintf(dataLCD,"X:%d Y:%d %s",pos.x,pos.y, (dataReceive[4] == 0) ? "VD" : ((dataReceive[4] == 1) ? "RD" : ((dataReceive[4] == 2) ? "RG" : "VG")));
					 TXT_PrintString(lcd,dataLCD);
					 break;
	}
}

void printLCDSIZE(Uint8 size,THD_struct *lcd){
	char dataLCD[3];
	sprintf(dataLCD," (%d",size);
	TXT_PrintString(lcd,dataLCD);
}


void pos_from_can_P (
	unsigned char* dataReceive, /* Donn�es de position au format can { Hx, Lx, Hy, Ly, Ha, La }*/
	t_position *pos) /* Position � remplir */
{
  pos->x = (Uint16)(dataReceive[0] << 8) | (Uint16)dataReceive[1];
  pos->y = (Uint16)(dataReceive[2] << 8) | (Uint16)dataReceive[3];
}

void pos_from_can_A (
	unsigned char* dataReceive, /* Donn�es de position au format can { Hx, Lx, Hy, Ly, Ha, La }*/
	t_position *pos) /* Position � remplir */
{
  pos->x = (Uint16)(dataReceive[0] << 8) | dataReceive[1];
  pos->y = (Uint16)(dataReceive[2] << 8) | dataReceive[3];
  pos->a = ((double) ((dataReceive[4] << 8) | dataReceive[5])) / 4096;
}
