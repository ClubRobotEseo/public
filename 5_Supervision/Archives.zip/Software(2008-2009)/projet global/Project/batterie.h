#include "THD_advanced.h"
#include "THD_SYS_types.h"
#include <stdio.h>

/* Constantes de positionnement de l'icone de batterie */
#define BATTERIE_POS_X		140
#define BATTERIE_POS_Y		30
#define BATTERIE_HEIGHT		70
#define BATTERIE_WIDTH		50

#define BATTERIE_TITRE_X	20
#define BATTERIE_TITRE_Y	2
#define BATTERIE_INFO_X		18
#define BATTERIE_INFO_Y		15


void affiche_batterie(THD_struct *lcd);
void efface_batterie(THD_struct *lcd);
void rafraichit_batterie(THD_struct *lcd);
