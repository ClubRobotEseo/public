#ifndef INTERFACE_H_
#define INTERFACE_H_

	#include "THD_advanced.h"
	#include "THD_SYS_types.h"
	#include <stdio.h>
	#include "Constantes.h"
	#include "config_struct.h"

	/*D�finition des masques de boutons*/
	#define MASK_TOP	0b00000010
	#define MASK_BOT	0b00000001
	#define MASK_VALID	0b01000000
	#define MASK_CANCEL	0b00000100
	#define MASK_COLOR	0b00100000
	
	typedef enum{OFF,VERT,ROUGE,ORANGE}LedColor_e;		//pour la mise � jour de configOn->couleur on aura toujours global.couleur_Match = !configOn->couleur car rouge et vert sont invers�s dans les deux impl�mentations
	
	/* couleur sur LATB6 et LATB7 */
	#define SetLedColor(color)		LATB=((LATB&~0xC0)|(color<<6))		//LATB&~0xC0 met les bits 6 et 7 � 0, on fait ensuite un ou '|' bit � bit en d�calant l'argument de 6 pour qu'il se retrouve sur ls bits 6 et 7

	#define isSWEvent(buffer) (SW_PORT == buffer ? 0 : 1)
	#define isSWOn(mask) !(SW_PORT & mask)		//renvoie vrai pour une modification de type "appuie"
	#define getSWEvent(buffer) (SW_PORT^buffer)		//XOR bit � bit entre SW_PORT et buffer, renvoie le MASK du bouton modifi�

	typedef struct {
		Uint8 pos_x;
		Uint8 pos_y;
		char *text;
	} IButton;

	void enMatch(THD_struct *lcd);			//Fonction appel�e lorsque la phase de configuration est termin�e et qui tournera pendant tout le match
	void askNewColor(config* configOn);		//envoie d'un message CAN � destination de la carte P demandant le changement de la couleur
	void printCanMsg(CAN_msg_t* msg);
	void checkFlags(THD_struct *lcd, config* configOn);				//v�rifie l'occurence d'�ventuels flags, les renvoie et ajoute les messages CAN au buffer de messages
	void checkCANAndWrite(THD_struct *lcd);		//check les messages CAN et les �crit � l'�cran (� utiliser dans la fonction afficheLecture)
	void changeColor(CAN_msg_t newColormsg, config* configOn);		//fonction appel�e lors de la r�ception du message BOADCAST_COLOR pour effectuer le changement de couleur
	void drawMenu(THD_struct *lcd);
	void drawCurs(THD_struct *lcd, Uint8 page);
	void undrawCurs(THD_struct *lcd, Uint8 page);
	void printTitle(THD_struct *lcd, Uint8 page);
	void eraseTitle(THD_struct *lcd);
	void affichage(THD_struct *lcd, config* configOn);
	Uint8 afficheMenu(THD_struct *lcd, Uint8 page, config* configOn);
	void afficheTxtMenu(THD_struct *lcd, Uint8 page);
	void affichePret(THD_struct *lcd, config* configOn);
	void affichePreconf(THD_struct *lcd, config* configOn);
	void afficheTxtPreconf(THD_struct *lcd, config* configOn);
	void afficheStrateg(THD_struct *lcd, config* configOn);
	void afficheTxtStrateg(THD_struct *lcd, config* configOn);
	void afficheDepot(THD_struct *lcd, config* configOn);
	void afficheTxtDepot(THD_struct *lcd, config* configOn);
	void afficheEchange(THD_struct *lcd, config* configOn);
	void afficheTxtEchange(THD_struct *lcd, config* configOn);
	void afficheConfig(THD_struct *lcd, config* configOn);
	void afficheTxtConfig(THD_struct *lcd, config* configOn);
	void afficheLecture(THD_struct *lcd, config* configOn);
	void active_choice(THD_struct *lcd, Uint8 smenu);
	void unactive_choice(THD_struct *lcd, Uint8 smenu);
	void sous_drawCurs(THD_struct *lcd, Uint8 sous_menu_select);
	void sous_drawCursDouble(THD_struct *lcd, Uint8 sous_menu_select);
	void sous_undrawCursDouble(THD_struct *lcd, Uint8 sous_menu_select);
	void sous_undrawCurs(THD_struct *lcd, Uint8 sous_menu_select);
	void ssous_undrawCursDouble(THD_struct *lcd, Uint8 ligne, Uint8 valeur);
	void ssous_drawCursDouble(THD_struct *lcd, Uint8 ligne, Uint8 valeur);
	void clearScreen(THD_struct *lcd);
#endif
