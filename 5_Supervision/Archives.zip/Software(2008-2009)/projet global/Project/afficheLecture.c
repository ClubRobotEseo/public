#include "interface.h"
#include "..\QS\QS_can.h"
#include "..\QS\QS_uart.h"
#include "buffer.h"

void afficheLecture(THD_struct *lcd, config* configOn) 
{
	extern Uint8 swBuffer;
	
	clearScreen(lcd);		//On efface l'�cran pour avoir un maximum de place pour afficher les messages
	
	TXT_SetPos(lcd, THD_pos(15,1));	//On r��crit le titre mais un peu plus haut que les autres
	TXT_PrintString(lcd, "Lecture");
	
	global.affiche_lecture_offset = 0;		//remise � 0 de l'offset d'affichage des messages (on recommence � �crire � la premi�re ligne)

	while(1) 
	{
		if(isSWEvent(swBuffer)) 
		{
			switch(getSWEvent(swBuffer)) 
			{
				case MASK_VALID:
					if(isSWOn(MASK_VALID)) 
					{
						BUFFER_flush();		//Lors de l'appui sur le bouton VALID on vide le buffer
					}
				break;
				case MASK_CANCEL:
					if(isSWOn(MASK_CANCEL)) 
					{
						clearScreen(lcd);
						return;
	   				}
				break;
			}
			/*On met � jour le buffer*/
    		swBuffer = SW_PORT;
		}
		if(global.affiche_lecture_offset >= MAX_OFFSET)		//Cas d'effacement de l'�cran lorsque 14 messages ont �t� �crits (la fonction checkCANAndWrite voudra �crire Match encours mais comme on �crit d�j� Lecture ici et que l'on r�initialise l'offset, �a marche
		{
			clearScreen(lcd);
			TXT_SetPos(lcd, THD_pos(15,1));			//On r��crit le titre
			TXT_PrintString(lcd, "Lecture");
			global.affiche_lecture_offset = 0;		//r�initialisation de l'offset
		}
		checkCANAndWrite(lcd);		//check et affiche les messages
	}
}
