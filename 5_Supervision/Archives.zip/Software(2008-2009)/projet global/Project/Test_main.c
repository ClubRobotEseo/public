/*
 *	Club Robot ESEO 2008 - 2009
 *	Archi-Tech'
 *
 *	Fichier : Test_main.c
 *	Package : Projet Standard
 *	Description : fonction principale permettant
 *				l'appel des fonctions de test
 *				de la carte supervision
 *	Auteur : Jacen & Jixi
 *	Version 20081209
 */

#define TEST_MAIN_C
#include "Test_main.h"
#include "../QS/QS_timer.h"
#include "Buffer.h"
   #include "interface.h"
	#include "THD_advanced.h"
	#include "THD_SYS_types.h"
	#include "Constantes.h"
	#include "config_struct.h"
	#include "..\QS\QS_adc.h"
	#include "../QS/QS_CANmsgList.h"

#ifdef TEST_MODE


	int main (void)
	{
		PORTS_init();
		CAN_init();
		ADC_init();		/* utilistion de l'entr�e analogique AN2 pour surveiller la batterie */
		UART_init();
		
		LCD_FS=1;
		nop();
		LCD_RV=0;
		
		/*Variables du lcd*/
		THD_struct *lcd=NULL;

//	#define	LCD_WIDTH		240
//	#define LCD_HEIGHT		128

		/* lcd = THD_Init ((int)&PORTE,(int) &TRISE,(int) &PORTG, PIN_8, PIN_2, PIN_1, PIN_7, THD_pos(LCD_WIDTH, LCD_HEIGHT), 6); */
		lcd = THD_Init ((int)&PORTE,(int) &TRISE,(int) &PORTD, PIN_4, PIN_2, PIN_1, PIN_3, THD_pos(LCD_WIDTH, LCD_HEIGHT), 6);		//doit �tre fait apr�s les initialisations de ports
		TXT_ClearScreen(lcd);
		GFX_ClearScreen(lcd);
		
		config configOn = {2, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		
//		CAN_msg_t receivedCanMsg;

		global.TIMER3_loops=0;		//On initialise la variable qui compte le nombre de boucle du Timer3
		TIMER3_stop();				//Tant qu'on n'a pas lanc� le timer on est � l'instant 0
		TIMER3_run(250);			//On lance le timer3, il ne peut compter que jusqu'� 255 ms, on le fait boucler toutes les 250 ms
		
		BUFFER_init();
		
		global.couleur_Match = OFF;		//Led bicolore initialis�e � ind�finie (�teinte)
		SetLedColor(global.couleur_Match);
		LED_0 =1;
		LED_1 =0;
		LED_2 =0;
		LED_3 =0;

		/* menu fabriqu� par Djo et Jacen */
		affichage(lcd,&configOn);
//		affichePret(lcd);


		while (1)
		/*{
			if (global.flags.u2rx)
			{
				if(u2rxToCANmsg (&receivedCanMsg))
				{
					BUFFER_add(receivedCanMsg);
				}
				if(global.buffer.indiceFin == 20)
				{
					BUFFER_flush();
				}
			}
		}*/
		return 0;
	}


#endif /* def TEST_MODE */
