/*
 *	Club Robot ESEO 2008 - 2009
 *	Archi'Tech
 *
 *	Fichier : Buffer.h
 *	Package : Supervision
 *	Description : sp�cification des fonctions du buffer circulaire qui sauvegarde les messages can �chang�s durant le match ainsi que la base de temps
 *	Auteur : Jixi
 *	Version 20090305
 */
 
	#include "../QS/QS_all.h"
 #ifndef BUFFER_H
	#define BUFFER_H
	#include "../QS/QS_timer.h"
	#include "../QS/QS_uart.h"
	#include "Super_uart.h"
	#include "../QS/QS_can.h"			//inclut pour la rustine
	#include "../QS/QS_CANmsgList.h"
	
	void BUFFER_init();
	
	void BUFFER_add(CAN_msg_t m);
	/* Cette fonction ajoute au buffer circulaire (en queue de la file) un �l�ment de type CANtime (message CAN associ� � son moment d'occurence)
	 */

	void BUFFER_flush();
	#warning le commentaire me semble inadapt� (sign� Jacen)
	/* Cette fonction renvoie la structure contenue dans le buffer � la position pass�e en param�tre
	 */
#endif /* ndef BUFFER_H */
