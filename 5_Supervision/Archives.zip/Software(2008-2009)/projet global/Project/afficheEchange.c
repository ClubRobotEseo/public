#include "interface.h"


const char SWTxtEchange[BTN_NUMBER_ECHANGES][MAX_ECHANGES_LEN] = {
	"CAN <-> Zigbee",
	"UART -> Zigbee"
};

const char SWTxtSEchange[2][MAX_ECHANGES_LEN] = {
	"Oui",
	"Non",
};




void afficheEchange(THD_struct *lcd, config* configOn) 
{
	extern Uint8 swBuffer;
	Uint8 smenu=0;

	afficheTxtEchange(lcd, configOn);

	while(1) 
	{
		if(isSWEvent(swBuffer)) 
		{
			switch(getSWEvent(swBuffer)) 
			{
				case MASK_TOP:    /* Actions pour haut */
					if(isSWOn(MASK_TOP)) 
					{
	    				if(smenu > 0) 
						{
		    				sous_undrawCursDouble(lcd, smenu);
		    				smenu--;
		    				sous_drawCursDouble(lcd, smenu);
		    			}
            		}
				break;
				case MASK_BOT:
					if(isSWOn(MASK_BOT)) 
					{
						if(smenu < BTN_NUMBER_ECHANGES-1) 
						{
		    				sous_undrawCursDouble(lcd, smenu);
		    				smenu++;
		    				sous_drawCursDouble(lcd, smenu);
						}
            		}
				break;
				case MASK_VALID:
					if(isSWOn(MASK_VALID)) 
					{
						switch (smenu)
						{
							case 0:
								ssous_undrawCursDouble(lcd,0,configOn->envoi_can_zigbee);
		    					configOn->envoi_can_zigbee = !configOn->envoi_can_zigbee;
		    					ssous_drawCursDouble(lcd,0,configOn->envoi_can_zigbee);
								break;
							case 1:
								ssous_undrawCursDouble(lcd,1,configOn->envoi_uart_zigbee);
		    					configOn->envoi_uart_zigbee= !configOn->envoi_uart_zigbee;
		    					ssous_drawCursDouble(lcd,1,configOn->envoi_uart_zigbee);
								break;
							default:
								printf("erreur dans la fonction afficheenvoi");
								break;
						}
					}
				break;
				case MASK_CANCEL:
					if(isSWOn(MASK_CANCEL)) 
					{
						clearScreen(lcd);
						return;
	   				}
				break;
				case MASK_COLOR:
					if(isSWOn(MASK_COLOR))
					{
						askNewColor(configOn);
					}
				break;
			}
			/*On met � jour le buffer*/
	      	swBuffer = SW_PORT;
		}
		checkFlags(lcd, configOn);		//parallelisation du menu et de la r�ception des messages
	}
}


void afficheTxtEchange(THD_struct *lcd, config* configOn) 
{
	Uint8 i;
	
	for(i=0; i<BTN_NUMBER_ECHANGES; i++)
	{
		TXT_SetPos(lcd, THD_pos(STXT_POS_X,STXT_POS_Y+4*i));
		TXT_PrintString(lcd, SWTxtEchange[i]);
		GFX_DrawFrame(lcd, THD_pos(SMENU_POS_X+1, SMENU_POS_Y+1+i*2*(SBTN_HEIGHT+BTN_SMENU_OFFSET_Y)), THD_pos(SMENU_POS_X+SBTN_WIDTH-1, SMENU_POS_Y-1+i*2*(SBTN_HEIGHT+BTN_SMENU_OFFSET_Y)+SBTN_HEIGHT), SET);
		TXT_SetPos(lcd, THD_pos(STXT_POS_X,STXT_POS_Y+4*i+2));
		TXT_PrintString(lcd, SWTxtSEchange[0]);
		TXT_SetPos(lcd, THD_pos(STXT_POS_X+10,STXT_POS_Y+4*i+2));
		TXT_PrintString(lcd, SWTxtSEchange[1]);
	}
	sous_drawCursDouble(lcd, 0);
	ssous_drawCursDouble(lcd,0,configOn->envoi_can_zigbee);
	ssous_drawCursDouble(lcd,1,configOn->envoi_uart_zigbee);
}
