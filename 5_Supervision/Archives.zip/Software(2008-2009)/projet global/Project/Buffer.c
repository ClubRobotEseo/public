/*
 *	Club Robot ESEO 2008 - 2009
 *	Archi'Tech
 *
 *	Fichier : Buffer.c
 *	Package : Supervision
 *	Description : impl�mentation du buffer circulaire qui sauvegarde les messages can �chang�s durant le match ainsi que la base de temps
 *	Auteur : Jixi
 *	Version 20090305
 */

#define BUFFER_C
#include "Buffer.h"


void BUFFER_init()
{
	global.buffer.indiceDebut = 0;
	global.buffer.indiceFin = 0;
	global.count_BEACON_POS_msg = 3;	//On initialise le compteur pour enregistrer le premier compteur
	global.count_CARTE_P_POSITION_ROBOT_msg = 3;		//idem
}
 
void BUFFER_add(CAN_msg_t m)
{
	switch(m.sid)		//On trie les messages en fonction de leur sid
	{
		case 0:						//�a veut rien dire
			break;
			
		case ASSER_TELL_POSITION:	//On en veut pas
			break;
		
		case ACT1_DCM_STATE:		//On en veut pas
			break;
			
		case BEACON_POS:
			global.count_BEACON_POS_msg++;
			global.count_BEACON_POS_msg %= 4;
			if(!global.count_BEACON_POS_msg)		//On prend un message sur quatre
			{
				(global.buffer.tab[global.buffer.indiceFin]).message = m;
				(global.buffer.tab[global.buffer.indiceFin]).temps = global.TIMER3_loops; //le timer boucle toutes les 250 ms
				global.buffer.indiceFin++;
			}
			break;
		
		case CARTE_P_POSITION_ROBOT:
			global.count_CARTE_P_POSITION_ROBOT_msg++;
			global.count_CARTE_P_POSITION_ROBOT_msg %= 4;
			if(!global.count_CARTE_P_POSITION_ROBOT_msg)		//On prend un message sur quatre
			{
				(global.buffer.tab[global.buffer.indiceFin]).message = m;
				(global.buffer.tab[global.buffer.indiceFin]).temps = global.TIMER3_loops; //le timer boucle toutes les 250 ms
				global.buffer.indiceFin++;
			}
			break;
			
		/*case ACT2_DROP_LINTEL:
		case ACT2_GET_LINTEL:
			CAN_send(&m);*/		//Rustine : on renvoie ces messages sur le CAN avant de les enregistrer
		
		default:					//Par d�faut on enregistre
			(global.buffer.tab[global.buffer.indiceFin]).message = m;
			(global.buffer.tab[global.buffer.indiceFin]).temps = global.TIMER3_loops; //le timer boucle toutes les 250 ms
			global.buffer.indiceFin++;
			break;
	}

	if (global.buffer.indiceFin >= BUFFER_SIZE-1)		//Si jamais on d�passe la taille du buffer, on �crase le dernier message re�u, BUFFER_SIZE -1 car on incr�mente si la condition est vraie
		global.buffer.indiceFin=BUFFER_SIZE-1;
}

void _ISR _T3Interrupt()
{
	global.TIMER3_loops++;
	IFS0bits.T3IF=0;
}

void BUFFER_flush()
{
	Uint16 i;
	Uint16 temps = 0xFFFF;
	Uint8 aux_debut = global.buffer.indiceDebut;
	Uint8 aux_fin = global.buffer.indiceFin;
	CAN_msg_t msg;
	while(global.buffer.indiceDebut<global.buffer.indiceFin)
	{	
		if((global.buffer.tab[global.buffer.indiceDebut]).temps != temps)
		{
			temps = (global.buffer.tab[global.buffer.indiceDebut]).temps;
			
			UART2_putc(STX);
			UART2_putc((Uint8)(temps>>8));
			UART2_putc((Uint8)temps);
			UART2_putc(ETX);		
		}
		//tempo � l'arrache
		for(i=1;i!=0;i++);
		msg = ((global.buffer.tab[global.buffer.indiceDebut]).message);
		CANmsgToU2tx (&msg );
		global.buffer.indiceDebut++;
		
		//tempo � l'arrache
		for(i=1;i!=0;i++);
	}
	global.buffer.indiceDebut = aux_debut;
	global.buffer.indiceFin = aux_fin;
}
