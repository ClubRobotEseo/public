/*
 *	Club Robot ESEO 2008 - 2009
 *	Archi'Tech
 *
 *	Fichier : Super_uart.c
 *	Package : Supervision
 *	Description : fonctions de gestion des I/O sur uart.
 *	Auteur : Jacen
 *	Version 20081214
 */

#define SUPER_UART_C

#include "Super_uart.h"

#ifdef USE_UART1
bool_e u1rxToCANmsg (CAN_msg_t* dest)
{
	/*	
	 *	cette fonction lit un octet dans le buffer de reception de l'uart2
	 *	et compl�te le message CAN pass� en argument � partir du point o�
	 *	elle s'est arret�e � son pr�c�dent appel. Elle renvoie ensuite si
	 *	oui ou non elle a fini de compl�ter le message CAN. Elle v�rifie 
	 *  aussi si le message est bien conforme au protocole de communication
	 *  (cf QS)
	 */
	static Uint8 next_byte_to_read=0;
	Uint8 byte_read;

	if(global.flags.u1rx)
	{
		byte_read = UART1_get_next_msg();

		switch (next_byte_to_read)
		{
			case 0:
				if(byte_read == SOH) 
					(++next_byte_to_read);		//v�rifie qu'il s'agit bien d'un message CAN externe (cf protocole de communication QS)
				break;
			case 1:		/*lecture du MSB du sid */
				dest->sid = (Uint16)byte_read <<8;
				(++next_byte_to_read);
				break;
			case 2:		/*lecture du LSB du sid */
				dest->sid |= (Uint16)byte_read;
				(++next_byte_to_read);
				break;
			case 11:	/*lecture du champs size */
				dest->size = byte_read;
				(++next_byte_to_read);
				break;
			case 12:
				if(byte_read == EOT) 
					(++next_byte_to_read);		//v�rification de fin du message (cf protocole de communication QS)
				else 
					next_byte_to_read = 0;						//Si le message n'est pas valide on recommence � 0
				break;
				
			default:	/*lecture d'un octet de data */
				dest->data[next_byte_to_read - 3]=byte_read;
				(++next_byte_to_read);
				break;
		}
		if(next_byte_to_read >12)
		{
			next_byte_to_read=0;
			return TRUE;
		}
	}
	return FALSE;
}

void CANmsgToU1tx (CAN_msg_t* src)
{
	/*	Ecrit le contenu du message CAN pass� en argument sur
	 *	l'uart1
	 */
	Uint8 i;
	UART1_putc(0x01);		// Envoi de l'octet SOH cf : protocole de communication QS
	UART1_putc((Uint8)(src->sid >>8));
	UART1_putc((Uint8)src->sid);
	for (i=0; i<8; i++)
		UART1_putc(src->data[i]);
	UART1_putc(src->size);
	UART1_putc(0x04);		// Envoi de l'octet EOT cf : protocole de communication QS
}
#endif /* def USE_UART1 */

#ifdef USE_UART2
bool_e u2rxToCANmsg (CAN_msg_t* dest)
{
	/*	
	 *	cette fonction lit un octet dans le buffer de reception de l'uart2
	 *	et compl�te le message CAN pass� en argument � partir du point o�
	 *	elle s'est arret�e � son pr�c�dent appel. Elle renvoie ensuite si
	 *	oui ou non elle a fini de compl�ter le message CAN. Elle v�rifie 
	 *  aussi si le message est bien conforme au protocole de communication
	 *  (cf QS)
	 */
	static Uint8 next_byte_to_read=0;
	Uint8 byte_read;

	if(global.flags.u2rx)
	{
		byte_read = UART2_get_next_msg();

		switch (next_byte_to_read)
		{
			case 0:
				if(byte_read == SOH) 
					(++next_byte_to_read);		//v�rifie qu'il s'agit bien d'un message CAN externe (cf protocole de communication QS)
				break;
			case 1:		/*lecture du MSB du sid */
				dest->sid = (Uint16)byte_read <<8;
				(++next_byte_to_read);
				break;
			case 2:		/*lecture du LSB du sid */
				dest->sid |= (Uint16)byte_read;
				(++next_byte_to_read);
				break;
			case 11:	/*lecture du champs size */
				dest->size = byte_read;
				(++next_byte_to_read);
				break;
			case 12:
				if(byte_read == EOT) 
					(++next_byte_to_read);		//v�rification de fin du message (cf protocole de communication QS)
				else 
					next_byte_to_read = 0;						//Si le message n'est pas valide on recommence � 0
				break;
				
			default:	/*lecture d'un octet de data */
				dest->data[next_byte_to_read - 3]=byte_read;
				(++next_byte_to_read);
				break;
		}
		if(next_byte_to_read >12)
		{
			next_byte_to_read=0;
			return TRUE;
		}
	}
	return FALSE;
}

void CANmsgToU2tx (CAN_msg_t* src)
{
	/*	Ecrit le contenu du message CAN pass� en argument sur
	 *	l'uart1
	 */
	Uint8 i;
	UART2_putc(0x01);		// Envoi de l'octet SOH cf : protocole de communication QS
	UART2_putc((Uint8)(src->sid >>8));
	UART2_putc((Uint8)src->sid);
	for (i=0; i<8; i++)
		UART2_putc(src->data[i]);
	UART2_putc(src->size);
	UART2_putc(0x04);		// Envoi de l'octet EOT cf : protocole de communication QS
}
#endif /* def USE_UART2 */


