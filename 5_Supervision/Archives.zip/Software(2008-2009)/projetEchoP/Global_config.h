/*
 *  Club Robot ESEO 2008 - 2009
 *  Archi-Tech'
 *
 *  Fichier : Global_config.h
 *  Package : Standard_Project
 *  Description : Configuration des modules de QS
 *  Auteur : Jacen
 *  Version 20081209
 */

#ifndef GLOBAL_CONFIG_H
	#define GLOBAL_CONFIG_H
	#include "../QS/QS_types.h"

	/* En premier lieu, choisir si on souhaite executer un code de
	 * test ou le code de match */

	#define TEST_MODE
//	#define MATCH_MODE

	/* Pour certaines config particulieres, il faut definir qui on est
	 * a l'aide d'une des valeurs du type cartes_e de QS_types.h */
	#define I_AM CARTE_SUPER

	/* Il faut choisir � quelle frequence on fait tourner le PIC */
	#define FREQ_10MHZ
//	#define FREQ_10MHZ_FS_CLK	/* uniquement pour tester le quartz */
//	#define FREQ_20MHZ
//	#define FREQ_40MHZ
	
	/* Les instructions ci dessous d�finissent le comportement des
	 * entrees sorties du pic. une configuration en entree correspond
	 * a un bit a 1 (Input) dans le masque, une sortie a un bit a
	 * 0 (Output).
	 * Toute connection non utilisee doit etre configuree en entree
	 * (risque de griller ou de faire bruler le pic) 
	 */

	#define PORT_A_IO_MASK	0xFFFF
	#define PORT_B_IO_MASK	0xFFFF
	#define PORT_C_IO_MASK	0xFFFF
	#define PORT_D_IO_MASK	0xFF00
	#define PORT_E_IO_MASK	0xFFFF
	#define PORT_F_IO_MASK	0xFFFF
	#define PORT_G_IO_MASK	0xFFFF

	/* Les instructions suivantes permettent de configurer certainesF
	 * entrees/sorties du pic pour realiser des fonctionnalites
	 * particulieres comme une entree analogique 
	 */

	#define USE_CAN
//	#define USE_CAN2
/*	Nombre de messages CAN conserv�s 
	pour traitement hors interuption */
	#define CAN_BUF_SIZE		4
//
	#define USE_UART1
	#define USE_UART1RXINTERRUPT
//	#define USE_UART2
//	#define USE_UART2RXINTERRUPT
/*	Taille de la chaine de caracteres memorisant
	les caracteres recus sur UART */
	#define UART_RX_BUF_SIZE	16
//
/* utilise les PWM L au lieu des H */
//	#define USE_PWM_L
/* choix de la fr�quence des PWM */
//	#define FREQ_PWM_50HZ
	#define FREQ_PWM_1KHZ
//	#define FREQ_PWM_10KHZ
//	#define FREQ_PWM_50KHZ
//
//
/* utilisation des entr�es analogiques */
//	#define USE_AN0
//	#define USE_AN1
//	#define USE_AN2
//	#define USE_AN3
//	#define USE_AN4
//	#define USE_AN5
//	#define USE_AN6
//	#define USE_AN7
//	#define USE_AN8
//	#define USE_AN9
//	#define USE_AN10
//	#define USE_AN11
//	#define USE_AN12
//	#define USE_AN13
//	#define USE_AN14
//	#define USE_AN15
//	#define USE_ANALOG_EXT_VREF

	
	
#endif /* ndef GLOBAL_CONFIG_H */
