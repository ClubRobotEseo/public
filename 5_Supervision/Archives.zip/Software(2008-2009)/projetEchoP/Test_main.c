/*
 *	Club Robot ESEO 2008 - 2009
 *	Archi-Tech'
 *
 *	Fichier : Test_main.c
 *	Package : Projet Standard
 *	Description : fonction principale permettant
 *				l'appel des fonctions de test
 *				de la carte supervision
 *	Auteur : Jacen
 *	Version 20081209
 */

#define TEST_MAIN_C
#include "Test_main.h"

#ifdef TEST_MODE

	int main (void)
	{
		Uint16 i=0;
		CAN_msg_t receivedCanMsg, UartToCanMsg;//, test_can_msg = {0x101,"RTFM ! ", 0};

		PORTS_init();
		UART_init();
		CAN_init();
		
				
		while (1)
		{
			if(!i)
				PORTD++;
			i++;
			
			if (global.flags.canrx)
			{
				receivedCanMsg = CAN_get_next_msg();
				if (receivedCanMsg.sid)
				{
					CANmsgToU1tx (&receivedCanMsg);
				}
			}
			if (global.flags.u1rx)
			{
				if(u1rxToCANmsg (&UartToCanMsg))
				{
					//CANmsgToU1tx (&UartToCanMsg);
					CAN_send(&UartToCanMsg);
				}
			}
			
		}
		return 0;
	}


#endif /* def TEST_MODE */
