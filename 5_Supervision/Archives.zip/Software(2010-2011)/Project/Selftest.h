/*
 *	Club Robot ESEO 2009 - 2011
 *	Chek'Norris
 *
 *	Fichier : Selftest.h
 *	Package : Supervision
 *	Description : Envoi et r�ception des messages de selftest. 
 *	Auteur : Ronan & Patman
 *	Version 20100422
 */
#include "QS/QS_all.h"

#ifndef SELFTEST_H
	#define SELFTEST_H
	
	#include "QS/QS_can.h"
	#include "QS/QS_CANmsgList.h"
	#include "QS/QS_uart.h"
	#include "QS/QS_watchdog.h"
	#include "QS/QS_can_over_uart.h"

	#define LED_V_ACT LATBbits.LATB14
	#define LED_V_BALISE LATBbits.LATB10
	#define LED_V_STRAT LATBbits.LATB12
	#define LED_V_ASSER LATBbits.LATB4
	#define LED_V_ROBOT LATBbits.LATB8
	#define LED_R_ACT LATBbits.LATB15
	#define LED_R_BALISE LATBbits.LATB11
	#define LED_R_STRAT LATBbits.LATB13
	#define LED_R_ASSER LATBbits.LATB5
	#define LED_R_ROBOT LATBbits.LATB9
	
	#define LED_ON	1
	#define LED_OFF	0
	
	#define FORWARD 0x01
	#define	REAR 0x10
		
	#define TEMPS_SYNCHRO 10
	#define NOMBRE_TESTS_BALISE 2
	
	void SELFTEST_init();
	void SELFTEST_update();
	void LED_init();
	
#endif
