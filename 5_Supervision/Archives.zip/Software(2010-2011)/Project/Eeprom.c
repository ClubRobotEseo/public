/*
 *	Club Robot ESEO 2010 - 2011
 *	???
 *
 *	Fichier : eeprom.c
 *	Package : Supervision
 *	Description : Gestion d'une m�moire externe sur SPI
 *	Auteur : Ronan
 *	Version 20100929
 */

#define READ 0x03 	/* Read data from memory array beginning at selected address */
#define WRITE 0x02 	/* Write data to memory array beginning at selected address */
#define WEN 0x06 	/* Set the write enable latch (enable write operations) */
#define WRDI 0x04 	/* Reset the write enable latch (disable write operations) */
#define RDSR 0x05 	/* Read STATUS register */
#define WRSR 0x01 	/* Write STATUS register */
#define PE 0x42 	/* Page Erase � erase one page in memory array */
#define SE 0xD8 	/* Sector Erase � erase one sector in memory array */
#define CE 0xC7 	/* Chip Erase � erase all sectors in memory array */
#define RDID 0xAB 	/* Release from Deep power-down and read electronic signature */
#define DPD 0xB9 	/* Deep Power-Down mode */

#define EEPROM_C
#include "eeprom.h"


#define EEPROM_CS EEPROM_SPI2_CS

static void WriteEnable(void);

void EEPROM_init(void)
{
	EEPROM_SPI2_HOLD = 1;
	EEPROM_SPI2_WP = 1;
	SPI_init();
}


//Attention, il est interdit de demander une �criture � cheval sur 2 pages...
//(les pages font 256 octets... )
//TODO : renommer en EEPROM_write() et EEPROM_read()	
void EEPROM_Write(Uint32 Address, Uint8 * Data, Uint8 size) 
{
  Uint16 i;
  while(Memory_busy()) debug_printf(".");
  WriteEnable();                      // Write Enable prior to Write
  if(Memory_write_granted())		  // Check for WEL bit set
  {                  						
	EEPROM_CS = 0;                             // Select Device
	SPI2_write(WRITE);               // Send Write OpCode
	SPI2_write((Uint8)(Address >> 16));   // Send High Address Byte (seven �don�t care� bits)
	SPI2_write((Uint8)(Address >> 8));	// Send Address Byte
	SPI2_write((Uint8)(Address));     	// Send Low Address Byte
	
	for(i=0;i<size;i++)  
		SPI2_write(Data[i]);                // Write Byte to device

	EEPROM_CS = 1;                             // Deselect Device
	 // while(Memory_busy());               // Wait for Write to Complete
  } 
	//debug_printf("config %d", SPI2CON);
}

//Attention, il est interdit de demander une �criture � cheval sur 2 pages...
//(les pages font 256 octets... )
void EEPROM_Read(Uint32 Address, Uint8 * Data, Uint8 size) 
{
	Uint16 i;
	while(Memory_busy()) debug_printf(".");
  	EEPROM_CS = 0;                             // Select Device
	SPI2_write(READ);                // Send Read OpCode 
 	SPI2_write((Uint8)(Address >> 16));   // Send High Address Byte (seven �don�t care� bits)
	SPI2_write((Uint8)(Address >> 8));	// Send Address Byte
	SPI2_write((Uint8)(Address));     	// Send Low Address Byte

  	for(i=0;i<size;i++)
  		Data[i]=SPI2_read();         
  	EEPROM_CS = 1;                             // Deselect Device
}

static void WriteEnable(void) {
    EEPROM_CS = 0;                           //Select Device
   	SPI2_write(WEN);               //Write Enable OpCode
    EEPROM_CS = 1;                           //Deselect Device
}

bool_e Memory_busy(void) {
	Uint8 status;
    EEPROM_CS = 0;                           //Select Device
    SPI2_write(RDSR);              //Read Status Register OpCode
    status=SPI2_read();         //Read Status Register
    EEPROM_CS = 1;                           //Deselect Device
    return (status & 0x01);
}

//Renvoi vrai si la m�moire n'est pas prot�g�e en �criture...
bool_e Memory_write_granted(void) 
{
	Uint8 status;
    EEPROM_CS = 0;                           //Select Device
    SPI2_write(RDSR);              //Read Status Register OpCode
 	status=SPI2_read();         //Read Status Register
    EEPROM_CS = 1;                           //Deselect Device
    return (status & STATUS_MASK_WEL)?TRUE:FALSE;
}
