/*
 *  Club Robot ESEO 2008 - 2010
 *  Archi-Tech', PACMAN
 *
 *  Fichier : Global_config.h
 *  Package : Standard_Project
 *  Description : Configuration des modules de QS
 *  Auteur : Jacen
 *  Version 20100415
 */

#ifndef GLOBAL_CONFIG_H
	#define GLOBAL_CONFIG_H
	#include "QS/QS_types.h"

	/* Belle interface graphique !*/  
	#define INTERFACE_GRAPHIQUE
	
	/* Le mode verbeux active debug_printf */
	#define VERBOSE_MODE

	/* Pour certaines config particulieres, il faut definir qui on est
	 * a l'aide d'une des valeurs du type cartes_e de QS_types.h */
	#define I_AM CARTE_SUPER
	#define I_AM_CARTE_SUPER

	/* Il faut choisir � quelle frequence on fait tourner le PIC */
	#define FREQ_10MHZ
	
	/* Les instructions ci dessous d�finissent le comportement des
	 * entrees sorties du pic. une configuration en entree correspond
	 * a un bit a 1 (Input) dans le masque, une sortie a un bit a
	 * 0 (Output).
	 * Toute connection non utilisee doit etre configuree en entree
	 * (risque de griller ou de faire bruler le pic) 
	 */

	#define PORT_A_IO_MASK	0xFFFF
	#define PORT_B_IO_MASK	0x00CF
		#define LED_PROP_OK		PORTBbits.RB5
		#define LED_PROP_KO		PORTBbits.RB4
		#define LED_ACT_OK		PORTBbits.RB15
		#define LED_ACT_KO		PORTBbits.RB14
		#define LED_STRAT_OK	PORTBbits.RB13
		#define LED_STRAT_KO	PORTBbits.RB12
		#define LED_BALISE_OK	PORTBbits.RB11
		#define	LED_BALISE_KO	PORTBbits.RB10
		#define	LED_ROBOT_OK	PORTBbits.RB9
		#define LED_ROBOT_KO	PORTBbits.RB8
	#define PORT_C_IO_MASK	0xFFFF
	#define PORT_D_IO_MASK	0xC0FF
	#define PORT_E_IO_MASK	0xFCFF
		#define EEPROM_SPI2_HOLD	LATEbits.LATE8
		#define EEPROM_SPI2_WP		LATEbits.LATE9
	#define PORT_F_IO_MASK	0xFFFF
	#define PORT_G_IO_MASK	0xFD53
		#define	RTC_I2C_SCL		PORTGbits.RG2
		#define	RTC_I2C_SDA		PORTGbits.RG3
		#define EEPROM_SPI2_SCK	PORTGbits.RG5
		#define EEPROM_SPI2_SDI	PORTGbits.RG6
		#define EEPROM_SPI2_SDO	PORTGbits.RG7
	 	#define EEPROM_SPI2_CS 	LATGbits.LATG9
	/* Les instructions suivantes permettent de configurer certainesF
	 * entrees/sorties du pic pour realiser des fonctionnalites
	 * particulieres comme une entree analogique 
	 */

	#define USE_CAN
//	#define USE_CAN2
/*	Nombre de messages CAN conserv�s 
	pour traitement hors interuption */
	#define CAN_BUF_SIZE		16

	#define USE_UART1
	#define USE_UART1RXINTERRUPT
	#define USE_UART2
	#define USE_UART2RXINTERRUPT
/*	Taille de la chaine de caracteres memorisant
	les caracteres recus sur UART */
	#define UART_RX_BUF_SIZE	42


	//Taille du buffer de m�morisation des caract�res de l'interface texte ...
	#define TAILLE_BUFFER_INTERFACE_TEXTE 20
	
	
	//Taille du buffer de m�morisation des messages CAN pendant le match...
	//ATTENTION : il faut qu'il soit grand... mais pas trop, sinon il n'y a plus assez de place pour la pile...
	#define BUFFER_SIZE		200
	
	/* utilisation du module de watchdog */
	#define USE_WATCHDOG
	/* timer utilis� pour le watchdog (1, 2, 3 ou 4) */
	#define WATCHDOG_TIMER		2
	/* granularit� du temps en ms */
	#define WATCHDOG_QUANTUM	1
	/* nombre maximal de watchdogs en ex�cution */
	#define WATCHDOG_MAX_COUNT  3	

	//activation du module BUTTONS
	#define USE_BUTTONS
	//timer 1 pour le module BUTTONS
	#define BUTTONS_TIMER 1
	
	//Activation du module d'enregistrement des messages CAN re�us pendant les matchs en m�moire EEPROM.
	#define EEPROM_CAN_MSG_ENABLE
	
	#ifdef EEPROM_CAN_MSG_ENABLE
		#define USE_SPI2
		#define SPI_R_BUF_SIZE 16
	#endif
	
	#define USE_I2C
	
#endif /* ndef GLOBAL_CONFIG_H */
