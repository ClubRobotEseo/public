/*
 *	Club Robot ESEO 2009 - 2010
 *	Chomp
 *
 *	Fichier : Can_watch.h
 *	Package : Supervision
 *	Description : Traitement des messages arrivant sur CAN 
 *	Auteur : Ronan
 *	Version 20100422
 */
 
 #include "QS/QS_all.h"
 
 #ifndef CAN_WATCH_H
	#define CAN_WATCH_H
	#include "QS/QS_can.h"
	#include "Buffer.h"
	#include "Interface.h"
	#include "Can_watch.h"
	#include "Selftest.h"
	#include "Eeprom_can_msg.h"
	#include "RTC.h"
	
	void CAN_WATCH_init();
	void CAN_WATCH_update();
	void _ISR _T1Interrupt();
		
#endif
