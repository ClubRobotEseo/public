/*
 *	Club Robot ESEO 2008 - 2011
 *	Archi-Tech', PACMAN, ChekNorris
 *
 *	Fichier : main.h
 *	Package : Supervision
 *	Description : sequenceur de la supervision
 *	Auteur : Jacen
 *	Version 20110413
 */

#define MAIN_C
#include "main.h"

int main (void)
{	
	init();
	RTC_print_time();
		
//	print_all_msg(); //d�sol�...
//	EEPROM_CAN_MSG_verbose_all_match_header();
	
	while (1)
	{	

		/* Gestion du selftest */
		SELFTEST_update(NULL);

		/* Interface de gestion des boutons */
		BUTTON_update();

		/* V�rification de la r�ception d'un message CAN et traitement de ce message */		
		CAN_WATCH_update();

		/* V�rification de la r�ception d'un message de type CAN sur l'UART1 et l'UART2 */
		CAN_INJECTOR_update();

		
		#ifdef INTERFACE_GRAPHIQUE
			INTERFACE_GRAPHIQUE_process_u1rx();	
		#endif /* def INTERFACE_GRAPHIQUE */
	}
	return 0;
}

void init(void)
{
	PORTS_init();
	UART_init();;
	debug_printf("<---------Demarrage carte supervision--------->\r\n");
	
	RCON_read();
	RTC_init();
	TIMER_init();
	BUFFER_init();
	CAN_init();
	CAN_WATCH_init();
	CAN_INJECTOR_init();
	BUTTON_init();
	
	#ifdef EEPROM_CAN_MSG_ENABLE
		EEPROM_CAN_MSG_init();
	#endif
	
	#ifdef INTERFACE_GRAPHIQUE
		INTERFACE_GRAPHIQUE_init();
	#endif /* def INTERFACE_GRAPHIQUE */
	
	//CONFIGURATION PAR DEFAUT
	global.config_robot[STRATEGIE]=1;
	global.config_robot[COLOR]=BLUE;
	global.config_robot[EVITEMENT]=TRUE;
	global.config_robot[BALISE]=TRUE;
	global.config_robot[TRANSMIT]=TRUE;
	global.config_robot[BUFFER]=FALSE;	//Buffer d�sactiv� par d�faut !!!	
	
	//INITIALISATION DES LEDS
	LED_RUN = 1;
	LED_CAN = 0;
	LED_UART = 0;
	LED_USER = 1;
	LED_USER2 = 0;
	LED_ERROR = 0;
	
	//Initialisation de la proc�dure de selfest
	SELFTEST_init();
}

void RCON_read()
{
	debug_printf("dsPIC30F reset source :\r\n");
	if(RCON & 0x8000)
		debug_printf("- Trap conflict event\r\n");
	if(RCON & 0x4000)
		debug_printf("- Illegal opcode or uninitialized W register access\r\n");
	if(RCON & 0x80)
		debug_printf("- MCLR Reset\r\n");
	if(RCON & 0x40)
		debug_printf("- RESET instruction\r\n");
	if(RCON & 0x10)
		debug_printf("- WDT time-out\r\n");
	if(RCON & 0x8)
		debug_printf("- PWRSAV #SLEEP instruction\r\n");
	if(RCON & 0x4)
		debug_printf("- PWRSAV #IDLE instruction\r\n");
	if(RCON & 0x2)
		debug_printf("- POR, BOR\r\n");
	if(RCON & 0x1)
		debug_printf("- POR\r\n");
	RCON=0;
}
/* Trap pour debug reset */
void _ISR _MathError()
{
  _MATHERR = 0;
  LED_ERROR = 1;
  debug_printf("Trap Math\r\n");
  while(1) Nop();
}

void _ISR _StackError()
{
  _STKERR = 0;
  LED_ERROR = 1;
  debug_printf("Trap Stack\r\n");
  while(1) Nop();
}

void _ISR _AddressError()
{
  _ADDRERR = 0;
  LED_ERROR = 1;
  debug_printf("Trap Address\r\n");
  while(1) Nop();
}

void _ISR _OscillatorFail()
{
  _OSCFAIL = 0;
  LED_ERROR = 1;
  debug_printf("Trap OscFail\r\n");
  while(1) Nop();
}
