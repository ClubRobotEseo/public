/*
 *	Club Robot ESEO 2009 - 2010
 *	Chomp
 *
 *	Fichier : Can_injector.c
 *	Package : Supervision
 *	Description : Injection des messages arrivant de l'UART2 et de l'UART1 sur le CAN 
 *	Auteur : Ronan
 *	Version 20100422
 */
 
#define CAN_INJECTOR_C

#include "Can_injector.h"

bool_e CAN_INJECTOR_process_can_msg(CAN_msg_t * can_msg);
	
	
void CAN_INJECTOR_init() {

}

void CAN_INJECTOR_update() {
	
	static CAN_msg_t can_msg_1;
	static CAN_msg_t can_msg_2;
	
	if(!global.interface_graphique_enable)
	{
		if(u1rxToCANmsg(&can_msg_1))
		{	
			if(CAN_INJECTOR_process_can_msg(&can_msg_1))
				CAN_send(&can_msg_1);
			LED_USER = !LED_USER;
		}	
	}
	
	if(u2rxToCANmsg(&can_msg_2))
	{	
		if(CAN_INJECTOR_process_can_msg(&can_msg_2))
			CAN_send(&can_msg_2);
		LED_USER = !LED_USER;
	}
}


/*
@brief	Messages can re�us sur un uart et qui sont destin�s uniquement ou en partie � la supervision.
@ret	bool_e : TRUE si le message doit �tre propag� sur le bus can, FALSE si il ne concernait que nous... => pas de propagation.
@param	can_msg : message can re�u sur l'uart...
*/
bool_e CAN_INJECTOR_process_can_msg(CAN_msg_t * can_msg)
{
	bool_e propagation = TRUE;
	
	// Messages qui nous sont destin�s.
	switch(can_msg->sid)
	{	
		case BROADCAST_COULEUR:	//Attention, cette propagation est faite pour la propulsion, mais la strat�gie, si elle est pr�sente, ne prendra pas en compte cette couleur !
			global.config_robot[COLOR]=can_msg->data[0];
		break;
		case SUPER_RTC_SET:
			propagation = FALSE; //Ce message est pour nous...
			RTC_set_time(&(can_msg->data[0]), &(can_msg->data[1]), &(can_msg->data[2]), &(can_msg->data[3]), &(can_msg->data[4]), &(can_msg->data[5]), &(can_msg->data[6]));			
			/*
				Uint8 secondes
				Uint8 minutes
				Uint8 hours
				Uint8 day
				Uint8 months
				Uint8 year	(11 pour 2011)
			*/
			//Retour ... pour v�rifier que ca a fonctionn�..
			RTC_can_send();
		break;
		case SUPER_RTC_GET:
			propagation = FALSE; //Ce message est pour nous...
			RTC_print_time();			
			RTC_can_send();	
		break;
		default:
		break;			
	}
	
	#ifdef EEPROM_CAN_MSG_ENABLE
		EEPROM_CAN_MSG_process_msg(can_msg);
	#endif
	return propagation;
}	


